"""Persistent, scoped hold for the slot-4 position-unconfirmed episode.

This is not a global STOP latch. Missing or invalid evidence is fail-closed for
this route. The guard deliberately has no automatic release operation.
"""
import json, os, stat

PATH='/home/lava/printer_data/controlled-exploration/slot4-position-unconfirmed-20261109.json'
PORT='/dev/serial/by-path/platform-fed00000.usb-usb-0:1.3:1.0'
UID=(808780566,17445170,942880330)
MOTION=frozenset(('feed_filament','unwind_filament','feed_or_rollback_raw',
                  'start_feed_assist','update_feeding_speed'))
READ_STOP=frozenset(('stop_feed_filament','stop_feed_assist','get_status',
                     'get_info','get_feed_info','get_key_state','discover_device'))

class LocationHold:
    def __init__(self,path=PATH):
        self.valid_marker=False
        self.active=True
        try:
            st=os.lstat(path)
            if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.geteuid() or stat.S_IMODE(st.st_mode)!=0o600 or st.st_size>8192:
                return
            with open(path,encoding='utf8') as f: data=json.load(f)
            self.valid_marker=(isinstance(data,dict) and data.get('reason')=='position_unconfirmed_after_seek' and
                data.get('ace_uid')==list(UID) and data.get('slot')==3 and data.get('head')==3 and data.get('port')==PORT)
            if self.valid_marker and data.get('state') == 'verified_ejected':
                self.active=not (data.get('gate_empty') is True and data.get('heads_clear') is True and data.get('stopped') is True and data.get('uid_verified') is True)
            if self.valid_marker and data.get('state') == 'verified_recovered':
                self.active=not (data.get('head_triggered') is True and data.get('head_clear') is True and data.get('gate_present') is True and data.get('stopped') is True and data.get('encoder_target_reached') is True and data.get('target_mm') == 1393)
        except (OSError,ValueError,TypeError):
            return
    def blocks_route(self, *, head=None, idx=None, slot=None, port=None, ace_uid=None):
        # Head 4 may still contain this route even if another source/UID is
        # selected.  Slot 4 on the original port is independently protected.
        if not self.active: return False
        if head == 3: return True
        if slot != 3: return False
        if idx in (None,0) or port == PORT: return True
        # Unknown/reconnected hardware cannot prove that it is a different ACE.
        return ace_uid is None or tuple(ace_uid) == UID
    def blocks_wire(self, idx, request, port, ace_uid=None):
        if not isinstance(request,dict): return False
        method=request.get('method');params=request.get('params') or {}
        if method in READ_STOP: return False
        if method == 'raw':
            
            try: command=int(params.get('cmd'))
            except (ValueError,TypeError): command=None
            # Raw motor command cannot be safely scoped to a slot without
            # decoding protobuf; block only on the original ACE endpoint.
            return command in (8,10,11) and self.blocks_route(idx=idx,slot=3,port=port,ace_uid=ace_uid)
        if method in ('drying','drying_raw'):
            return bool(params.get('auto_roll',False)) and self.blocks_route(idx=idx,slot=3,port=port,ace_uid=ace_uid)
        if method not in MOTION: return False
        slot=params.get('index',params.get('slot'))
        if type(slot) is not int:
            return self.blocks_route(idx=idx,slot=3,port=port,ace_uid=ace_uid)
        return self.blocks_route(idx=idx,slot=slot,port=port,ace_uid=ace_uid)
    def message(self):
        return 'ACE槽4/喷头4耗材位置待核，相关运动已暂停；STOP和状态查询可用'
