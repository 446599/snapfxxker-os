"""Bounded, fail-closed ACE2 slot ejection; no heating or head motion."""
import logging, os, json, stat, time, hashlib
from .ace_location_hold import PATH, PORT, UID, LocationHold, RouteChanged
STEP_MM = 20
SPEED_MM_S = 80
MAX_MM = 2000  # hard command budget; inlet sensor ends the move
MAX_SECONDS = 480

class SlotActions:
    def __init__(self, ace):
        self.ace = ace
        self.seq = 0
        self.state = {'seq': 0, 'state': 'idle', 'kind': '', 'ace': None,
                      'slot': None, 'progress': 0, 'limit': MAX_MM, 'message': ''}
        self.cancel = False
        self._eject_lease = None
        self._eject_pending = None
        ace.printer.lookup_object('webhooks').register_endpoint('multiace/slot_eject_cancel', self.cancel_endpoint)

    def cancel_endpoint(self, request):
        if self.state['state'] != 'running' or self.state['kind'] != 'eject':
            request.send({'cancelled': False, 'state': self.state['state']})
            return
        self.cancel = True
        self.state['message'] = '正在停止，请等待确认'
        request.send({'cancelled': True, 'state': 'cancelling'})

    def status(self):
        return dict(self.state)

    def _check(self, idx, slot, transport=None, own=False, allow_tag=False, for_eject=False):
        a = self.ace
        a._require_no_stop_fault()
        if (allow_tag and self.cancel and getattr(a, '_tag_read_busy', False)
                and getattr(a, '_tag_op_kind', None) == 'read'
                and (getattr(a, '_tag_op_ace', None), getattr(a, '_tag_op_slot', None)) == (idx, slot)):
            raise RuntimeError('用户已停止识别')
        ps = a.printer.lookup_object('print_stats', None)
        if ps is None or getattr(ps, 'state', '').lower() not in ('standby', 'complete', 'cancelled'):
            raise RuntimeError('打印机不空闲或状态未知')
        if not a._is_v2_idx(idx) or not a._connected_per_ace.get(idx) or idx in a._fw_update_hold:
            raise RuntimeError('ACE 离线或不支持此操作')
        if a._serials.get(idx) is None:
            raise RuntimeError('ACE 通信不可用')
        if transport is not None and a._serials.get(idx) is not transport:
            raise RuntimeError('ACE 已断开或重新连接')
        if (a._swap_in_progress and not own) or a._unload_all_active or (not allow_tag and (getattr(a, '_tag_read_busy', False) or getattr(a, '_gen1_manual_busy', False))):
            raise RuntimeError('换料、卸载或标签操作正在进行')
        if (a._calibration or {}).get('state') not in ('idle', 'cancelled', 'complete', 'completed', 'error'):
            raise RuntimeError('校准正在进行')
        if getattr(a, '_calibration_unload', {}).get('active'):
            raise RuntimeError('校准退料正在进行')
        if not for_eject and a._get_heads_for_ace_slot(idx, slot):
            raise RuntimeError('请先从喷头卸载')
        if for_eject:
            sources = getattr(a, '_head_source', None)
            if not isinstance(sources, dict) or set(sources) != set(range(4)):
                raise RuntimeError('喷头来源状态未知')
            for source in sources.values():
                if source is not None and (
                    not isinstance(source, dict)
                    or type(source.get('ace_index')) is not int
                    or type(source.get('slot')) is not int
                    or not 0 <= source['ace_index'] < len(a._ace_devices)
                    or not 0 <= source['slot'] < 4
                ):
                    raise RuntimeError('喷头来源状态未知')
        bg = a.printer.lookup_object('ace_bg_swap', None)
        if bg is not None and getattr(bg, '_busy', False):
            raise RuntimeError('后台换料正在进行')
        guard = a.printer.lookup_object('ace_native_guard', None)
        if guard is not None and getattr(guard, 'state', None) != 'idle':
            raise RuntimeError('料槽保护正在运行或状态未知')
        for h in range(4):
            sensor = a.printer.lookup_object('filament_motion_sensor e%d_filament' % h, None)
            if sensor is None:
                raise RuntimeError('喷头状态未知')
            try:
                pin = getattr(sensor, 'runout_buttun_state', None) if (for_eject or getattr(a, 'unload_gpio', True)) else None
                raw = pin if for_eject or type(pin) is bool else sensor.get_status(0).get('filament_detected')
                if type(raw) is not bool: raise ValueError('unknown sensor')
                present = raw
            except Exception:
                raise RuntimeError('喷头状态未知')
            if present:
                source = a._head_source.get(h) if for_eject else None
                if (
                    not for_eject
                    or source is None
                    or (source.get('ace_index'), source.get('slot')) == (idx, slot)
                ):
                    raise RuntimeError('目标喷头有料或来源未知，请先从喷头卸载')

    def _request(self, idx, method, params, command, monitor=None, stop_transport=None, eject_token=None):
        request = {'method': method, 'params': params}
        if monitor is None and stop_transport is None and eject_token is None:
            r = self.ace._tipform_send(idx, request, timeout=3.0)
        else:
            attempts = 2 if method in ('get_status', 'get_key_state', 'get_feed_info') else 1
            r = None
            for attempt in range(attempts):
                request = {'method': method, 'params': params}
                box = [None]
                def callback(self, response, target=box):
                    target[0] = response if response is not None else {}
                if stop_transport is not None:
                    request['_insert_stop_transport'] = stop_transport
                    request['_insert_reject'] = callback
                if eject_token is not None:
                    request['_eject_token'] = eject_token
                    request['_insert_reject'] = callback
                if monitor is None:
                    monitor = lambda: None
                monitor()
                self.ace.send_request_to(idx, request, callback)
                deadline = self.ace.reactor.monotonic() + 3.0
                while box[0] is None and self.ace.reactor.monotonic() < deadline:
                    monitor()
                    self.ace.reactor.pause(min(deadline, self.ace.reactor.monotonic() + .05))
                monitor()
                r = box[0]
                if r is not None:
                    if attempt:
                        logging.info('[multiACE] slot_eject telemetry reply ace=%d method=%s id=%s attempt=%d',
                                     idx, method, request.get('id'), attempt + 1)
                    break
                if attempt + 1 < attempts:
                    logging.info('[multiACE] slot_eject telemetry timeout ace=%d method=%s id=%s retry=%d',
                                 idx, method, request.get('id'), attempt + 1)
        if r is None:
            raise RuntimeError('%s 响应超时' % method)
        if not isinstance(r, dict) or r.get('_v2_frame_valid') is not True or r.get('_v2_payload_valid') is not True or r.get('_v2_command') != command:
            raise RuntimeError('%s 响应帧无效' % method)
        if type(r.get('code')) is not int or r['code'] != 0 or str(r.get('msg','')).upper() == 'FORBIDDEN':
            raise RuntimeError('%s 设备拒绝或响应码无效' % method)
        if not isinstance(r.get('result'), dict):
            raise RuntimeError('%s 数据缺失' % method)
        return r['result']

    def _lane_states(self, idx, monitor=None):
        st = self._request(idx, 'get_status', {}, 6, monitor=monitor)
        slots = st.get('slots')
        if st.get('_status_wire_valid') is not True or not isinstance(slots, list) or len(slots) != 4 or any(not isinstance(x, dict) for x in slots) or sorted(x.get('index') for x in slots if type(x.get('index')) is int) != [0, 1, 2, 3] or any(x.get('_wire_valid') is not True or not isinstance(x.get('slot_status'), str) or not x['slot_status'] for x in slots):
            raise RuntimeError('槽位状态数据不完整或无效')
        return {x['index']: x['slot_status'] for x in slots}

    def _lanes_ready(self, idx):
        lanes = self._lane_states(idx)
        busy = [(i + 1, st) for i, st in lanes.items() if st != 'ready']
        if busy:
            raise RuntimeError('槽位忙碌: ' + ', '.join('%s=%s' % x for x in busy))

    def _gate(self, idx, slot, monitor=None):
        keys = self._request(idx, 'get_key_state', {}, 73, monitor=monitor).get('fields')
        if not isinstance(keys, dict) or type(keys.get('1')) is not int:
            raise RuntimeError('入口传感器数据缺失')
        return bool(keys['1'] & (1 << (4 * slot)))

    def _sample(self, idx, slot, allow_initial_zero=False, monitor=None):
        lanes = self._lane_states(idx, monitor=monitor)
        if any(st != 'ready' for st in lanes.values()):
            raise RuntimeError('槽位状态不稳定或未知')
        gate = self._gate(idx, slot, monitor=monitor)
        feed = self._request(idx, 'get_feed_info', {}, 76, monitor=monitor)
        rows = feed.get('feed_info')
        if feed.get('_feed_wire_valid') is not True or not isinstance(rows, list):
            raise RuntimeError('编码器数据缺失')
        row = [x for x in rows if x.get('index') == slot]
        if len(row) != 1 or row[0].get('_wire_valid') is not True or type(row[0].get('decoder')) is not int or type(row[0].get('_decoder_present')) is not bool:
            raise RuntimeError('编码器数据不可用')
        present, decoder = row[0]['_decoder_present'], row[0]['decoder']
        if not present and decoder != 0:
            raise RuntimeError('编码器数据不可用')
        if allow_initial_zero:
            steps, length = row[0].get('steps'), row[0].get('length')
            if type(steps) is not int or steps < 0 or type(length) is not int or length < 0:
                raise RuntimeError('编码器基线数据不可用')
            return gate, (present, decoder), (steps, length)
        return gate, (present, decoder)

    def _stop(self, idx, slot, timeout=2.0):
        a = self.ace
        r = a._checked_stop_request(idx, {'method': 'stop_feed_assist', 'params': {'index': slot}}, timeout=timeout)
        if r.get('_v2_frame_valid') is not True or r.get('_v2_payload_valid') is not True or r.get('_v2_command') != 9:
            a._latch_stop_fault(idx, slot, 'STOP response frame not confirmed')
            a._require_no_stop_fault()
        return r

    def _stable(self, idx, slot, allow_initial_zero=False, monitor=None):
        samples = []
        for _ in range(3):
            samples.append(self._sample(idx, slot, allow_initial_zero=allow_initial_zero, monitor=monitor))
            end = self.ace.reactor.monotonic() + .25
            while self.ace.reactor.monotonic() < end:
                if monitor: monitor()
                self.ace.reactor.pause(min(end, self.ace.reactor.monotonic() + .05))
            if monitor: monitor()
        if len(set(samples)) != 1:
            raise RuntimeError('停止后入口或编码器不稳定')
        return samples[-1][:2]

    def _stop_and_wait_ready(self, idx, slot, transport, motion_start=None):
        a = self.ace
        if motion_start is not None:
            while a.reactor.monotonic() - motion_start < .3:
                if a._serials.get(idx) is not transport: raise RuntimeError('原 ACE 连接已断开')
                a.reactor.pause(min(motion_start + .3, a.reactor.monotonic() + .05))
        if a._serials.get(idx) is not transport: raise RuntimeError('原 ACE 连接已断开')
        self._stop(idx, slot)
        deadline = a.reactor.monotonic() + 8.0
        def cleanup_monitor():
            if a._serials.get(idx) is not transport: raise RuntimeError('ACE 连接改变')
            if a.reactor.monotonic() >= deadline: raise RuntimeError('停止确认超过时限')
        retry_at = a.reactor.monotonic() + 1.0
        retried = False
        while a.reactor.monotonic() < deadline:
            cleanup_monitor()
            lanes = self._lane_states(idx, monitor=cleanup_monitor)
            if any(st != 'ready' for i, st in lanes.items() if i != slot):
                raise RuntimeError('其他料槽正在运动或状态未知')
            target = lanes[slot]
            if target == 'ready':
                result = self._stable(idx, slot, monitor=cleanup_monitor)
                cleanup_monitor()
                return result
            if target != 'rollback': raise RuntimeError('目标料槽状态异常: %s' % target)
            if not retried and a.reactor.monotonic() >= retry_at:
                if deadline - a.reactor.monotonic() < 3.0:
                    raise RuntimeError('停止确认剩余时间不足')
                self._stop(idx, slot, timeout=.5)
                cleanup_monitor()
                retried = True
            a.reactor.pause(min(deadline, a.reactor.monotonic() + .1))
        raise RuntimeError('停止后料槽未在时限内恢复就绪')

    def eject_allows(self, idx, request, serial=None):
        try:
            lease = self._eject_lease
            if lease is None or self._eject_pending is None or self.cancel:
                return False
            target_idx, slot, transport = lease
            if serial is not None and serial is not transport:
                return False
            if (
                idx != target_idx
                or self.ace._serials.get(idx) is not transport
                or not self.ace._connected_per_ace.get(idx)
                or self.ace._serial_failed_per_ace.get(idx)
                or self.ace._stop_guard.message()
            ):
                return False
            if (
                self.state.get("state") != "running"
                or self.state.get("kind") != "eject"
                or self.ace._head_source != self._eject_sources
            ):
                return False
            if request.get("_eject_token") is not self._eject_pending:
                return False
            if request.get("method") != "unwind_filament" or request.get("params") != {
                "index": slot,
                "length": MAX_MM,
                "speed": SPEED_MM_S,
            }:
                return False
            ps = self.ace.printer.lookup_object("print_stats", None)
            if ps is None or getattr(ps, "state", "").lower() not in (
                "standby",
                "complete",
                "cancelled",
            ):
                return False
            for head in range(4):
                sensor = self.ace.printer.lookup_object(
                    "filament_motion_sensor e%d_filament" % head, None
                )
                pin = (
                    getattr(sensor, "runout_buttun_state", None)
                    if sensor is not None
                    else None
                )
                source = self.ace._head_source.get(head)
                if type(pin) is not bool:
                    return False
                if pin and (
                    not isinstance(source, dict)
                    or (source.get("ace_index"), source.get("slot")) == (idx, slot)
                ):
                    return False
            return True
        except Exception:
            return False

    def eject_consumed(self, request):
        if (
            self._eject_pending is not None
            and request.get("_eject_token") is self._eject_pending
        ):
            self._eject_pending = None

    def _eject_stop(self, idx, slot, transport, monitor):
        if self.ace._serials.get(idx) is not transport:
            raise RuntimeError("原ACE连接已改变")
        return self._request(
            idx,
            "stop_feed_filament",
            {"index": slot},
            9,
            monitor=monitor,
            stop_transport=transport,
        )

    def _eject_stable(self, idx, slot, monitor):
        gates = []
        for _ in range(3):
            monitor()
            lanes = self._lane_states(idx, monitor=monitor)
            if any(value != "ready" for value in lanes.values()):
                raise RuntimeError("槽位静止状态未知")
            gates.append(self._gate(idx, slot, monitor=monitor))
            end = self.ace.reactor.monotonic() + 0.25
            while self.ace.reactor.monotonic() < end:
                monitor()
                self.ace.reactor.pause(min(end, self.ace.reactor.monotonic() + 0.05))
        if len(set(gates)) != 1:
            raise RuntimeError("入口状态不稳定")
        return gates[-1]

    def _eject_stop_ready(self, idx, slot, transport, motion_start=None):
        a = self.ace
        if motion_start is not None:
            while a.reactor.monotonic() - motion_start < 0.3:
                if a._serials.get(idx) is not transport:
                    raise RuntimeError("原ACE连接已改变")
                a.reactor.pause(min(motion_start + 0.3, a.reactor.monotonic() + 0.05))
        deadline = a.reactor.monotonic() + 8

        def monitor():
            if (
                a._serials.get(idx) is not transport
                or a.reactor.monotonic() >= deadline
            ):
                raise RuntimeError("原连接变化或STOP确认超时")

        self._eject_stop(idx, slot, transport, monitor)
        retry_at = a.reactor.monotonic() + 1
        retried = False
        while True:
            monitor()
            lanes = self._lane_states(idx, monitor=monitor)
            if any(value != "ready" for i, value in lanes.items() if i != slot):
                raise RuntimeError("其他槽忙或未知")
            if lanes[slot] == "ready":
                return self._eject_stable(idx, slot, monitor)
            if lanes[slot] != "rollback":
                raise RuntimeError("目标槽状态未知")
            if not retried and a.reactor.monotonic() >= retry_at:
                self._eject_stop(idx, slot, transport, monitor)
                retried = True
            a.reactor.pause(min(deadline, a.reactor.monotonic() + 0.1))

    def start(self, gcmd):
        idx = gcmd.get_int("ACE", minval=0, maxval=3)
        slot = gcmd.get_int("SLOT", minval=0, maxval=3)
        if self.state["state"] == "running":
            raise gcmd.error("料槽操作正在进行")
        try:
            self._check(idx, slot, for_eject=True)
        except Exception as e:
            raise gcmd.error(str(e))
        self.seq += 1
        self.cancel = False
        self.state = {
            "seq": self.seq,
            "state": "running",
            "kind": "eject",
            "ace": idx,
            "slot": slot,
            "message": "准备退出 ACE",
        }
        self.ace._swap_in_progress = True
        transport = self.ace._serials.get(idx)
        self.ace.reactor.register_async_callback(
            lambda _event: self._run(idx, slot, transport)
        )
        gcmd.respond_info("料槽退出已开始")

    def stop(self, gcmd):
        if self.state["state"] != "running" or self.state["kind"] != "eject":
            raise gcmd.error("没有正在进行的料槽退出")
        self.cancel = True
        self.state["message"] = "正在停止，请等待确认"
        gcmd.respond_info("已请求停止")

    def _arm_eject_pending(self, marker_hash):
        a = self.ace
        with open(PATH, 'rb') as f:
            old = f.read()
        if hashlib.sha256(old).hexdigest() != marker_hash:
            raise RuntimeError('位置记录在操作中改变')
        if a._location_hold.active:
            return marker_hash
        data = json.loads(old)
        data['state'] = 'eject_in_progress'
        data['eject_started_at'] = time.time()
        nonce = os.urandom(16).hex()
        archive = PATH + '.before-eject-start-' + nonce
        tmp = PATH + '.eject-pending-' + nonce
        fd = os.open(archive, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as f:
            f.write(old)
            f.flush()
            os.fsync(f.fileno())
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as f:
            json.dump(data, f)
            f.flush()
            os.fsync(f.fileno())
        staged = LocationHold(tmp)
        if not staged.valid_marker or not staged.active:
            raise RuntimeError('退出中保护记录无效')
        os.replace(tmp, PATH)
        a._location_hold = LocationHold(routes_path=a._location_hold.routes_path)
        if not a._location_hold.valid_marker or not a._location_hold.active:
            raise RuntimeError('退出中保护未生效')
        directory = os.open(os.path.dirname(PATH), os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
        with open(PATH, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()

    def _commit_ejected(self, idx, slot, transport, uid, marker_hash, sources):
        a = self.ace
        # A different lane may never clear the slot-4 incident marker.
        affected = (
            idx == 0 and slot == 3 and uid == UID and str(a._ace_devices[0]) == PORT
        )
        old_sources = dict(a._head_source)
        marker_old = None
        archive = None
        replaced = False
        try:
            if affected and marker_hash is not None:
                st = os.lstat(PATH)
                if (
                    not stat.S_ISREG(st.st_mode)
                    or st.st_uid != os.geteuid()
                    or stat.S_IMODE(st.st_mode) != 0o600
                ):
                    raise RuntimeError("位置记录权限不符")
                with open(PATH, "rb") as f:
                    marker_old = f.read()
                if hashlib.sha256(marker_old).hexdigest() != marker_hash:
                    raise RuntimeError("位置记录在操作中改变")
                nonce = os.urandom(16).hex()
                archive = PATH + ".before-eject-" + nonce
                tmp = PATH + ".eject-" + nonce
                fd = os.open(archive, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "wb") as f:
                    f.write(marker_old)
                    f.flush()
                    os.fsync(f.fileno())
                proof = {
                    "reason": "position_unconfirmed_after_seek",
                    "state": "verified_ejected",
                    "ace_uid": list(UID),
                    "slot": 3,
                    "head": 3,
                    "port": PORT,
                    "gate_empty": True,
                    "heads_clear": True,
                    "stopped": True,
                    "uid_verified": True,
                    "time": time.time(),
                }
                fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "w") as f:
                    json.dump(proof, f)
                    f.flush()
                    os.fsync(f.fileno())
                staged = LocationHold(tmp)
                if not staged.valid_marker or staged.active:
                    raise RuntimeError("退出记录无效")
            for head, source in list(a._head_source.items()):
                if source is not None and (
                    source.get("ace_index"),
                    source.get("slot"),
                ) == (idx, slot):
                    a._head_source[head] = None
            a._save_head_source()
            if affected and marker_old is not None:
                os.replace(tmp, PATH)
                replaced = True
                d = os.open(os.path.dirname(PATH), os.O_RDONLY)
                try:
                    os.fsync(d)
                finally:
                    os.close(d)
                hold = LocationHold(routes_path=a._location_hold.routes_path)
                if not hold.valid_marker or hold.active:
                    raise RuntimeError("退出记录复核失败")
                a._location_hold = hold
            # Only the calibrated 0/3 route owns this park reference.
            if (idx, slot) == (0, 3):
                a._normal_load_speed.park = None
        except Exception:
            if replaced and archive is not None:
                os.replace(archive, PATH)
            a._head_source = old_sources
            a._save_head_source()
            raise

    def _run(self, idx, slot, transport):
        a = self.ace
        start = a.reactor.monotonic()
        moving = False
        motion_start = None
        try:
            if transport is None:
                raise RuntimeError("ACE通信不可用")
            self._check(idx, slot, transport, own=True, for_eject=True)
            sources = {
                h: (dict(v) if v is not None else None)
                for h, v in a._head_source.items()
            }
            self._eject_sources = sources

            def check():
                self._check(idx, slot, transport, own=True, for_eject=True)
                if a._head_source != sources:
                    raise RuntimeError("喷头来源发生变化")
                if self.cancel:
                    raise RuntimeError("已取消，耗材可能仍在入口内")
                if a.reactor.monotonic() - start > MAX_SECONDS - 15:
                    raise RuntimeError("达到总时限，尚未退出")

            uid_response = self._request(idx, "discover_device", {}, 0, monitor=check)
            uid = tuple(uid_response.get("uid%d" % i) for i in (1, 2, 3))
            if any(type(x) is not int for x in uid):
                raise RuntimeError("ACE身份未知")
            held = a._location_hold.blocks_route(
                idx=idx, slot=slot, port=str(a._ace_devices[idx]), ace_uid=uid, heads=a._rfid_route_heads(idx,slot)
            )
            marker_hash = None
            affected = (
                idx == 0 and slot == 3 and uid == UID and str(a._ace_devices[0]) == PORT
            )
            route_token = a._location_hold.route_token(str(a._ace_devices[idx]), uid, slot)
            if held and not affected and route_token is None:
                raise RuntimeError("待核路线与目标身份不匹配")
            if affected:
                if not a._location_hold.valid_marker:
                    raise RuntimeError("位置记录不可确认")
                with open(PATH, "rb") as f:
                    marker_hash = hashlib.sha256(f.read()).hexdigest()
            self._eject_lease = (idx, slot, transport)
            try:
                gate = self._eject_stop_ready(idx, slot, transport)
            except Exception as exc:
                a._latch_stop_fault(idx, slot, "initial stop unconfirmed: %s" % exc)
                raise
            check()
            if gate and affected:
                marker_hash = self._arm_eject_pending(marker_hash)
            while gate:
                check()
                self._eject_pending = object()
                token = self._eject_pending
                moving = True
                motion_start = a.reactor.monotonic()
                self._request(
                    idx, "unwind_filament",
                    {"index": slot, "length": MAX_MM, "speed": SPEED_MM_S},
                    8, monitor=check, eject_token=token,
                )
                self.state.update(message="正在高速退出 ACE，请稍候")
                seen_rollback = False
                while True:
                    check()
                    lanes = self._lane_states(idx, monitor=check)
                    if any(v != "ready" for i, v in lanes.items() if i != slot):
                        raise RuntimeError("其他槽状态异常")
                    target = lanes[slot]
                    if target not in ("ready", "rollback"):
                        raise RuntimeError("目标槽状态异常")
                    if target == "rollback":
                        seen_rollback = True
                    gate = self._gate(idx, slot, monitor=check)
                    if not gate or (target == "ready" and seen_rollback):
                        break
                    if not seen_rollback and a.reactor.monotonic() - motion_start > 5:
                        raise RuntimeError("未观察到退料启动")
                    a.reactor.pause(a.reactor.monotonic() + 0.1)
                gate = self._eject_stop_ready(idx, slot, transport, motion_start)
                moving = False
            check()
            if affected or route_token is not None:
                uid_end = self._request(idx, "discover_device", {}, 0, monitor=check)
                if tuple(uid_end.get("uid%d" % i) for i in (1, 2, 3)) != uid:
                    raise RuntimeError("ACE身份改变")
                if self._eject_stable(idx, slot, check):
                    raise RuntimeError("入口空状态未保持")
            self._commit_ejected(idx, slot, transport, uid, marker_hash, sources)
            if route_token is not None:
                try:
                    a._location_hold.release_route(str(a._ace_devices[idx]), uid, slot, route_token)
                except RouteChanged:
                    raise
                except Exception as exc:
                    a._latch_stop_fault(idx, slot, 'RFID position hold release could not be persisted: %s' % exc)
                    raise
            self.state.update(state="complete", message="耗材已退出 ACE 入口")
            logging.info("[multiACE] slot_eject seq=%d result=complete", self.state["seq"])
        except Exception as e:
            self.state.update(state="error", message=str(e))
            logging.info("[multiACE] slot_eject seq=%d result=error error=%s", self.state["seq"], str(e))
        finally:
            if moving:
                try:
                    self._eject_stop_ready(idx, slot, transport, motion_start)
                except Exception as e:
                    a._latch_stop_fault(
                        idx, slot, "stop stillness not confirmed: %s" % e
                    )
                    self.state.update(
                        state="error", message="停止未确认，请检查设备：%s" % e
                    )
            self._eject_pending = None
            self._eject_lease = None
            self._eject_sources = None
            a._swap_in_progress = False

def persist_rfid_position_uncertain(ace, idx, slot, identity=None, heads=None, scope="route"):
    port, uid = identity if identity is not None else ace._location_identity(idx)
    # Keep this route held in memory even if the durable write fails.
    ace._location_hold.hold_route(port, uid, slot, heads, scope)
    if (idx, slot) == (0, 3) and getattr(ace, '_normal_load_speed', None) is not None:
        ace._normal_load_speed.park = None


def supervise_rfid_motion(reader, actions, idx, slot, transport, motion_uncertain_type):
    """Interrupt only this web RFID reader's active moves; never guess restore."""
    reactor = actions.ace.reactor
    original_identity = actions.ace._location_identity(idx)
    original_heads = actions.ace._rfid_route_heads(idx, slot)
    original_scope = "ace" if getattr(actions.ace, "_ace_mode", None) != "multi" else "route"
    original_pause = reader._pause
    original_move = reader._move_and_confirm
    original_read = reader.read_slot
    handled = [False]
    active = [False]
    stopping = [False]
    stopped = [False]

    def stop_and_verify():
        if stopped[0]:
            return
        stopped[0] = True
        stopping[0] = True
        try:
            if actions.ace._serials.get(idx) is not transport or transport is None:
                raise RuntimeError('ACE transport changed; old motion stillness unknown')
            deadline = reactor.monotonic() + 8
            def monitor():
                if actions.ace._serials.get(idx) is not transport or reactor.monotonic() >= deadline:
                    raise RuntimeError('ACE transport changed or STOP verification timed out')
            actions._eject_stop(idx, slot, transport, monitor)
            monitor()
            actions._stable(idx, slot, monitor=monitor)
            if actions.ace._serials.get(idx) is not transport:
                raise RuntimeError('ACE transport changed during stillness check')
        except Exception as stop_exc:
            actions.ace._latch_stop_fault(idx, slot,
                'RFID stop or stillness unconfirmed: %s' % stop_exc)
            reader._motion_uncertain += '; STOP or stillness unconfirmed'
        finally:
            stopping[0] = False

    def guarded_pause(seconds):
        if not active[0] or stopping[0]:
            return original_pause(seconds)
        deadline = reactor.monotonic() + seconds
        while reactor.monotonic() < deadline:
            try:
                actions._check(idx, slot, transport, allow_tag=True)
            except Exception as exc:
                # Set before STOP: the reader's finally must never restore a
                # movement whose end position can no longer be inferred.
                reader._motion_uncertain = 'RFID motion interrupted: %s' % exc
                raise motion_uncertain_type(reader._motion_uncertain)
            original_pause(min(0.05, deadline - reactor.monotonic()))

    def guarded_move(*args, **kwargs):
        if (transport is None or actions.ace._serials.get(idx) is not transport
                or original_identity != actions.ace._location_identity(idx)
                or original_heads != actions.ace._rfid_route_heads(idx, slot)
                or not original_identity[0] or original_identity[1] is None):
            raise RuntimeError('RFID original route identity unavailable or changed')
        if (idx, slot) == (0, 3) and getattr(actions.ace, '_normal_load_speed', None) is not None:
            actions.ace._normal_load_speed.park = None
        active[0] = True
        stopped[0] = False
        try:
            return original_move(*args, **kwargs)
        except Exception as exc:
            if isinstance(exc, motion_uncertain_type) or reader._motion_uncertain:
                if not reader._motion_uncertain:
                    reader._motion_uncertain = 'RFID motion uncertain: %s' % exc
                handle_uncertain()
            raise
        finally:
            active[0] = False

    def handle_uncertain():
        if handled[0]: return
        handled[0] = True
        hold = actions.ace._location_hold
        route = None
        hold_error = None
        try:
            route = hold.hold_memory(original_identity[0], original_identity[1], slot, original_heads, original_scope)
            if (idx, slot) == (0, 3) and getattr(actions.ace, '_normal_load_speed', None) is not None:
                actions.ace._normal_load_speed.park = None
        except Exception as exc:
            hold_error = exc
        stop_and_verify()
        if hold_error is None:
            try:
                hold.persist_route(route)
            except Exception as exc:
                hold_error = exc
        if hold_error is not None:
            actions.ace._latch_stop_fault(idx, slot, 'RFID position hold could not be persisted: %s' % hold_error)

    def guarded_read(*args, **kwargs):
        try:
            return original_read(*args, **kwargs)
        except Exception as exc:
            if isinstance(exc, motion_uncertain_type) or reader._motion_uncertain:
                if not reader._motion_uncertain:
                    reader._motion_uncertain = 'RFID motion uncertain: %s' % exc
                handle_uncertain()
            raise

    reader._pause = guarded_pause
    reader._move_and_confirm = guarded_move
    reader.read_slot = guarded_read
