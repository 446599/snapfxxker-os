import os

# Host view of an ACE input gate (slot sensor), derived from the unit's
# status report. Shared by ace.py and its mixins.
GATE_UNKNOWN = -1
GATE_EMPTY = 0
GATE_AVAILABLE = 1

# Sensor reads: send_request_to never stamps the host-side 'busy' for
# these (the stamp is for MOTOR commands, held until the next status report
# shows the motion). Same content for every codec; the contract checker in
# tests/units/contract.py carries a frozen copy and a test keeps them equal.
TELEMETRY_METHODS = frozenset((
    'get_status', 'get_feed_info', 'get_filament_info', 'get_lane_state', 'get_key_state', 'discover_device',
    'filament_identify', 'filament_recognition', 'set_lanes'))

class AceProtocol(object):
    NAME = ''
    DEFAULT_BAUD = 0
    SERIAL_KWARGS = {}
    TELEMETRY_METHODS = TELEMETRY_METHODS
    # Static unit capabilities of this codec (ace_unit.caps_for merges them
    # with the firmware-derived ones). Keys and meaning: ace_unit.py.
    CAPS_STATIC = {}

    @staticmethod
    def _read_usb_ids(real_dev):
        """Return (vendor, product) lowercase-hex for a tty device name, or
        (None, None). Walks UP from /sys/class/tty/<dev>/device until
        idVendor/idProduct are found: they live on the USB *device* node,
        which is ONE level up for CDC-ACM (ttyACM, the genuine ACE cable) but
        TWO levels up for usb-serial adapters (ttyUSB: CH340/FTDI/CP210x
        insert an extra port node). A fixed 'device/..' only matched ttyACM,
        so a generic USB-RS485 adapter was silently dropped before the
        vid:pid check ran."""
        try:
            node = os.path.realpath('/sys/class/tty/%s/device' % real_dev)
        except OSError:
            return None, None
        for _ in range(8):
            try:
                vp = os.path.join(node, 'idVendor')
                pp = os.path.join(node, 'idProduct')
                if os.path.exists(vp) and os.path.exists(pp):
                    with open(vp, 'r') as f:
                        vendor = f.read().strip().lower()
                    with open(pp, 'r') as f:
                        product = f.read().strip().lower()
                    return vendor, product
            except (IOError, OSError):
                pass
            parent = os.path.dirname(node)
            if parent == node:
                break
            node = parent
        return None, None

    @classmethod
    def discover(cls):
        raise NotImplementedError

    @classmethod
    def open_transport(cls, path, baud, **kwargs):

        import serial
        merged = dict(cls.SERIAL_KWARGS)
        merged.update(kwargs)
        return serial.Serial(port=path, baudrate=baud, **merged)

    def encode_request(self, request, next_id=None):
        raise NotImplementedError

    def decode_frames(self, buffer):
        raise NotImplementedError

    def initial_handshake_requests(self):
        return [{'method': 'get_info'}]

    def make_default_info(self):
        raise NotImplementedError


"""Protocol-neutral evidence for existing slot operations, no new alarm codes."""
from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class LaneSample:
    present: bool
    state: str
    encoder: int
    motor: int
    stamp: tuple = ()


def accepted(reply):
    return (isinstance(reply, dict) and type(reply.get('code')) is int
            and reply['code'] == 0 and str(reply.get('msg', '')).strip().upper() != 'FORBIDDEN'
            and isinstance(reply.get('result'), dict))


def uid(reply):
    if not accepted(reply):
        return None
    values = tuple(reply['result'].get('uid%d' % n) for n in (1, 2, 3))
    return values if any(values) and all(type(v) is int and 0 <= v <= 0xffffffff for v in values) else None


def native_sample(sensors, feed, counters, fg, slot, now, *, after=None):
    """Use actual independent sensor/feed/encoder/tach reports, not cached ready.

    Counter units are native (micrometres and FG pulses); only compare
    samples from the same connection and driver. Missing data is None.
    """
    if type(slot) is not int or not 0 <= slot < 4:
        return None
    reports = (sensors, feed, counters, fg)
    if any(not isinstance(r, (tuple, list)) or len(r) != 2
           or type(r[0]) not in (int, float) or not isfinite(r[0])
           or not 0 <= now - r[0] <= 3.5 for r in reports):
        return None
    if after is not None and any(r[0] <= after for r in reports):
        return None
    if not isinstance(feed[1], dict):
        return None
    modes = feed[1].get('mode', ())
    if any(not isinstance(x, (tuple, list, bytes, bytearray)) or len(x) != 4
           for x in (modes, counters[1], fg[1])):
        return None
    states = {0: 'ready', 1: 'feeding', 2: 'rollback', 3: 'rollback',
              4: 'preloading', 5: 'assisting', 6: 'rollback_assisting',
              7: 'feed_error', 8: 'assisting'}
    if (type(modes[slot]) is not int or modes[slot] not in states
            or type(sensors[1]) is not int or not 0 <= sensors[1] <= 0xffff):
        return None
    enc, motor = counters[1][slot], fg[1][slot]
    if (type(enc) is not int or not -(2**31) <= enc < 2**31
            or type(motor) is not int or not 0 <= motor < 2**32):
        return None
    return LaneSample(bool(sensors[1] & (1 << slot)), states[modes[slot]], enc, motor,
                      tuple(r[0] for r in reports))


def stock_sample(status, gates, feed, slot):
    """V2 reports retain their real V2 validation; no manufactured fields."""
    if type(slot) is not int or not 0 <= slot < 4:
        return None
    if not all(accepted(r) for r in (status, gates, feed)):
        return None
    if not all(r.get('_v2_frame_valid') is True and r.get('_v2_payload_valid') is True
               and r.get('_v2_command') == cmd
               for r, cmd in zip((status, gates, feed), (6, 73, 76))):
        return None
    status, gates, feed = (r['result'] for r in (status, gates, feed))
    if status.get('_status_wire_valid') is not True or feed.get('_feed_wire_valid') is not True:
        return None
    slots, rows, fields = status.get('slots'), feed.get('feed_info'), gates.get('fields')
    if not isinstance(slots, list) or not isinstance(rows, list) or not isinstance(fields, dict):
        return None
    slots = [x for x in slots if isinstance(x, dict) and type(x.get('index')) is int and x['index'] == slot]
    rows = [x for x in rows if isinstance(x, dict) and type(x.get('index')) is int and x['index'] == slot]
    mask = fields.get('1')
    if len(slots) != 1 or len(rows) != 1 or type(mask) is not int or not 0 <= mask < 2**64:
        return None
    s, r = slots[0], rows[0]
    if s.get('_wire_valid') is not True or r.get('_wire_valid') is not True or r.get('_decoder_present') is not True:
        return None
    enc, motor = r.get('decoder'), r.get('steps')
    if type(enc) is not int or not 0 <= enc < 2**64 or type(motor) is not int or motor < 0:
        return None
    state = s.get('slot_status')
    if not isinstance(state, str) or not state or state == 'unknown':
        return None
    if enc >= 2**63:
        enc -= 2**64
    return LaneSample(bool(mask & (1 << (4 * slot))), state, enc, motor)


def still(previous, current):
    """Only a new native report can count as another observation of stillness."""
    if previous is None or current is None:
        return False
    if previous.stamp or current.stamp:
        if not previous.stamp or not current.stamp or len(previous.stamp) != len(current.stamp):
            return False
        if any(b <= a for a, b in zip(previous.stamp, current.stamp)):
            return False
    return (previous.present, previous.state, previous.encoder, previous.motor) == (
        current.present, current.state, current.encoder, current.motor) and current.state == 'ready'


from math import isfinite

def read_lane_sample(ace, idx, slot):
    """One shared read API. Caller owns motion and the selected connection."""
    if type(slot) is not int or not 0 <= slot < 4:
        return None
    transport = ace._serials.get(idx)
    protocol = getattr(ace._protocols.get(idx), 'NAME', '')
    if transport is None or not ace._connected_per_ace.get(idx):
        return None

    def same_connection():
        return (ace._serials.get(idx) is transport
                and ace._connected_per_ace.get(idx)
                and getattr(ace._protocols.get(idx), 'NAME', '') == protocol)

    def ask(method, params=None):
        if not same_connection():
            return None
        reply = ace._tipform_send(idx, {'method': method, 'params': params or {}}, timeout=2.0)
        return reply if same_connection() else None

    if protocol == 'ace2k':
        reply = ask('get_lane_state', {'index': slot})
        if not accepted(reply):
            return None
        r = reply['result']
        if type(r.get('index')) is not int or r['index'] != slot or type(r.get('present')) is not bool:
            return None
        if (type(r.get('encoder')) is not int or not -(2**31) <= r['encoder'] < 2**31
                or type(r.get('motor')) is not int or not 0 <= r['motor'] < 2**32
                or not isinstance(r.get('state'), str) or r['state'] not in (
                    'ready', 'feeding', 'rollback', 'preloading', 'assisting',
                    'rollback_assisting', 'feed_error')):
            return None
        stamp = r.get('stamp')
        if not isinstance(stamp, (tuple, list)) or len(stamp) != 4:
            return None
        if any(type(t) not in (int, float) or not isfinite(t) for t in stamp):
            return None
        return LaneSample(r['present'], r['state'], r['encoder'], r['motor'], tuple(stamp))
    if protocol == 'v2':
        status = ask('get_status')
        if not accepted(status):
            return None
        gates = ask('get_key_state')
        if not accepted(gates):
            return None
        return stock_sample(status, gates, ask('get_feed_info'), slot)
    return None
