import json
import logging
import os
import struct

from .ace_protocol import AceProtocol

V1_VENDOR_ID = '28e9'
V1_PRODUCT_ID = '018a'

FRAME_START = b'\xFF\xAA'
FRAME_END = 0xFE
MAX_PAYLOAD_LEN = 2048
MAX_REQUEST_LEN = 1024
HEADER_LEN = 4
TRAILER_LEN = 3
MIN_FRAME_LEN = HEADER_LEN + TRAILER_LEN
CRC_COLLISION = 0xAAFF

def calc_crc(buffer):
    crc = 0xFFFF
    for byte in buffer:
        data = byte
        data ^= crc & 0xFF
        data ^= (data & 0x0F) << 4
        crc = ((data << 8) | (crc >> 8)) ^ (data >> 4) ^ (data << 3)
    return crc

class AceProtocolV1(AceProtocol):
    NAME = 'v1'
    DEFAULT_BAUD = 115200
    # ACE Pro: open-loop unit, reader on the reactor thread, no per-slot
    # motion truth, no decoder, tag identity arrives inside the status.
    CAPS_STATIC = {
        'transport_engine': 'reactor_fd',
        'blocking_write_on_reactor': True,
        'reconnectable': True,
        'presence_sensor': True,
        'empty_token': 'empty1',
        'has_slot_status_truth': False,
        'busy_wait_floor': False,
        'fa_monitor': False,
        'needs_fa_prestop': False,
        'has_rollback_assist': False,
        'no_freewheel': False,
        'freewheel_print_mode': False,
        'locate_method': 'jog',
        'calibration_feed': 'chunked',
        'host_tag_session': False,
        'buffer_relax': False,
        'fa_stop_rollback': True,
        'self_stops_on_resistance': False,
        'has_decoder': False,
        'v1_fa_health_log': True,
        'tag_identity_in_status': True,
        'fw_tag_pair_dedupe': True,
        'has_humidity': False,
        'has_dryer': True,
        'has_exhaust_valve': False,
        'has_feed_check': False,
        'flash_engine': 'iap_v1',
        'v2_command_set': False,
        'lanes_concurrent': False,
        'speed_unit': 'mm_s',
        'busy_reply': 'code0_forbidden',
        'has_stable_id': False,
    }
    SERIAL_KWARGS = {
        'rtscts': True,
        'exclusive': True,
        'timeout': 0,
        'write_timeout': 0,
    }

    @classmethod
    def discover(cls):
        ace_devices = []
        by_path_dir = '/dev/serial/by-path/'
        if not os.path.exists(by_path_dir):
            return ace_devices
        for entry in sorted(os.listdir(by_path_dir)):
            full_path = os.path.join(by_path_dir, entry)
            real_dev = os.path.basename(os.path.realpath(full_path))
            vendor, product = cls._read_usb_ids(real_dev)
            if vendor is None:
                continue
            if vendor == V1_VENDOR_ID and product == V1_PRODUCT_ID:
                ace_devices.append(full_path)
        return ace_devices

    def encode_request(self, request, next_id=None):
        payload = json.dumps(request).encode('utf-8')
        if len(payload) > MAX_REQUEST_LEN:
            raise ValueError(
                'request payload too large: %d bytes' % len(payload))
        crc = calc_crc(payload)
        attempts = 0
        while crc == CRC_COLLISION and attempts < 10:
            if next_id is None:
                break
            request['id'] = next_id()
            payload = json.dumps(request).encode('utf-8')
            crc = calc_crc(payload)
            attempts += 1
        data = bytes([FRAME_START[0], FRAME_START[1]])
        data += struct.pack('<H', len(payload))
        data += payload
        data += struct.pack('<H', crc)
        data += bytes([FRAME_END])
        return data

    def decode_frames(self, buffer):
        results = []
        while len(buffer) >= MIN_FRAME_LEN:
            start = buffer.find(FRAME_START)
            if start < 0:
                if buffer.endswith(b'\xFF'):
                    del buffer[:-1]
                else:
                    del buffer[:]
                break
            if start > 0:
                del buffer[:start]
            if len(buffer) < HEADER_LEN:
                break
            payload_len = struct.unpack('<H', bytes(buffer[2:4]))[0]
            if payload_len > MAX_PAYLOAD_LEN:
                del buffer[:2]
                continue
            total_len = HEADER_LEN + payload_len + TRAILER_LEN
            if len(buffer) < total_len:
                break
            payload = bytes(buffer[HEADER_LEN:HEADER_LEN + payload_len])
            trailer = bytes(buffer[HEADER_LEN + payload_len:total_len])
            crc_rx = struct.unpack('<H', trailer[:2])[0]
            if crc_rx != calc_crc(payload) or trailer[2] != FRAME_END:
                # Corrupt frame: skip this start marker and resync on the
                # next one instead of parsing garbage.
                logging.info('[multiACE] V1 frame dropped: crc rx=%04x calc=%04x end=%02x'
                             % (crc_rx, calc_crc(payload), trailer[2]))
                del buffer[:2]
                continue
            del buffer[:total_len]
            try:
                ret = json.loads(payload.decode('utf-8'))
            except (json.decoder.JSONDecodeError, UnicodeDecodeError):
                logging.info('[multiACE] V1 invalid JSON/UTF-8 frame dropped')
                continue
            results.append(ret)
        return results

    def initial_handshake_requests(self):
        return [{'method': 'get_info'}]

    def make_default_info(self):
        return {
            'status': 'ready',
            'dryer_status': {
                'status': 'stop',
                'target_temp': 0,
                'duration': 0,
                'remain_time': 0,
                # An ACE Pro has no rotisserie and no flag bits; the keys
                # exist so a consumer never has to ask which protocol it
                # is looking at.
                'raw_status': 0,
                'rotisserie': False,
                'auto_roll_allowed': False,
            },
            'temp': 0,
            'enable_rfid': 1,
            'fan_speed': 7000,
            'feed_assist_count': 0,
            'cont_assist_time': 0.0,
            'slots': [
                {'index': i, 'status': 'empty1', 'sku': '', 'type': '',
                 'rfid': 0, 'brand': '', 'color': [0, 0, 0]}
                for i in range(4)
            ],
        }
