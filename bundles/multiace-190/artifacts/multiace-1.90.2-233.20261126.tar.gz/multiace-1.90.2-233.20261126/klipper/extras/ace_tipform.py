# multiACE: per-material tip-forming tables ([ace_tipform] config section).
#
# The stock tip form is the INNER_FILAMENT_UNLOAD macro; its actual pull
# moves live in CONTROL_RETRACT_ACTION (u1_firmware fluidd.cfg:687) - one
# fixed choreography for everything. This module makes ONLY that move step
# configurable per material; the frame around it (discard position, heat,
# cool+fan, ooze scrape-off, nozzle clean, discard) stays stock either way
# (the U1 has NO cutter - "CUTOFF" is a wipe against the discard edge). The
# background swap engine consumes the same tables (its built-in
# COLD_PULL_NORMAL/SOFT constants are the fallback).
#
# Section keys:
#   mode: stock | custom     'stock' (default) = the unchanged INNER macro.
#   default: <table>         fallback table for every material
#   soft: <table>            fallback for soft/flexible filament (SOFT=1)
#   <material>: <table>      per-material, key = filament type lowercased
#                            (pla, petg, abs, ...; free-form, e.g. petg_basf
#                            works if you declare that type on the slot)
#   <vendor>_<material>: <table>   per-vendor+material (optional axis). The
#                            vendor is the slot's declared BRAND lowercased,
#                            internal spaces -> '_' (e.g. 'prusament_pla',
#                            'prusa_research_petg'). Matches only when the slot
#                            carries a real brand (RFID/override); a generic/
#                            empty/NONE vendor falls through to <material>.
#
# Table = comma-separated tokens (Prusa-style ramming/cooling expressible):
#   <mm>@<feedrate>   extruder move, negative = retract, feedrate in mm/min
#   pause:<ms>        dwell
#   temp:<C>          set nozzle target (no wait)
#   waittemp:<C>      set target and WAIT until reached, both directions
#                     (SkinnyDip pattern; 100-350. In the bg path this waits
#                     passively - no fan on a parked head - so it is SLOW
#                     there; bounded, proceeds with a warning on timeout)
#   fan:<0-255>       part fan (inline path only; the bg engine skips it -
#                     a parked head's fan is not addressable there)
#   unloadtemp:<C>    NOT a step: extracted at parse time as the table's
#                     UNLOAD-TEMP parameter - the whole unload (heat,
#                     INNER TEMP= / custom-frame heat, probe pre-warm)
#                     runs at this temp for the table's material/vendor.
#                     Without it the unload runs at the DB unload temp
#                     when the DB gives one that differs from its load
#                     temp (firmware 2.1+), else at the load temp.
#                     Range 175-350 (pull moves need >
#                     min_extrude_temp). A table may consist of ONLY
#                     this token = stock pull choreography at a custom
#                     temp (e.g. 'pla: unloadtemp:220').
#   loadtemp:<C>      NOT a step either: the LOAD-TEMP parameter - load
#                     heat, seat press, phase3 verify and the bg load
#                     half run at this temp instead of the DB load temp
#                     (chain: tipform -> DB get_load_temp -> 250). Set
#                     to the print temp, the whole swap runs at one
#                     temperature and needs no reheat. The stuck-tip
#                     RETRY still escalates to the DB load temp, the
#                     hotter pull is what frees a stuck tip. Range
#                     175-350; 'pla: unloadtemp:220, loadtemp:220' is a
#                     valid param-only table (comma-separated!).
#   bgtemp:<C>        Parameter: the BACKGROUND load half (feed, grip,
#                     prime through the open dock) runs at this temp
#                     instead of loadtemp - purge strings into the bin
#                     may run hotter than the inline purge that can
#                     pause over the part. Without it: loadtemp. Range
#                     175-350.
#   bgprimespeed:<f>  Parameter: the feedrate (mm/min, like every move
#                     here) of the BACKGROUND prime through the open
#                     dock. Without it: [ace_bg_swap] prime_speed (4 mm/s
#                     = 240). 60-1200. Soft filament keeps its own slow
#                     prime whatever this says.
#   prime:<mm>[@<f>]  Parameter: a HOT PRE-PURGE right before the tip
#   primetemp:<C>     forms - heat to primetemp (default: loadtemp),
#                     push <mm> into the discard (inline) / through the
#                     dock (background), then cool to unloadtemp and
#                     pull. A tip formed from a freshly primed, hot melt
#                     zone is more reproducible than one formed from
#                     whatever the print left behind. The cool-down is
#                     passive (no fan on the unload path), budget the
#                     time. prime 1-200 mm (feedrate mm/min, default
#                     300), primetemp 175-350.
#
# Example (PETG with ramming + cooling moves):
#   [ace_tipform]
#   mode: custom
#   default: 57@400, 3@1500, -27@2700, -5.5@40, -37.5@1500
#   petg: 30@400, 0.7@1600, 0.7@2400, -27@2700, pause:200, 2@600, -2@600, -35@1500
#
# Per device: append '@<driver>' to any key (ace_v1, ace_v2, cfs), e.g.
#   pla@cfs: unloadtemp:215, loadtemp:220
# The row applies only to heads fed by a unit of that driver; the lookup
# tries the whole '@<driver>' chain first, then the plain chain.
#
# Lookup order: <vendor>_<material> -> <material> -> soft (when SOFT) ->
# default -> None (= stock macro inline / built-in table in the bg engine).
# A table with a NET push (sum of moves > 0) is refused at startup - the tip
# must end OUT of the melt zone or the next load jams.

import logging
import os
import re

TOKEN_MOVE = 'move'
TOKEN_PAUSE = 'pause'
TOKEN_TEMP = 'temp'
TOKEN_WAITTEMP = 'waittemp'
TOKEN_FAN = 'fan'

MAX_MOVE_MM = 200.
MAX_FEEDRATE = 6000.
MAX_PAUSE_MS = 60000.
MAX_TEMP = 350.
MIN_WAITTEMP = 100.
# Klipper hard-refuses extruder moves below min_extrude_temp (170) - a
# move AFTER a waittemp below this margin fails as 'custom gcode error'
# mid-unload. Reject it at parse time instead.
MIN_MOVE_TEMP = 175.
# bgprimespeed: (mm/min): 1-20 mm/s. The stock bg prime is 4 mm/s.
MIN_BG_PRIME_F = 60.
MAX_BG_PRIME_F = 1200.


def parse_table(raw):
    """Parse a table string into a token list:
    ('move', mm, feedrate) / ('pause', seconds) / ('temp', C) /
    ('waittemp', C) / ('fan', n).
    Raises ValueError with a user-readable message on any bad token."""
    tokens = []
    net = 0.
    unload_temp = None
    load_temp = None
    bg_temp = None
    bg_prime_f = None
    prime_temp = None
    prime_mm = None
    prime_f = 300.
    last_waittemp = None
    for part in str(raw).replace('\n', ',').split(','):
        part = part.strip()
        if not part:
            continue
        low = part.lower()
        if low.startswith('pause:'):
            ms = float(low.split(':', 1)[1])
            if not 0 <= ms <= MAX_PAUSE_MS:
                raise ValueError('pause out of range (0-%d ms): %r'
                                 % (int(MAX_PAUSE_MS), part))
            tokens.append((TOKEN_PAUSE, ms / 1000.))
        elif low.startswith('temp:'):
            c = float(low.split(':', 1)[1])
            if not 0 <= c <= MAX_TEMP:
                raise ValueError('temp out of range (0-%d C): %r'
                                 % (int(MAX_TEMP), part))
            tokens.append((TOKEN_TEMP, c))
        elif low.startswith('waittemp:'):
            # Set the target AND wait until the nozzle reaches it - BOTH
            # directions (the SkinnyDip pattern: drop for the toolchange,
            # dip cool, restore). Bounded below: waiting for a temperature
            # the hotend cannot passively reach would stall the unload.
            c = float(low.split(':', 1)[1])
            if not MIN_WAITTEMP <= c <= MAX_TEMP:
                raise ValueError('waittemp out of range (%d-%d C): %r'
                                 % (int(MIN_WAITTEMP), int(MAX_TEMP), part))
            tokens.append((TOKEN_WAITTEMP, c))
            last_waittemp = c
        elif low.startswith('fan:'):
            v = int(float(low.split(':', 1)[1]))
            if not 0 <= v <= 255:
                raise ValueError('fan out of range (0-255): %r' % part)
            tokens.append((TOKEN_FAN, v))
        elif low.startswith('unloadtemp:'):
            # Parameter, not a step (see the header note): extracted and
            # returned separately, never enters the token stream.
            c = float(low.split(':', 1)[1])
            if not MIN_MOVE_TEMP <= c <= MAX_TEMP:
                raise ValueError('unloadtemp out of range (%d-%d C): %r'
                                 % (int(MIN_MOVE_TEMP), int(MAX_TEMP), part))
            unload_temp = c
        elif low.startswith('loadtemp:'):
            # Parameter like unloadtemp: the load-side temp (load heat,
            # seat press, phase3, bg load half). Floor MIN_MOVE_TEMP -
            # phase3 extrudes.
            c = float(low.split(':', 1)[1])
            if not MIN_MOVE_TEMP <= c <= MAX_TEMP:
                raise ValueError('loadtemp out of range (%d-%d C): %r'
                                 % (int(MIN_MOVE_TEMP), int(MAX_TEMP), part))
            load_temp = c
        elif low.startswith('bgtemp:'):
            # Parameter: the background load half only (bg feed/grip/prime
            # through the open dock), else loadtemp.
            c = float(low.split(':', 1)[1])
            if not MIN_MOVE_TEMP <= c <= MAX_TEMP:
                raise ValueError('bgtemp out of range (%d-%d C): %r'
                                 % (int(MIN_MOVE_TEMP), int(MAX_TEMP), part))
            bg_temp = c
        elif low.startswith('bgprimespeed:'):
            # Parameter: feedrate (mm/min, the unit of every move token)
            # of the background prime through the open dock.
            f = float(low.split(':', 1)[1])
            if not MIN_BG_PRIME_F <= f <= MAX_BG_PRIME_F:
                raise ValueError('bgprimespeed out of range (%d-%d mm/min): '
                                 '%r' % (int(MIN_BG_PRIME_F),
                                         int(MAX_BG_PRIME_F), part))
            bg_prime_f = f
        elif low.startswith('primetemp:'):
            # Parameter pair with prime: temperature of the pre-purge.
            c = float(low.split(':', 1)[1])
            if not MIN_MOVE_TEMP <= c <= MAX_TEMP:
                raise ValueError('primetemp out of range (%d-%d C): %r'
                                 % (int(MIN_MOVE_TEMP), int(MAX_TEMP), part))
            prime_temp = c
        elif low.startswith('prime:'):
            # Parameter: hot pre-purge length before the tip forms,
            # optionally '@<feedrate>' (mm/min, default 300).
            body = low.split(':', 1)[1]
            if '@' in body:
                _mm, _f = body.split('@', 1)
                prime_f = float(_f)
                if not 0 < prime_f <= MAX_FEEDRATE:
                    raise ValueError('prime feedrate out of range '
                                     '(1-%d mm/min): %r'
                                     % (int(MAX_FEEDRATE), part))
            else:
                _mm = body
            v = float(_mm)
            if not 1. <= v <= 200.:
                raise ValueError('prime out of range (1-200 mm): %r' % part)
            prime_mm = v
        elif '@' in part:
            mm_s, f_s = part.split('@', 1)
            try:
                mm = float(mm_s)
                feedrate = float(f_s)
            except ValueError:
                raise ValueError('bad move token %r (expected '
                                 '<mm>@<feedrate>, comma-separated)' % part)
            if abs(mm) > MAX_MOVE_MM:
                raise ValueError('move too long (max %d mm): %r'
                                 % (int(MAX_MOVE_MM), part))
            if not 0 < feedrate <= MAX_FEEDRATE:
                raise ValueError('feedrate out of range (1-%d mm/min): %r'
                                 % (int(MAX_FEEDRATE), part))
            if last_waittemp is not None and last_waittemp < MIN_MOVE_TEMP:
                raise ValueError(
                    'move %r after waittemp:%d - Klipper refuses extruder '
                    'moves below min_extrude_temp (170); use waittemp >= '
                    '%d before further moves (true cold pulls below that '
                    'are not possible on the inline path)'
                    % (part, int(last_waittemp), int(MIN_MOVE_TEMP)))
            net += mm
            tokens.append((TOKEN_MOVE, mm, feedrate))
        else:
            raise ValueError("unrecognised token %r (expected mm@feedrate, "
                             "pause:ms, temp:C, waittemp:C, fan:0-255, "
                             "unloadtemp:C, loadtemp:C, bgtemp:C, "
                             "bgprimespeed:mm/min, prime:mm or "
                             "primetemp:C)"
                             % part)
    if tokens and not any(t[0] == TOKEN_MOVE for t in tokens):
        raise ValueError('table has no moves')
    if prime_temp is not None and prime_mm is None:
        raise ValueError('primetemp:%d needs a prime:<mm> length'
                         % int(prime_temp))
    if (not tokens and unload_temp is None and load_temp is None
            and bg_temp is None and bg_prime_f is None
            and prime_mm is None):
        raise ValueError('table has no moves')
    if net > 0.:
        raise ValueError('table pushes a NET %+.1f mm - the tip must end '
                         'retracted out of the melt zone' % net)
    prime = ((prime_temp, prime_mm, prime_f) if prime_mm is not None
             else None)
    return tokens, unload_temp, load_temp, bg_temp, prime, bg_prime_f


class AceTipform:
    def __init__(self, config):
        self.printer = config.get_printer()
        mode = config.get('mode', 'stock').strip().lower()
        if mode not in ('stock', 'custom'):
            raise config.error(
                "[ace_tipform] mode must be 'stock' or 'custom' (got %r)"
                % mode)
        self.tables = {}
        self.unload_temps = {}
        self.load_temps = {}
        self.bg_temps = {}
        self.bg_prime_speeds = {}
        self.primes = {}
        # Every option in the section is a table (keys are free-form
        # material names); read them ALL so Klipper's every-option-must-be-
        # accessed check never halts on a user-added material.
        items = [(opt, config.get(opt))
                 for opt in config.get_prefix_options('') if opt != 'mode']
        self._apply(mode, items)
        gcode = self.printer.lookup_object('gcode')
        gcode.register_command(
            'ACE_TIPFORM_RELOAD', self.cmd_ACE_TIPFORM_RELOAD,
            desc='[multiACE] Re-read the [ace_tipform] section from ace.cfg '
                 'and apply it live (no Klipper restart). Usage: '
                 'ACE_TIPFORM_RELOAD [FILE=<path>]')

    def _apply(self, mode, items):
        """Parse + swap the table state. Shared by startup and the live
        reload so both paths validate and degrade identically (a bad table
        is dropped LOUDLY, never a halt: validation rules evolve and a
        previously-saved table can turn invalid on an update; the web
        editor is the strict gate). Built into locals first, so a
        reload that dies mid-parse cannot leave half-swapped state."""
        tables, unload_temps, load_temps, bg_temps = {}, {}, {}, {}
        bg_prime_speeds = {}
        primes = {}
        dropped = []
        for opt, raw in items:
            try:
                (_toks, _utemp, _ltemp, _btemp, _prime,
                 _bgpf) = parse_table(raw)
                if _bgpf is not None:
                    bg_prime_speeds[opt.strip().lower()] = _bgpf
                if _prime is not None:
                    primes[opt.strip().lower()] = _prime
                if _toks:
                    tables[opt.strip().lower()] = _toks
                if _utemp is not None:
                    unload_temps[opt.strip().lower()] = _utemp
                if _ltemp is not None:
                    load_temps[opt.strip().lower()] = _ltemp
                if _btemp is not None:
                    bg_temps[opt.strip().lower()] = _btemp
            except ValueError as e:
                dropped.append(opt)
                logging.error('[multiACE] ace_tipform: table %r DISABLED '
                              '(falls back to stock): %s' % (opt, e))
        self.mode = mode
        self.tables = tables
        self.unload_temps = unload_temps
        self.load_temps = load_temps
        self.bg_temps = bg_temps
        self.bg_prime_speeds = bg_prime_speeds
        self.primes = primes
        logging.info('[multiACE] ace_tipform: mode=%s tables=%s '
                     'unload_temps=%s load_temps=%s bg_temps=%s '
                     'bg_prime_speeds=%s primes=%s'
                     % (self.mode, sorted(self.tables.keys()) or 'none',
                        sorted(self.unload_temps.keys()) or 'none',
                        sorted(self.load_temps.keys()) or 'none',
                        sorted(self.bg_temps.keys()) or 'none',
                        sorted(self.bg_prime_speeds.keys()) or 'none',
                        sorted(self.primes.keys()) or 'none'))
        if ((self.unload_temps or self.load_temps or self.bg_temps
                or self.bg_prime_speeds or self.primes)
                and self.mode != 'custom'):
            # A set-but-inert knob must be LOUD, never silently skipped.
            logging.error(
                "[multiACE] ace_tipform: unloadtemp/loadtemp set for %s but "
                "mode is 'stock' - IGNORED. Set 'mode: custom' to activate "
                "(choreography stays stock for param-only tables)."
                % sorted(set(self.unload_temps.keys())
                         | set(self.load_temps.keys())
                         | set(self.bg_temps.keys())
                         | set(self.bg_prime_speeds.keys())
                         | set(self.primes.keys())))
        return dropped

    def _default_cfg_path(self):
        # Same derivation as ace.py's mode-switch script lookup: ace.cfg
        # lives under the save_variables directory (printer_data/config),
        # in extended/. Hardcoded fallback = the fixed U1 path.
        try:
            sv = self.printer.lookup_object('save_variables', None)
            if sv is not None:
                cand = os.path.join(
                    os.path.dirname(os.path.abspath(sv.filename)),
                    'extended', 'ace.cfg')
                if os.path.exists(cand):
                    return cand
        except Exception:
            pass
        return '/home/lava/printer_data/config/extended/ace.cfg'

    @staticmethod
    def _parse_section_text(text):
        """Extract 'key: value' options of the [ace_tipform] section from
        raw cfg text. Line-based on purpose (no configparser: Klipper's
        dialect differs and a parse error here must never raise) - the web
        editor writes single-line 'key: value' options, which is all this
        needs to read back. Returns (mode, [(key, value)...], found)."""
        in_sec, found, mode, items = False, False, 'stock', []
        for line in text.splitlines():
            s = line.strip()
            if not s or s[0] in '#;':
                continue
            if s.startswith('['):
                in_sec = re.match(r'^\[\s*ace_tipform\s*\]', s) is not None
                found = found or in_sec
                continue
            if not in_sec:
                continue
            m = re.match(r'^([A-Za-z0-9_\-@]+)\s*[:=]\s*(.*)$', s)
            if not m:
                continue
            k, v = m.group(1).strip().lower(), m.group(2).strip()
            if k == 'mode':
                mode = v.lower()
            elif v:
                items.append((k, v))
        return mode, items, found

    def cmd_ACE_TIPFORM_RELOAD(self, gcmd):
        """Live re-read of the section, so a web tipform save applies
        without a Klipper restart, like the [ace] parameters. The web
        backend fires this after writing the cfg; on an older
        build without the command it degrades to the old restart hint."""
        path = gcmd.get('FILE', None) or self._default_cfg_path()
        try:
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
        except Exception as e:
            raise gcmd.error('[multiACE] tipform reload: cannot read %s: %s'
                             % (path, e))
        mode, items, found = self._parse_section_text(text)
        if not found:
            raise gcmd.error('[multiACE] tipform reload: no [ace_tipform] '
                             'section in %s' % path)
        if mode not in ('stock', 'custom'):
            raise gcmd.error("[multiACE] tipform reload: mode must be "
                             "'stock' or 'custom' (got %r) - nothing "
                             "changed" % mode)
        dropped = self._apply(mode, items)
        msg = ('[multiACE] tipform reloaded live: mode=%s, %d table(s)%s'
               % (self.mode,
                  len(set(self.tables) | set(self.unload_temps)
                      | set(self.load_temps) | set(self.bg_temps)
                      | set(self.bg_prime_speeds) | set(self.primes)),
                  (', DROPPED invalid: %s' % ', '.join(dropped))
                  if dropped else ''))
        gcmd.respond_info(msg)
        logging.info(msg)

    def _lookup(self, store, material, vendor=None, soft=False, device=None):
        """One value from `store` (tables or a parameter dict) for a
        (vendor, material, device), or None. Gated on mode: custom.

        Precedence per pass: '<vendor>_<material>' -> '<material>' ->
        'soft' (when SOFT) -> 'default'. With a device (driver name of the
        unit feeding the head: ace_v1, ace_v2, cfs) a first pass looks up
        the same chain with '@<device>' appended to every key, then the
        plain chain; a section without '@' keys behaves as before.
        Keys are CONSTRUCTED and checked for membership (never parsed
        back) - a missing/empty/generic vendor simply doesn't match and
        falls through to the plain material, so no vendor
        canonicalisation is needed. The vendor/material join is '_' (a
        space is invalid in a Klipper option name); the vendor part is
        lowercased and its internal spaces collapsed to '_' so
        'Prusament PLA' and 'Prusa Research' land on stable keys."""
        if self.mode != 'custom':
            return None
        mat = (material or '').strip().lower()
        ven = '_'.join((vendor or '').strip().lower().split())
        dev = (device or '').strip().lower()
        chain = []
        if mat and ven and ven not in ('none', 'generic'):
            chain.append('%s_%s' % (ven, mat))
        if mat:
            chain.append(mat)
        if soft:
            chain.append('soft')
        chain.append('default')
        keys = (['%s@%s' % (k, dev) for k in chain] if dev else []) + chain
        for k in keys:
            if k in store:
                return store[k]
        return None

    def table_for(self, material, vendor=None, soft=False, device=None):
        """The custom table for a (vendor, material, device), or None = use
        the stock path (INNER macro inline / built-in table in the bg
        engine). Precedence: see _lookup."""
        return self._lookup(self.tables, material, vendor, soft, device)

    def unload_temp_for(self, material, vendor=None, soft=False,
                        device=None):
        """The custom unload temp, or None = the unload runs at the DB
        unload temp (when it differs from the DB load temp) or the load
        temp. Same precedence and mode gate as table_for (the whole
        section is inert in mode: stock; a param-only table just means
        stock CHOREOGRAPHY at the custom temp)."""
        return self._lookup(self.unload_temps, material, vendor, soft, device)

    def load_temp_for(self, material, vendor=None, soft=False, device=None):
        """The custom LOAD temp, or None = fall through to the DB chain
        (get_load_temp -> 250)."""
        return self._lookup(self.load_temps, material, vendor, soft, device)

    def bg_temp_for(self, material, vendor=None, soft=False, device=None):
        """The custom BACKGROUND-load temp, or None = use loadtemp."""
        return self._lookup(self.bg_temps, material, vendor, soft, device)

    def prime_for(self, material, vendor=None, soft=False, device=None):
        """(primetemp or None, prime_mm, feedrate) of the hot pre-purge,
        or None = no pre-purge."""
        return self._lookup(self.primes, material, vendor, soft, device)

    def bg_prime_speed_for(self, material, vendor=None, soft=False,
                           device=None):
        """The custom BACKGROUND prime feedrate (mm/min), or None = use
        [ace_bg_swap] prime_speed. Same precedence and mode gate as
        bg_temp_for."""
        return self._lookup(self.bg_prime_speeds, material, vendor, soft,
                            device)

    def get_status(self, eventtime):
        # tables = UNION of move-tables and param-only (unloadtemp:/
        # loadtemp:) keys - the web's restart-pending banner compares cfg
        # keys against this list; a param-only entry missing here would
        # flag "restart pending" forever.
        return {
            'mode': self.mode,
            'tables': sorted(set(self.tables.keys())
                             | set(self.unload_temps.keys())
                             | set(self.load_temps.keys())
                             | set(self.bg_temps.keys())
                             | set(self.bg_prime_speeds.keys())
                             | set(self.primes.keys())),
            'unload_temps': dict(self.unload_temps),
            'load_temps': dict(self.load_temps),
            'bg_temps': dict(self.bg_temps),
            'bg_prime_speeds': dict(self.bg_prime_speeds),
            'primes': {k: list(v) for k, v in self.primes.items()},
        }


def load_config(config):
    return AceTipform(config)
