"""Monitor filament movement on the active ACE route during a print."""
import logging
import math

from .ace_flow_guard import raw_head_state, source_route


class PrintTangleMonitor:
    POLL_INTERVAL = 1.0
    RESPONSE_TIMEOUT = 3.0
    MAX_SAMPLE_GAP = 5.0
    DEFICIT_LIMIT_MM = 150.0

    def __init__(self, controller):
        self.controller = controller
        self.ace = controller.ace
        self.route = None
        self.pending = None
        self.pending_request = None
        self.started = None
        self.previous = None
        self.deficit = 0.0
        self.fault = None

    def cancel_pending(self):
        request = self.pending_request
        route = self.route
        self.pending = None
        self.pending_request = None
        if request is None or route is None or type(request.get('id')) is not int:
            return
        idx, transport = route[2], route[4]
        if self.ace._serials.get(idx) is not transport:
            return
        lock = getattr(self.ace, '_cb_locks', {}).get(idx)
        callbacks = getattr(self.ace, '_callback_maps', {}).get(idx, {})
        if lock is None:
            callbacks.pop(request['id'], None)
        else:
            with lock:
                callbacks.pop(request['id'], None)

    def reset(self):
        self.cancel_pending()
        self.route = None
        self.pending = None
        self.started = None
        self.previous = None
        self.deficit = 0.0
        self.fault = None

    def current_route(self):
        a, controller = self.ace, self.controller
        if (controller.sd is None or controller.sd.current_file is None
                or controller.sd.must_pause_work or not a._is_actively_printing()
                or a._fa_context != 'print' or a._swap_in_progress
                or a._pickcheck_active or a._v2_active_rev_assist):
            return None
        head = controller.active_head()
        source = a._head_source.get(head)
        route = source_route(source)
        if route is None or not controller.manages(head, source):
            return None
        idx, slot = route
        if (not controller.online(idx) or not controller.accepted(idx, slot)
                or not a._source_insertion_matches(source, idx, slot)
                or raw_head_state(a, head) is not True):
            return None
        transport = a._serials[idx]
        identity = a._location_identity(idx)
        return (controller.sd.current_file, head, idx, slot, transport, identity,
                source.get('insert_epoch'), a.toolhead.get_extruder())

    def fault_is_current(self):
        route = self.fault
        if route is None:
            return False
        a, controller = self.ace, self.controller
        if (controller.sd is None or controller.sd.current_file is not route[0]
                or controller.sd.must_pause_work or not a._is_actively_printing()
                or controller.active_head() != route[1] or a._swap_in_progress):
            return False
        source = a._head_source.get(route[1])
        return (source_route(source) == route[2:4]
                and a._serials.get(route[2]) is route[4]
                and a._location_identity(route[2]) == route[5]
                and source.get('insert_epoch') == route[6]
                and a._source_insertion_matches(source, route[2], route[3]))

    def position(self, extruder):
        a = self.ace
        now = a.reactor.monotonic()
        print_time = a.printer.lookup_object('mcu').estimated_print_time(now)
        value = extruder.find_past_position(print_time)
        if not math.isfinite(value):
            raise ValueError('invalid extruder position')
        return value

    def tick(self, eventtime):
        a = self.ace
        try:
            if self.fault is not None:
                if self.fault_is_current():
                    return eventtime + self.POLL_INTERVAL
                self.reset()
            route = self.current_route()
            if route is None:
                self.reset()
                return eventtime + self.POLL_INTERVAL
            if route != self.route:
                self.reset()
                self.route = route
            if self.fault is not None:
                return eventtime + self.POLL_INTERVAL
            if self.pending is not None:
                if eventtime - self.started < self.RESPONSE_TIMEOUT:
                    return eventtime + self.POLL_INTERVAL
                self.cancel_pending()
                self.previous = None
                self.deficit = 0.0

            marker = object()
            self.pending, self.started = marker, eventtime
            request = {'method': 'get_feed_info'}
            self.pending_request = request
            idx, slot = route[2], route[3]

            def callback(*args, **kwargs):
                if self.pending is not marker:
                    return
                self.pending = None
                self.pending_request = None
                try:
                    response = kwargs.get('response', args[-1] if args else None)
                    if (self.current_route() != route or not isinstance(response, dict)
                            or type(request.get('id')) is not int
                            or response.get('id') != request['id']
                            or response.get('code') != 0 or response.get('_v2_command') != 76
                            or response.get('_v2_frame_valid') is not True
                            or response.get('_v2_payload_valid') is not True):
                        self.previous = None
                        self.deficit = 0.0
                        return
                    result = response.get('result') or {}
                    rows = [row for row in result.get('feed_info', [])
                            if isinstance(row, dict) and row.get('index') == slot]
                    if (result.get('_feed_wire_valid') is not True or len(rows) != 1
                            or rows[0].get('_wire_valid') is not True
                            or rows[0].get('_decoder_present') is not True
                            or any(type(rows[0].get(name)) is not int
                                   or not 0 <= rows[0][name] < (1 << 64)
                                   for name in ('decoder', 'length', 'steps'))):
                        self.previous = None
                        self.deficit = 0.0
                        return
                    raw = rows[0]['decoder']
                    decoder = raw - (1 << 64) if raw >= (1 << 63) else raw
                    self.observe(route, a.reactor.monotonic(), self.position(route[7]),
                                 decoder, rows[0]['length'], rows[0]['steps'])
                except Exception:
                    self.previous = None
                    self.deficit = 0.0
                    logging.exception('[multiACE] 打结监测采样失败')

            if a.send_request_to(idx, request, callback) is False:
                self.cancel_pending()
                self.previous = None
                self.deficit = 0.0
        except Exception:
            self.reset()
            logging.exception('[multiACE] 打结监测暂不可用')
        return eventtime + self.POLL_INTERVAL

    def observe(self, route, now, extruder, decoder, motor_length, steps):
        previous = self.previous
        self.previous = (now, extruder, decoder, motor_length, steps)
        if previous is None:
            return
        elapsed = now - previous[0]
        extruded = extruder - previous[1]
        travelled = abs(decoder - previous[2])
        if motor_length < previous[3] or steps < previous[4]:
            # Counters reset at the beginning of each ACE motor operation.
            # The unobserved part of this interval is not movement evidence.
            return
        if (elapsed <= 0 or elapsed > self.MAX_SAMPLE_GAP
                or abs(extruded) > 100 * elapsed + 20
                or travelled > 100 * elapsed + 20):
            self.deficit = 0.0
            return
        # Assist may feed ahead into its buffer. Keep that credit so the
        # following extrusion is not mistaken for missing filament.
        self.deficit = max(-self.DEFICIT_LIMIT_MM, self.deficit + extruded - travelled)
        if self.deficit >= self.DEFICIT_LIMIT_MM:
            self.fault = route
            logging.warning('[multiACE] ACE %d 槽 %d 耗材走料不足 %.1f mm，准备暂停',
                            route[2] + 1, route[3] + 1, self.deficit)

    def check_move(self, gcmd, head, idx, slot):
        if self.fault is None:
            return
        if not self.fault_is_current() or self.fault[1:4] != (head, idx, slot):
            self.reset()
            return
        job = self.fault[0]
        self.fault = None
        self.deficit = 0.0
        detail = ('[multiACE] 喷头 %d · ACE %d 槽 %d 耗材走料不足，请检查料盘是否打结或卡住'
                  % (head + 1, idx + 1, slot + 1))
        stop_error = self.controller.stop_failed_assist(job, head, idx, slot)
        if stop_error:
            detail += '；' + stop_error
        raise gcmd.error(message=detail[:400], action='pause', id=525, index=head,
                         code=210, oneshot=1, level=2)
