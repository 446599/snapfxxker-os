"""Bounded short grip from a fresh inlet edge, followed by optional RFID."""
import logging
import math
import secrets
import struct
import threading
from .ace_filament_options import FilamentOptions, SCAN_MM, GRIP_MM, GRIP_SPEED
from .ace_v2_standstill import DECODER_UNAVAILABLE_REASONS, stop_and_verify
from .ace_flow_guard import dynamic_route_blocked, raw_head_state, source_route
from contextlib import contextmanager

FIRMWARE = 'V1.2.00O'
# Klipper can report roundoff from the endpoint of a completed move.
STOPPED_VELOCITY_EPSILON = 1e-6
REFRESH_EDGE_SECONDS = 30.0
METHODS = {'insert_policy_query': 0, 'insert_policy_set': 1,
           'insert_policy_start': 2, 'insert_policy_discard': 3}

class NoMotion(RuntimeError):
    """The writer or a validated MCU response proved START was not accepted."""


def encode(method, params):
    op = METHODS[method]
    slot, enabled = params.get('index', 0), params.get('enabled', True)
    session, epoch = params.get('session', 0), params.get('epoch', 0)
    expected, revision = params.get('expected_session', 0), params.get('revision', 0)
    if type(slot) is not int or not 0 <= slot < 4 or type(enabled) is not bool:
        raise ValueError('invalid insertion policy')
    if any(type(v) is not int or not 0 <= v <= 0xffffffff for v in (session, epoch, expected, revision)):
        raise ValueError('invalid insertion identity')
    return struct.pack('<4sBBBBIIII', b'AIP1', 1, op, slot, int(enabled), session, epoch, expected, revision)


def decode(payload):
    if not isinstance(payload, bytes) or len(payload) != 48:
        raise ValueError('invalid insertion reply length')
    magic, version, code, configured, enabled, session, park = struct.unpack_from('<4sBBBBII', payload)
    epochs = list(struct.unpack_from('<4I', payload, 16))
    pending, results = list(payload[32:36]), list(payload[36:40])
    if (magic != b'AIR1' or version != 1 or code > 6 or configured > 1 or enabled > 1
            or park != 400 or any(v > 1 for v in pending) or any(v > 6 for v in results)
            or struct.unpack_from('<I', payload, 44)[0] != 0x20261114
            or (configured and not session)):
        raise ValueError('invalid insertion reply')
    return {'code': code, 'configured': bool(configured), 'enabled': bool(enabled),
            'session': session, 'park_mm': park, 'epochs': epochs, 'pending': pending, 'results': results,
            'revision': struct.unpack_from('<I', payload, 40)[0]}


class InsertPolicy:
    def __init__(self, ace, config):
        self.ace = ace
        # Consume the legacy Klipper option without treating it as consent.
        config.getboolean('auto_insert_rfid', False)
        self.options = FilamentOptions(ace, ace.paths['config_dir'] +
                                      '/persistent/multiace-advanced-filament.json')
        self.units = {}
        self.changing = False
        self.polling = False
        self.active = None
        self.owner = None
        self.gate_events = {}
        self.pause_empty = {}
        self.pause_events = {}
        self.pause_tainted = set()
        self.paused_since = None
        self.paused_motion_since = None
        self.pause_mutex = None
        self.paused_grip_unconfirmed = None
        self.scan_origins = {}
        self.wire_lock = threading.Lock()
        self.timer = None
        ace.gcode.register_command('ACE_SET_AUTO_INSERT_RFID', self.set_command,
            desc='Enable optional RFID after explicit Y-clearance confirmation; default is a 100 mm grip.')
        ace.gcode.register_command('ACE_SET_INSERT_RFID_AUTO', self.set_auto_command,
            desc='Toggle only RFID on the next insertion; manual RFID remains available.')
        ace.gcode.register_command('ACE_SET_REMAINING_ESTIMATE', self.remaining_command,
            desc='Enable optional remaining estimate after Y-clearance confirmation.')
        ace.printer.register_event_handler('klippy:ready', self.ready)

    @property
    def enabled(self):
        return self.options.enabled('rfid')

    def ready(self):
        self.timer = self.ace.reactor.register_timer(self.tick, self.ace.reactor.monotonic() + 1)

    def capable(self, idx):
        return str((self.ace._ace_models.get(idx) or ('', ''))[1]).upper() in (FIRMWARE, 'V1.2.01O', 'V1.2.03O', 'V1.2.04O')

    def bypass(self, idx):
        return self.changing or self.capable(idx)

    def busy(self):
        a = self.ace
        ps = a.printer.lookup_object('print_stats', None)
        return (ps is None or getattr(ps, 'state', '').lower() not in ('standby', 'complete', 'cancelled')
            or a._swap_in_progress or a._unload_all_active or getattr(a, '_tag_read_busy', False)
            or a._slot_actions.state.get('state') in ('preparing', 'running')
            or bool(getattr(a, '_insert_read_running', set()))
            or bool(getattr(a, '_insert_abort_running', set()))
            or getattr(getattr(a, '_path_calibration', None), 'task', {}).get('active', False))

    @contextmanager
    def claim(self, kind, idx=None, slot=None, paused_grip=False, paused_sync=False):
        """Claim the same gate as manual RFID/eject before the first reactor yield."""
        a, actions = self.ace, self.ace._slot_actions
        if self.owner is not None or (not (paused_grip or paused_sync) and self.busy()):
            raise RuntimeError('请等待当前打印或料槽动作结束')
        if paused_grip and (kind != 'insert' or not self._paused_safe(idx, slot)):
            raise RuntimeError('暂停期间料路或设备尚未安全停稳')
        if paused_sync and (kind != 'insert_policy' or self.pause_mutex is None
                            or not self.pause_mutex.test() or not self._pause_stable()):
            raise RuntimeError('暂停状态已变化，等待同步插料设置')
        previous_action = actions.state
        actions.seq += 1
        token = {'seq': actions.seq, 'kind': kind, 'idx': idx, 'slot': slot,
                 'paused_grip': paused_grip, 'paused_sync': paused_sync}
        self.owner = token
        actions.cancel = False
        actions.state = {'seq': actions.seq, 'state': 'running', 'kind': kind,
                         'ace': idx, 'slot': slot, 'progress': 0, 'limit': GRIP_MM,
                         'message': '正在同步插料设置' if kind == 'insert_policy' else '正在抓取耗材'}
        a._swap_in_progress = True
        try:
            yield token
            if actions.state.get('state') == 'running':
                actions.state.update(state='complete', progress=100)
        except Exception as exc:
            cancelled = actions.cancel and (kind != 'insert' or actions.state.get('stop_confirmed'))
            actions.state.update(state='cancelled' if cancelled else 'error',
                                 message='已停止插料' if cancelled and kind == 'insert' else str(exc))
            raise
        finally:
            if (kind == 'insert_policy' and actions.state.get('seq') == token['seq']
                    and (paused_sync or previous_action.get('kind') in ('recover', 'eject'))):
                actions.state = previous_action
            self.owner = None
            a._swap_in_progress = False

    def connected(self, idx, entry):
        a = self.ace
        if (not a._connected_per_ace.get(idx) or a._serials.get(idx) is not entry['transport']
                or a._location_identity(idx) != entry['identity']):
            raise RuntimeError('ACE 连接或身份已变化')

    def owned(self, idx, entry, allow_cancel=False):
        self.connected(idx, entry)
        actions = self.ace._slot_actions
        if (self.owner is None or actions.state.get('seq') != self.owner['seq']
                or actions.state.get('kind') != self.owner['kind'] or (actions.cancel and not allow_cancel)):
            raise RuntimeError('插料操作已停止或发生变化')

    def unit(self, idx):
        a = self.ace
        transport, identity = a._serials.get(idx), a._location_identity(idx)
        if transport is None or identity[1] is None or not a._connected_per_ace.get(idx):
            raise RuntimeError('ACE 身份或连接未确认')
        entry = self.units.get(idx)
        if entry is None or entry['transport'] is not transport or entry['identity'] != identity:
            entry = {'transport': transport, 'identity': identity, 'session': secrets.randbits(32) or 1,
                     'snapshot': None, 'epochs': None, 'applied': None, 'error': ''}
            self.units[idx] = entry
        return entry

    def request(self, idx, method, entry, slot=0, epoch=0, enabled=None, token=None,
                expected_session=0, revision=0, cleanup=False):
        a = self.ace
        if cleanup and method != 'insert_policy_discard': raise ValueError('invalid cleanup operation')
        check = (lambda: self.connected(idx, entry)) if method == 'insert_policy_query' else (lambda: self.owned(idx, entry, cleanup))
        check()
        request = {'method': method, 'params': {'index': slot, 'epoch': epoch,
            'session': entry['session'], 'enabled': False,
            'expected_session': expected_session, 'revision': revision},
            '_insert_stop_transport': entry['transport']}
        box = []
        def callback(self, response):
            box.append(response)
        request['_insert_reject'] = callback
        if method != 'insert_policy_query': request['_insert_policy_owner'] = self.owner
        if cleanup: request['_insert_policy_cleanup'] = True
        if token is not None: request['_insert_policy_token'] = token
        try:
            a.send_request_to(idx, request, callback)
            deadline = a.reactor.monotonic() + 2.0
            while not box and a.reactor.monotonic() < deadline:
                check()
                a.reactor.pause(min(deadline, a.reactor.monotonic() + .05))
            check()
        except Exception:
            if token is not None:
                with self.wire_lock:
                    token['revoked'] = True
                    if not token.get('wire_attempted'): raise NoMotion('插料在发送前取消')
            raise
        reply = box[0] if box else None
        if reply is None and token is not None:
            with self.wire_lock:
                token['revoked'] = True
                if not token.get('wire_attempted'): raise NoMotion('插料排队已超时，未发送送料指令')
        if method == 'insert_policy_start' and isinstance(reply, dict):
            if (reply.get('_insert_invalidated') is True or reply.get('_host_stop_fault') is True
                    or reply.get('_location_hold') is True):
                raise NoMotion('插料在发送前被拦截')
            if (reply.get('_v2_frame_valid') is True and reply.get('_v2_payload_valid') is True
                    and reply.get('_v2_command') == 93 and type(reply.get('code')) is int
                    and 1 <= reply['code'] <= 5):
                raise NoMotion('插料事件已过期或设备未接受，请重新插料')
        if (not isinstance(reply, dict) or reply.get('_v2_frame_valid') is not True
                or reply.get('_v2_payload_valid') is not True or reply.get('_v2_command') != 93
                or type(reply.get('code')) is not int or reply['code'] != 0):
            if isinstance(reply, dict):
                logging.debug('[multiACE] ACE %d %s response rejected: %s', idx + 1, method,
                              reply.get('msg') or reply.get('code'))
            raise RuntimeError('ACE 插料设置响应未确认')
        result = reply.get('result', {}).get('insert_policy')
        if not isinstance(result, dict): raise RuntimeError('ACE 插料设置数据缺失')
        entry['snapshot'] = result
        return result

    def apply_unit(self, idx, enabled=False):
        # Always suppress native long pull-in; optional scans are host-bounded.
        enabled = False
        a, entry = self.ace, self.unit(idx)
        snapshot = self.request(idx, 'insert_policy_query', entry)
        self.observe(idx, entry, snapshot)
        if (snapshot['configured'] and snapshot['session'] == entry['session']
                and snapshot['enabled'] == enabled and entry['applied'] == enabled):
            self.reconcile_loaded_sources(idx, snapshot, snapshot)
            entry['error'] = ''
            return snapshot
        entry['applied'] = None
        monitor = lambda: self.owned(idx, entry)
        lanes = a._slot_actions._lane_states(idx, monitor=monitor)
        if any(value != 'ready' for value in lanes.values()):
            # Preserve continuous source identity without touching the ACE's
            # settings while a firmware fault still owns a lane.
            self.reconcile_loaded_sources(idx, snapshot, snapshot, lanes)
            raise RuntimeError('ACE 存在未就绪料槽，请等待料槽恢复')
        # RF enable belongs to the two paired readers. Raw manual RC522 access
        # remains available while the native background readers are disabled.
        for slot in (0, 2):
            a._slot_actions._request(idx, 'set_rfid_enable', {'index': slot, 'enable': enabled}, 14,
                                     monitor=monitor, stop_transport=entry['transport'], policy_token=self.owner)
        result = self.request(idx, 'insert_policy_set', entry, enabled=enabled,
                              expected_session=snapshot['session'], revision=snapshot['revision'])
        if not result['configured'] or result['session'] != entry['session'] or result['enabled'] != enabled:
            raise RuntimeError('ACE 未应用插料设置')
        self.observe(idx, entry, result)
        self.reconcile_loaded_sources(idx, snapshot, result, lanes)
        entry['applied'], entry['error'] = enabled, ''
        return result

    def reconcile_loaded_sources(self, idx, before, after, lanes=None):
        """Keep loaded routes across a host restart when the ACE proves continuity."""
        a = self.ace
        sources = getattr(a, '_head_source', {})
        if not sources or not after['configured']:
            return
        if lanes is None:
            rows = (a._info_per_ace.get(idx) or {}).get('slots') or ()
            lanes = {row.get('index', slot): row.get('slot_status')
                     for slot, row in enumerate(rows)}
        identity = a._rfid_identity_status(idx)
        gates = a._gate_status_per_ace.get(idx) or []
        changes = {}
        restored = []
        for head, source in sources.items():
            route = source_route(source)
            if route is None or route[0] != idx or source.get('load_failed') is not False:
                continue
            _, slot = route
            ready = lanes.get(slot) == 'ready'
            guard = getattr(a, '_stop_guard', None)
            if not ready and lanes.get(slot) == 'assist_error' and guard is not None:
                _, faults = guard.recovery_snapshot()
                local = [f for f in faults if (f['ace_idx'], f['slot']) == route]
                ready = all(f['reason'] in DECODER_UNAVAILABLE_REASONS for f in local)
            if (identity is None or source.get('connection_identity') != identity
                    or head not in (a._rfid_route_heads(idx, slot) or ())
                    or any(other_head != head and source_route(other) == route
                           for other_head, other in sources.items())
                    or slot >= len(gates) or gates[slot] != 1 or not ready
                    or before['epochs'][slot] != after['epochs'][slot]
                    or before['pending'][slot] or after['pending'][slot]
                    or raw_head_state(a, head) is not True
                    or dynamic_route_blocked(a, head=head, idx=idx, slot=slot)):
                continue
            # Restoring source identity does not release the independent STOP
            # guard. Its recovery needs the original source in the new session.
            update = dict(source)
            if not a._source_insertion_matches(source, idx, slot):
                proof = {'session': before['session'], 'epoch': before['epochs'][slot]}
                if (not before['configured'] or not before['session']
                        or source.get('insert_session') == a._insert_session
                        or source.get('ace_insertion') != proof):
                    continue
                update.update(a._capture_source_origin(idx, slot))
                restored.append(head)
            update['ace_insertion'] = {'session': after['session'], 'epoch': after['epochs'][slot]}
            if update != source:
                changes[head] = update
        if not changes:
            return
        originals = {head: sources[head] for head in changes}
        sources.update(changes)
        try:
            a._save_head_source()
        except Exception:
            sources.update(originals)
            raise
        for head in restored:
            logging.info('[multiACE] retained loaded head %d across host restart; ACE insertion unchanged',
                         head + 1)

    def set_command(self, gcmd):
        self._set_option(gcmd, 'rfid')

    def remaining_command(self, gcmd):
        self._set_option(gcmd, 'remaining')

    def set_auto_command(self, gcmd):
        enabled = bool(gcmd.get_int('ENABLE', minval=0, maxval=1))
        try:
            self.options.set_auto(enabled)
        except (OSError, ValueError) as exc:
            raise gcmd.error(str(exc))
        gcmd.respond_info('插料后自动识别设置已保存；下次插料生效')

    def _set_option(self, gcmd, feature):
        enabled = bool(gcmd.get_int('ENABLE', minval=0, maxval=1))
        confirmed = gcmd.get_int('CONFIRM_Y', 0, minval=0, maxval=1) == 1
        clearance = gcmd.get_int('CLEARANCE_MM', 0, minval=0, maxval=20000)
        if self.changing or self.busy():
            raise gcmd.error('请等待当前打印或料槽动作结束')
        indices = [i for i, connected in self.ace._connected_per_ace.items() if connected]
        if enabled and not any(self.capable(i) for i in indices):
            raise gcmd.error('至少需要一台支持短吸模式的在线 ACE')
        self.changing = True
        try:
            with self.claim('insert_policy'):
                # Synchronization never enables the MCU's native long movement.
                for idx in indices:
                    if self.capable(idx):
                        self.apply_unit(idx)
                self.options.update(feature, enabled, clearance, confirmed)
                self.ace._insert_read_queue = []
            gcmd.respond_info('耗材高级选项已保存；下次插料生效')
        except Exception as exc:
            raise gcmd.error(str(exc))
        finally:
            self.changing = False

    def invalidate(self, idx, slot, *, insertion_changed):
        a, key = self.ace, (idx, slot)
        with self.wire_lock:
            self.scan_origins.pop(key, None)
        a._v2_filament_info_per_ace.get(idx, {}).pop(slot, None)
        for name in ('_rc_last_uid', '_rc_last_fmt', '_insert_native_pending', '_single_verified_uid'):
            getattr(a, name, {}).pop(key, None)
        for name in ('_v2_filament_info_pending', '_v2_filament_info_empty'):
            getattr(a, name, {}).get(idx, {}).pop(slot, None)
        if insertion_changed:
            epochs = getattr(a, '_insert_epochs', None)
            if epochs is None: epochs = a._insert_epochs = {}
            epochs[key] = epochs.get(key, 0) + 1
        a._persist_tag_reads()

    def observe(self, idx, entry, snapshot):
        previous = entry['epochs']
        for slot in range(4):
            if previous is not None and previous[slot] != snapshot['epochs'][slot]:
                travel = getattr(self.ace, '_head_travel', None)
                if travel is not None:
                    travel.reset_route(idx, slot)
            if previous is None or previous[slot] != snapshot['epochs'][slot]:
                # The first report establishes the baseline. Clear cached tag
                # reads, but count an insertion change only against a prior report.
                self.invalidate(idx, slot, insertion_changed=previous is not None)
        entry['epochs'] = list(snapshot['epochs'])

    def _gate_context(self, idx, slot):
        a = self.ace
        return (a._serials.get(idx), a._location_identity(idx), a._ace_mode,
                tuple(a._rfid_route_heads(idx, slot) or ()), a._gen1_gate_gen.get((idx, slot)))

    def _refresh_proof_valid(self, idx, slot, entry, proof):
        """RAM-only physical evidence; MCU pending bits are never insertion consent."""
        ps = self.ace.printer.lookup_object('print_stats', None)
        state = getattr(ps, 'state', '').lower()
        return (self.units.get(idx) is entry
                and self.ace._connected_per_ace.get(idx) is True
                and entry['transport'] is self.ace._serials.get(idx)
                and entry['identity'] == self.ace._location_identity(idx)
                and proof['session'] == entry['session']
                and proof['context'] == self._gate_context(idx, slot)
                and state == proof['state']
                and state in ('standby', 'complete', 'cancelled', 'paused')
                and (state != 'paused' or self._pause_stable())
                and 0 <= self.ace.reactor.monotonic() - proof['at'] <= REFRESH_EDGE_SECONDS)

    def _discard_refresh_edge(self, idx, slot):
        entry = self.units.get(idx, {})
        entry.get('refresh_drops', {}).pop(slot, None)
        proof = entry.get('refresh_edges', {}).pop(slot, None)
        if proof is not None and self.gate_events.get((idx, slot)) == proof['context']:
            self.gate_events.pop((idx, slot), None)
            self.pause_events.pop((idx, slot), None)

    def _prune_refresh_edges(self):
        for idx, entry in self.units.items():
            for name in ('refresh_drops', 'refresh_edges'):
                for slot, proof in list(entry.get(name, {}).items()):
                    if not self._refresh_proof_valid(idx, slot, entry, proof):
                        self._discard_refresh_edge(idx, slot)

    def _refresh_gate_changed(self, idx, slot, before, after, transport, valid, entry, ctx):
        if entry is None:
            return
        previous = entry.get('refresh_drops', {}).pop(slot, None)
        self._discard_refresh_edge(idx, slot)
        ps = self.ace.printer.lookup_object('print_stats', None)
        state = getattr(ps, 'state', '').lower()
        if (valid is not True or type(before) is not int or type(after) is not int
                or entry.get('snapshot') is None or entry['transport'] is not transport
                or transport is not self.ace._serials.get(idx)
                or entry['identity'] != self.ace._location_identity(idx)
                or state not in ('standby', 'complete', 'cancelled', 'paused')
                or (state == 'paused' and not self._pause_stable())):
            return
        now = self.ace.reactor.monotonic()
        if before == 1 and after == 0 and entry['applied'] is None:
            entry.setdefault('refresh_drops', {})[slot] = {
                'context': ctx, 'at': now, 'state': state,
                'session': entry['session'], 'samples': 0}
        elif (before == 0 and after == 1 and previous is not None
                and previous['state'] == state and previous['session'] == entry['session']
                and previous['context'][:-1] == ctx[:-1]
                and type(previous['context'][-1]) is int and type(ctx[-1]) is int
                and ctx[-1] == previous['context'][-1] + 1
                and 0 <= now - previous['at'] <= REFRESH_EDGE_SECONDS
                and (state != 'paused' or previous['samples'] >= 2)):
            entry.setdefault('refresh_edges', {})[slot] = {
                'context': ctx, 'at': now, 'state': state, 'session': entry['session']}

    def _restore_refresh_edges(self, idx, entry):
        # Only the acknowledged, disabled host policy may adopt the new CMD93
        # epochs. The GPIO generation/port/UID/slot proof itself cannot rebase.
        self._prune_refresh_edges()
        if entry['applied'] is not False:
            return
        for slot, proof in list(entry.get('refresh_edges', {}).items()):
            gates = self.ace._gate_status_per_ace.get(idx) or ()
            if slot >= len(gates) or type(gates[slot]) is not int or gates[slot] != 1:
                self._discard_refresh_edge(idx, slot)
                continue
            self.gate_events[(idx, slot)] = proof['context']
            if proof['state'] == 'paused':
                self.pause_events[(idx, slot)] = (proof['context'], proof['at'])

    def gate_changed(self, idx, slot, before, after, transport, valid=False):
        key = idx, slot
        ps = self.ace.printer.lookup_object('print_stats', None)
        if ps is not None and getattr(ps, 'state', '').lower() in ('printing', 'paused'):
            self.pause_tainted.add(key)
        self.gate_events.pop(key, None)
        self.pause_events.pop(key, None)
        previous = self.pause_empty.pop(key, None)
        entry = self.units.get(idx)
        ctx = self._gate_context(idx, slot)
        self._refresh_gate_changed(idx, slot, before, after, transport, valid, entry, ctx)
        if (valid and before == 1 and after == 0 and self._pause_stable()
                and entry is not None and entry['applied'] is False
                and entry['transport'] is transport and self.ace._serials.get(idx) is transport):
            self.pause_empty[key] = [ctx, 0]
        if (valid and before == 0 and after == 1 and entry is not None and entry['applied'] is False
                and entry['transport'] is transport and self.ace._serials.get(idx) is transport):
            self.gate_events[key] = ctx
            if (valid and self._pause_stable() and previous and previous[1] >= 2
                    and previous[0][:-1] == ctx[:-1]
                    and type(previous[0][-1]) is int and ctx[-1] == previous[0][-1] + 1):
                self.pause_events[key] = (ctx, self.ace.reactor.monotonic())

    def observe_gate(self, idx, slot, gate, transport):
        key = idx, slot
        entry = self.units.get(idx, {})
        drop = entry.get('refresh_drops', {}).get(slot)
        if drop is not None:
            if (gate != 0 or transport is not entry['transport']
                    or not self._refresh_proof_valid(idx, slot, entry, drop)):
                self._discard_refresh_edge(idx, slot)
            else:
                drop['samples'] += 1
        empty = self.pause_empty.get(key)
        if empty is None:
            return
        if (not self._pause_stable() or gate != 0 or self.ace._serials.get(idx) is not transport
                or self._gate_context(idx, slot) != empty[0]):
            self.pause_empty.pop(key, None)
        else:
            empty[1] += 1

    def _pause_stable(self):
        ps = self.ace.printer.lookup_object('print_stats', None)
        pause = self.ace.printer.lookup_object('pause_resume', None)
        try:
            confirmed = pause is not None and pause.get_status(self.ace.reactor.monotonic()).get('is_paused') is True
        except (AttributeError, KeyError, TypeError, RuntimeError):
            confirmed = False
        return (confirmed and ps is not None and getattr(ps, 'state', '').lower() == 'paused'
                and self.paused_since is not None
                and self.ace.reactor.monotonic() - self.paused_since >= 1.0)

    def _motion_stable(self):
        """Read live motion and the unflushed/MCU queue without scheduling moves."""
        a = self.ace
        now = a.reactor.monotonic()
        try:
            motion = a.printer.lookup_object('motion_report', None)
            toolhead = a.printer.lookup_object('toolhead', None)
            if motion is None or toolhead is None:
                raise ValueError('motion evidence unavailable')
            report = motion.get_status(now)
            names = report['trapq']
            if 'toolhead' not in names or toolhead.get_extruder().get_name() not in names:
                raise ValueError('motion queues unavailable')
            xyz, extruder = report['live_velocity'], report['live_extruder_velocity']
            print_time, estimated, empty = toolhead.check_busy(now)
            values = (xyz, extruder, print_time, estimated)
            if (any(type(v) not in (int, float) or not math.isfinite(v) for v in values)
                    or abs(xyz) > STOPPED_VELOCITY_EPSILON
                    or abs(extruder) > STOPPED_VELOCITY_EPSILON
                    or empty is not True or print_time > estimated):
                raise ValueError('motion or queued moves remain')
        except (AttributeError, KeyError, TypeError, ValueError, RuntimeError):
            self.paused_motion_since = None
            return False
        if self.paused_motion_since is None:
            self.paused_motion_since = now
        return now - self.paused_motion_since >= .5

    def allows_paused_check(self, idx, slot):
        token = self.active
        return (token is not None and token is self.owner and token.get('paused_grip') is True
                and (token.get('idx'), token.get('slot')) == (idx, slot)
                and self._paused_safe(idx, slot, own=True))

    def require_paused_grip_stopped(self, gcmd):
        """Block RESUME only while this paused grip lacks a STOP receipt."""
        if self.paused_grip_unconfirmed is not None:
            raise gcmd.error('暂停短吸的停止尚未确认，请先检查原 ACE 并复核停止')

    def confirm_paused_grip_stop(self, idx, slot, receipt):
        """Accept a verified STOP on the same physical port, UID and slot."""
        pending = self.paused_grip_unconfirmed
        if (pending is not None and (pending['idx'], pending['slot']) == (idx, slot)
                and isinstance(receipt, dict) and receipt.get('slot') == slot
                and receipt.get('identity') == pending['identity']
                and receipt.get('transport') is not None
                and self.ace._serials.get(idx) is receipt['transport']
                and self.ace._connected_per_ace.get(idx) is True
                and not getattr(self.ace, '_reconnecting_per_ace', {}).get(idx)
                and self.ace._location_identity(idx) == pending['identity']
                and isinstance(pending['identity'], (tuple, list))
                and len(pending['identity']) == 2 and pending['identity'][0]
                and isinstance(pending['identity'][1], (tuple, list))
                and len(pending['identity'][1]) == 3
                and any(pending['identity'][1])
                and type(receipt.get('samples')) is int and receipt['samples'] >= 3):
            self.paused_grip_unconfirmed = None

    def _paused_safe(self, idx, slot, own=False):
        a = self.ace
        if not self._pause_stable() or not self._motion_stable() or self.changing:
            return False
        recovery = getattr(a, '_error_recovery', None)
        held = self.pause_mutex is not None
        if recovery is None or (not own and recovery._is_busy(ignore_gcode_mutex=held)):
            return False
        if own:
            if (self.owner is not self.active or self.active is None
                    or recovery.active or recovery._feed_in_progress(ignore_gcode_mutex=held)
                    or a._slot_actions.cancel or a._unload_all_active
                    or getattr(a, '_tag_read_busy', False)
                    or getattr(a, '_gen1_manual_busy', False)
                    or getattr(a, '_feed_supervisors', {})
                    or getattr(a, '_insert_read_running', set())
                    or getattr(a, '_insert_abort_running', set())):
                return False
            bg = a.printer.lookup_object('ace_bg_swap', None)
            guard = a.printer.lookup_object('ace_native_guard', None)
            operations = getattr(a, '_path_operations', None)
            if ((bg is not None and getattr(bg, '_busy', False))
                    or (guard is not None and getattr(guard, 'state', None) != 'idle')
                    or (operations is not None and any(op.get('state') not in ('complete', 'cancelled', 'error')
                                                       for op in operations.status()))):
                return False
        if a._stop_message(idx, slot) or dynamic_route_blocked(a, idx=idx, slot=slot):
            return False
        try:
            heads = tuple(a._rfid_route_heads(idx, slot) or ())
            if not heads or any(raw_head_state(a, head) is not False for head in heads):
                return False
            for head in heads:
                source = a._head_source.get(head)
                if source is not None and (source_route(source) != (idx, slot)
                        or not a._source_insertion_matches(source, idx, slot)):
                    return False
        except (AttributeError, KeyError, TypeError, RuntimeError):
            return False
        return True

    def prepare_manual(self, idx, slot):
        if not self.capable(idx): return
        if self.changing: raise RuntimeError('正在切换插料设置')
        with self.claim('insert_policy', idx, slot):
            entry = self.unit(idx)
            snapshot = self.apply_unit(idx)
            self.request(idx, 'insert_policy_discard', entry, slot, snapshot['epochs'][slot])
            self.gate_events.pop((idx, slot), None)

    def tick(self, eventtime):
        self._prune_refresh_edges()
        ps = self.ace.printer.lookup_object('print_stats', None)
        paused = ps is not None and getattr(ps, 'state', '').lower() == 'paused'
        if paused:
            if self.paused_since is None:
                self.paused_since = self.ace.reactor.monotonic()
            if self._pause_stable():
                self._motion_stable()
            else:
                self.paused_motion_since = None
        else:
            self._drop_reserved_events()
        if not self.polling and not self.changing and (paused or not self.busy()):
            self.polling = True
            self.ace.reactor.register_async_callback(self.poll)
        return eventtime + .5

    def _drop_reserved_events(self):
        self.paused_since = None
        self.paused_motion_since = None
        for key in self.pause_tainted:
            self.gate_events.pop(key, None)
        self.pause_tainted.clear()
        self.pause_empty.clear()
        self.pause_events.clear()

    def _paused_policy_sync(self, idx, entry):
        """Restore motion-free settings after an ACE loses its session during a pause."""
        for slot in range(4):
            key = idx, slot
            self.gate_events.pop(key, None)
            self.pause_empty.pop(key, None)
            self.pause_events.pop(key, None)
        entry['applied'] = None
        now = self.ace.reactor.monotonic()
        mutex = self._free_gcode_mutex()
        recovery = getattr(self.ace, '_error_recovery', None)
        if (now < entry.get('paused_sync_after', 0) or mutex is None or recovery is None
                or recovery._is_busy() or not self._motion_stable()):
            return
        # Existing apply_unit verifies every lane is ready and only disables
        # native automatic insertion and background RFID. Never replay an edge
        # observed before the new session was confirmed.
        with mutex:
            self.pause_mutex = mutex
            entry['paused_sync_after'] = now + 5.0
            try:
                with self.claim('insert_policy', idx, paused_sync=True):
                    self.apply_unit(idx)
                logging.info('[multiACE] restored ACE %d insertion policy during pause', idx + 1)
            finally:
                self.pause_mutex = None

    def _paused_inlet_ready(self, idx, slot, entry, context, inserted):
        """Release only isolated, armed peers while the original inlet is being serviced."""
        a = self.ace
        rows = a._info_per_ace.get(idx, {}).get('slots', ())
        lanes = {row['index']: row['slot_status'] for row in rows}
        if len(lanes) != 4 or context != self._gate_context(idx, slot):
            return False
        if inserted and all(state == 'ready' for state in lanes.values()):
            return True
        if lanes[slot] != ('ready' if inserted else 'feed_error'):
            return False
        peers = [peer for peer, state in lanes.items() if peer != slot and state != 'ready']
        if not peers or any(lanes[peer] not in ('assisting', 'rollback_assisting') for peer in peers):
            return False
        heads = context[3]
        if not heads or any(raw_head_state(a, head) is not False for head in heads):
            return False
        for peer in peers:
            peer_heads = tuple(a._rfid_route_heads(idx, peer) or ())
            if (not peer_heads or set(heads).intersection(peer_heads)
                    or not a._native_assist_is_armed(idx, peer) or a._stop_message(idx, peer)):
                return False
        stopped = entry.setdefault('inlet_peer_stops', {})
        event = context[-1]
        if stopped.get(slot) == event:
            return False
        mutex = self._free_gcode_mutex()
        recovery = getattr(a, '_error_recovery', None)
        if mutex is None or recovery is None or recovery._is_busy() or not self._motion_stable():
            return False
        transport = entry['transport']

        def monitor():
            self.connected(idx, entry)
            if (not self._pause_stable() or not self._motion_stable()
                    or self._gate_context(idx, slot) != context
                    or any(raw_head_state(a, head) is not False for head in heads)
                    or recovery._is_busy(ignore_gcode_mutex=True)):
                raise RuntimeError('暂停插料状态已变化')

        with mutex:
            monitor()
            current = a._slot_actions._lane_states(idx, monitor=monitor)
            if current != lanes or any(not a._native_assist_is_armed(idx, peer) for peer in peers):
                return False
            stopped[slot] = event
            for peer in peers:
                monitor()
                a._slot_actions._request(idx, 'stop_feed_assist', {'index': peer}, 9,
                                         monitor=monitor, stop_transport=transport)
                a._clear_fa_cache_for(idx, peer)
            logging.info('[multiACE] ACE %d slot %d paused insert: stopped armed peers %s',
                         idx + 1, slot + 1, [peer + 1 for peer in peers])
        # A fresh status must confirm READY. The next CMD93 query can then
        # clear the firmware's old feed error while the inlet is still empty.
        return False

    def poll(self, eventtime):
        a = self.ace
        try:
            self._prune_refresh_edges()
            for idx, connected in list(a._connected_per_ace.items()):
                ps = a.printer.lookup_object('print_stats', None)
                paused = ps is not None and getattr(ps, 'state', '').lower() == 'paused'
                if not paused:
                    self._drop_reserved_events()
                if not connected or not self.capable(idx) or self.changing or (not paused and self.busy()): continue
                try:
                    entry = self.unit(idx)
                    snapshot = self.request(idx, 'insert_policy_query', entry)
                    if paused:
                        # On .03O, QUERY also advances empty-inlet fault recovery.
                        if (not self._pause_stable() or self.changing
                                or a.printer.lookup_object('print_stats', None) is not ps):
                            continue
                        if not (snapshot['configured'] and snapshot['session'] == entry['session']
                                and snapshot['enabled'] is False and entry['applied'] is False):
                            self._paused_policy_sync(idx, entry)
                            continue
                        self.observe(idx, entry, snapshot)
                        entry['error'] = ''
                        self._restore_refresh_edges(idx, entry)
                        for slot, epoch in enumerate(snapshot['epochs']):
                            key = idx, slot
                            empty = self.pause_empty.get(key)
                            if empty is not None:
                                self._paused_inlet_ready(idx, slot, entry, empty[0], inserted=False)
                            proof = self.pause_events.get(key)
                            if proof is None:
                                continue
                            if a.reactor.monotonic() - proof[1] > 30:
                                self.pause_events.pop(key, None)
                                continue
                            if (self._paused_safe(idx, slot)
                                    and self._paused_inlet_ready(idx, slot, entry, proof[0], inserted=True)):
                                self._run_paused_grip(idx, slot, entry, epoch, proof)
                                if key not in self.pause_events:
                                    self._discard_refresh_edge(idx, slot)
                        continue
                    if self.changing or self.busy(): continue
                    if (snapshot['configured'] and snapshot['session'] == entry['session']
                            and snapshot['enabled'] is False and entry['applied'] is False):
                        self.observe(idx, entry, snapshot)
                        self.reconcile_loaded_sources(idx, snapshot, snapshot)
                        entry['error'] = ''
                    else:
                        with self.claim('insert_policy', idx):
                            snapshot = self.apply_unit(idx)
                    self._restore_refresh_edges(idx, entry)
                    for slot, epoch in enumerate(snapshot['epochs']):
                        key = idx, slot
                        event = self.gate_events.get(key)
                        if event is None:
                            continue
                        if self._gate_context(idx, slot) != event:
                            self.gate_events.pop(key, None)
                            continue
                        if not a._stop_message(idx, slot) and not dynamic_route_blocked(a, idx=idx, slot=slot):
                            try:
                                self.run(idx, slot, entry, epoch, event=event)
                            finally:
                                self._discard_refresh_edge(idx, slot)
                except Exception as exc:
                    entry = self.units.get(idx)
                    if entry is not None: entry['error'] = str(exc)
        finally:
            self.polling = False

    def permits_start(self, idx, request, transport):
        if '_insert_policy_owner' in request:
            if request['_insert_policy_owner'] is None or request['_insert_policy_owner'] is not self.owner:
                return False
            entry = self.units.get(idx)
            try:
                self.owned(idx, entry, request.get('_insert_policy_cleanup') is True
                           and request.get('method') == 'insert_policy_discard')
                if transport is not entry['transport']: return False
            except Exception:
                return False
        if request.get('method') != 'insert_policy_start': return True
        token = request.get('_insert_policy_token')
        try:
            if token is None or token is not self.active or token['idx'] != idx or token.get('revoked'):
                return False
            self.monitor(token)
            return (transport is token['entry']['transport'] and
                    request['params']['epoch'] == token['epoch'] and
                    request['params']['session'] == token['entry']['session'])
        except Exception:
            return False

    def _scan_context(self, idx, slot):
        ace = self.ace
        return (ace._serials.get(idx), ace._location_identity(idx),
                getattr(ace, '_ace_mode', None), ace._rfid_route_heads(idx, slot),
                getattr(ace, '_insert_epochs', {}).get((idx, slot)))

    def drop_changed_scan_origins(self):
        with self.wire_lock:
            for key, context in list(self.scan_origins.items()):
                if context != self._scan_context(*key):
                    self.scan_origins.pop(key, None)

    def take_scan_origin(self, idx, slot):
        with self.wire_lock:
            origin = self.scan_origins.pop((idx, slot), None)
        return origin is not None and origin == self._scan_context(idx, slot)

    def restore_scan_origin(self, idx, slot, original_context):
        """Restore a consumed origin only after the reader proved its return.

        The reader invokes this after fresh stationary encoder and inlet checks.
        This is not a calibration or a new Y-clearance claim. A replug, new
        insertion or topology change cannot renew a previous origin.
        """
        with self.wire_lock:
            if (original_context is None
                    or original_context != self._scan_context(idx, slot)
                    or self.ace._connected_per_ace.get(idx) is not True
                    or self.ace._serial_failed_per_ace.get(idx, False)):
                return False
            self.scan_origins[(idx, slot)] = original_context
        return True

    def _occupied_branch(self, idx, slot, heads):
        a = self.ace
        if a._ace_mode != 'multi' or heads != (slot,) or raw_head_state(a, slot) is not True:
            return None
        source = a._head_source.get(slot)
        route = source_route(source)
        if (route is None or route[0] == idx or route[1] != slot
                or source.get('load_failed') is not False):
            return None
        return route

    def allows_branch_grip(self, idx, request, transport, head):
        """Admit precisely one finite inlet grip while another ACE owns the head."""
        a, token = self.ace, self.active
        if (token is None or token is not self.owner or token is not request.get('_insert_policy_owner')
                or token.get('paused_grip') or token.get('revoked') or token.get('grip_wire_attempted')
                or a._slot_actions.cancel or self.changing or request.get('method') != 'feed_filament'):
            return False
        slot, event = token['slot'], token.get('gate_event')
        if (event is None or head != slot or idx != token['idx']
                or transport is not token['entry']['transport']
                or request.get('params') != {'index': slot, 'length': GRIP_MM, 'speed': GRIP_SPEED}
                or self._gate_context(idx, slot) != event):
            return False
        stats = a.printer.lookup_object('print_stats', None)
        gates = a._gate_status_per_ace.get(idx) or ()
        peer = self._occupied_branch(idx, slot, event[3])
        return (stats is not None and stats.state in ('standby', 'complete', 'cancelled')
                and a._connected_per_ace.get(idx) is True and len(gates) > slot and gates[slot] == 1
                and peer is not None and peer == token.get('branch_peer'))

    def before_write(self, idx, request, transport):
        method = request.get('method')
        params = request.get('params') or {}
        with self.wire_lock:
            if (request.get('_insert_policy_owner') is not None and self.active is not None
                    and self.active.get('revoked')):
                return False
            owner = request.get('_insert_policy_owner')
            if owner is not None and owner is self.owner and owner.get('paused_sync'):
                setting_off = ((method == 'insert_policy_set' and params.get('enabled') is False)
                               or (method == 'set_rfid_enable' and params.get('enable') is False))
                if (not setting_off or idx != owner['idx'] or self.pause_mutex is None
                        or not self.pause_mutex.test() or not self._pause_stable()):
                    return False
            if (request.get('_insert_policy_owner') is self.owner and self.active is not None
                    and self.active.get('paused_grip')):
                token = self.active
                if (method != 'feed_filament' or params != {'index': token['slot'],
                        'length': GRIP_MM, 'speed': GRIP_SPEED}
                        or (idx, transport) != (token['idx'], token['entry']['transport'])
                        or self._gate_context(idx, token['slot']) != token.get('gate_event')
                        or self.pause_mutex is None or not self.pause_mutex.test()
                        or not self._pause_stable()):
                    return False
            if method == 'insert_policy_start':
                if not self.permits_start(idx, request, transport):
                    return False
                request['_insert_policy_token']['wire_attempted'] = True
            if (method == 'feed_filament' and request.get('_insert_policy_owner') is self.owner
                    and self.active is self.owner and self.active is not None
                    and (self.active.get('idx'), self.active.get('slot')) == (idx, params.get('index'))):
                self.active['grip_wire_attempted'] = True
                if self.active.get('paused_grip'):
                    self.paused_grip_unconfirmed = {
                        'idx': idx, 'slot': params['index'], 'transport': transport,
                        'identity': self.active['entry']['identity']}
            if method in ('insert_policy_start', 'feed_filament', 'unwind_filament',
                          'feed_or_rollback_raw', 'start_feed_assist', 'update_feeding_speed'):
                slot = params.get('index')
                if type(slot) is int and 0 <= slot < 4:
                    self._discard_refresh_edge(idx, slot)
                    self.gate_events.pop((idx, slot), None)
                    self.scan_origins.pop((idx, slot), None)
                    self.pause_empty.pop((idx, slot), None)
                    self.pause_events.pop((idx, slot), None)
                else:
                    for lane in range(4):
                        self._discard_refresh_edge(idx, lane)
                        self.gate_events.pop((idx, lane), None)
                        self.scan_origins.pop((idx, lane), None)
                        self.pause_empty.pop((idx, lane), None)
                        self.pause_events.pop((idx, lane), None)
            elif ((method == 'raw' and params.get('cmd') in (8, 10, 77))
                  or (method in ('drying', 'drying_raw') and params.get('auto_roll') is True)
                  or '_controlled_owner' in request):
                for lane in range(4):
                    self._discard_refresh_edge(idx, lane)
                    self.gate_events.pop((idx, lane), None)
                    self.scan_origins.pop((idx, lane), None)
                    self.pause_empty.pop((idx, lane), None)
                    self.pause_events.pop((idx, lane), None)
            return True

    def monitor(self, token):
        a, actions = self.ace, self.ace._slot_actions
        idx, slot, entry = token['idx'], token['slot'], token['entry']
        self.owned(idx, entry)
        if (self.changing or actions.cancel or self.active is not token
                or actions.state.get('seq') != token['seq'] or actions.state.get('kind') != 'insert'
                or a._location_identity(idx) != entry['identity']
                or (token.get('gate_event') is not None
                    and self._gate_context(idx, slot) != token['gate_event'])):
            raise RuntimeError('插料已停止或任务发生变化')
        actions._check(idx, slot, transport=entry['transport'], own=True)

    def _free_gcode_mutex(self):
        gcode = self.ace.printer.lookup_object('gcode', None)
        try:
            mutex = gcode.get_mutex() if gcode is not None else None
            if mutex is not None and not mutex.test() and not mutex.queue:
                return mutex
        except (AttributeError, TypeError, RuntimeError):
            pass
        return None

    def _run_paused_grip(self, idx, slot, entry, epoch, proof):
        # Reserve Klipper's G-code mutex through the one finite grip and STOP.
        # A queued resume/cancel waits; the command is never replayed.
        mutex = self._free_gcode_mutex()
        if mutex is None:
            return
        with mutex:
            self.pause_mutex = mutex
            try:
                self._run_paused_grip_locked(idx, slot, entry, epoch, proof)
            finally:
                self.pause_mutex = None

    def _run_paused_grip_locked(self, idx, slot, entry, epoch, proof):
        """One normal bounded inlet feed; never clear or bypass a lane fault."""
        a, actions = self.ace, self.ace._slot_actions
        key = idx, slot
        if (self.pause_events.get(key) != proof or self.gate_events.get(key) != proof[0]
                or self._gate_context(idx, slot) != proof[0]
                or not 0 <= a.reactor.monotonic() - proof[1] <= 30):
            self.pause_events.pop(key, None)
            return
        # Consume before any claim/yield. A rejected or cancelled attempt is
        # never replayed without another actual removal and insertion.
        self.pause_events.pop(key, None)
        self.gate_events.pop(key, None)
        try:
            with self.claim('insert', idx, slot, paused_grip=True) as token:
                token.update(entry=entry, epoch=epoch, gate_event=proof[0])
                self.active = token
                monitor = lambda: self.monitor(token)
                stopped_proved = False
                try:
                    monitor()
                    current = self.request(idx, 'insert_policy_query', entry)
                    if (current['epochs'][slot] != epoch or not current['configured']
                            or current['session'] != entry['session'] or current['enabled']):
                        raise RuntimeError('原 ACE 插料代次或策略已变化')
                    samples = []
                    for number in range(3):
                        monitor()
                        sample = actions._sample(idx, slot, allow_initial_zero=True, monitor=monitor)
                        if not sample[0]:
                            raise RuntimeError('原槽入口无料')
                        samples.append(sample)
                        if number < 2:
                            a.reactor.pause(a.reactor.monotonic() + .25)
                    if len(set(samples)) != 1:
                        raise RuntimeError('原槽停止状态或反馈不稳定')
                    baseline = samples[-1]
                    monitor()
                    actions._request(idx, 'feed_filament',
                        {'index': slot, 'length': GRIP_MM, 'speed': GRIP_SPEED}, 8,
                        monitor=monitor, stop_transport=entry['transport'], policy_token=self.owner)
                    started = a.reactor.monotonic()
                    deadline = started + GRIP_MM / float(GRIP_SPEED) + 3.0
                    ready_since = None
                    saw_feeding = False
                    while True:
                        monitor()
                        now = a.reactor.monotonic()
                        if now >= deadline:
                            raise RuntimeError('短吸未在时限内确认完成')
                        states = actions._lane_states(idx, monitor=monitor)
                        if any(value != 'ready' for lane, value in states.items() if lane != slot):
                            raise RuntimeError('短吸期间其他槽状态异常')
                        state = states.get(slot)
                        if state == 'feeding':
                            saw_feeding = True
                            ready_since = None
                        elif state == 'ready':
                            if ready_since is None:
                                ready_since = now
                            elif now - ready_since >= .2:
                                endpoint = actions._sample(idx, slot, allow_initial_zero=True, monitor=monitor)
                                present, (decoder_ok, delta), (steps, length) = endpoint
                                zero_baseline = baseline[1] == (True, 0) and baseline[2] == (0, 0)
                                if (present and decoder_ok and steps > 0 and GRIP_MM - 10 <= length <= GRIP_MM
                                        and 0 < abs(delta) <= GRIP_MM + 10 and endpoint[1:] != baseline[1:]
                                        and (saw_feeding or zero_baseline)):
                                    break
                                if (present and saw_feeding and not decoder_ok
                                        and now >= started + GRIP_MM / float(GRIP_SPEED)):
                                    # READY after the finite nominal duration is
                                    # a stop condition, not a distance receipt.
                                    break
                        else:
                            raise RuntimeError('短吸遇到实际槽故障或异常: %s' % state)
                        a.reactor.pause(min(deadline, a.reactor.monotonic() + .1))
                    receipt = stop_and_verify(a, idx, slot, transport=entry['transport'], identity=entry['identity'],
                                              monitor=monitor, timeout=5.0, ready_status_only=True,
                                              stopped_fault_without_decoder=True)
                    stopped_proved = True
                    self.confirm_paused_grip_stop(idx, slot, dict(receipt, slot=slot))
                    monitor()
                    final = actions._sample(idx, slot, allow_initial_zero=True, monitor=monitor)
                    if final != endpoint:
                        raise RuntimeError('短吸停稳后的终点反馈改变')
                    measured = endpoint[1][0]
                    actions.state.update(state='complete', stopped=True, stop_confirmed=True,
                                         progress=100, measured=measured,
                                         message=('已短吸 10 cm，打印仍暂停' if measured else
                                                  '短吸已停止，耗材位移未测得，打印仍暂停'))
                    entry['error'] = ''
                except Exception as original:
                    with self.wire_lock:
                        token['revoked'] = True
                        attempted = token.get('grip_wire_attempted', False)
                    if attempted and not stopped_proved:
                        try:
                            receipt = stop_and_verify(a, idx, slot, transport=entry['transport'],
                                                      identity=entry['identity'],
                                                      monitor=lambda: self.connected(idx, entry), timeout=5.0,
                                                      ready_status_only=True, stopped_fault_without_decoder=True)
                            actions.state['stop_confirmed'] = True
                            self.confirm_paused_grip_stop(idx, slot, dict(receipt, slot=slot))
                        except Exception as stop_error:
                            raise RuntimeError('%s；停止未确认: %s' % (original, stop_error)) from stop_error
                    raise
                finally:
                    self.active = None
        except Exception as exc:
            entry['error'] = str(exc)
            logging.info('[multiACE] paused inlet grip %d/%d: %s', idx, slot, exc)

    def run(self, idx, slot, entry, epoch, event=None):
        a, actions = self.ace, self.ace._slot_actions
        peer = self._occupied_branch(idx, slot, event[3]) if event is not None else None
        params = {'index': slot, 'length': GRIP_MM, 'speed': GRIP_SPEED}
        auto_at_start = self.options.enabled('auto_rfid', idx)
        try:
            actions._check(idx, slot)
            with self.claim('insert', idx, slot) as token:
                token.update(entry=entry, epoch=epoch, gate_event=event, branch_peer=peer)
                self.active = token
                monitor = lambda: self.monitor(token)
                try:
                    monitor()
                    current = self.request(idx, 'insert_policy_query', entry)
                    if (current['epochs'][slot] != epoch or
                        (event is None and not current['pending'][slot]) or
                        (event is not None and self.gate_events.get((idx, slot)) != event)):
                        return
                    baseline = actions._sample(idx, slot, allow_initial_zero=True, monitor=monitor)
                    if not baseline[0]:
                        raise RuntimeError('料槽入口无料')
                    # Consume the fresh insertion event BEFORE the short move.
                    # A reboot or a lost response never replays a previous insert.
                    self.gate_events.pop((idx, slot), None)
                    if current['pending'][slot]:
                        self.request(idx, 'insert_policy_discard', entry, slot, epoch)
                    monitor()
                    actions._request(idx, 'feed_filament', params, 8,
                        monitor=monitor, stop_transport=entry['transport'], policy_token=self.owner)
                    # Wait for the finite feed while remaining responsive to cancel.
                    started = a.reactor.monotonic()
                    duration = GRIP_MM / float(GRIP_SPEED)
                    earliest = started + duration
                    deadline = earliest + 3.0
                    actions.state.update(progress_percent=0, progress_estimated=True,
                                         message='正在短吸 %d mm' % GRIP_MM)
                    while a.reactor.monotonic() < earliest:
                        monitor()
                        percent = min(95, int(100 * (a.reactor.monotonic() - started) / duration))
                        actions.state.update(progress_percent=percent)
                        a.reactor.pause(min(earliest, a.reactor.monotonic() + .1))
                    actions.state.update(progress_percent=95, message='正在确认送料停止')
                    while True:
                        monitor()
                        if actions._lane_states(idx, monitor=monitor).get(slot) == 'ready':
                            break
                        if a.reactor.monotonic() >= deadline:
                            raise RuntimeError('插料未在预期时间内结束，已停止')
                        a.reactor.pause(min(deadline, a.reactor.monotonic() + .1))
                    monitor()
                    actions._eject_stop(idx, slot, entry['transport'], monitor)
                    a.wait_ace_ready_on(idx)
                    try:
                        stopped = actions._sample(idx, slot, allow_initial_zero=True, monitor=monitor)
                        present, (decoder_ok, delta), (_steps, measured_length) = stopped
                        if (peer is None and present and decoder_ok and 0 < abs(delta) <= GRIP_MM + 10
                                and 0 < measured_length <= GRIP_MM and stopped[1:] != baseline[1:]):
                            context = self._scan_context(idx, slot)
                            with self.wire_lock:
                                self.scan_origins[(idx, slot)] = context
                    except RuntimeError as exc:
                        logging.info('[multiACE] RFID short-grip origin not confirmed: %s', exc)
                    actions.state.update(state='complete', progress=100,
                                         progress_percent=100, progress_estimated=False,
                                         stop_confirmed=True,
                                         message='已插入 ACE，等待装料到喷头')
                    entry['error'] = ''
                except Exception:
                    connected = lambda: self.connected(idx, entry)
                    try:
                        connected()
                        actions._eject_stop(idx, slot, entry['transport'], connected)
                        stop_deadline = a.reactor.monotonic() + 2.0
                        while actions._lane_states(idx, monitor=connected).get(slot) != 'ready':
                            if a.reactor.monotonic() >= stop_deadline:
                                raise RuntimeError('目标槽仍未确认停止')
                            a.reactor.pause(min(stop_deadline, a.reactor.monotonic() + .1))
                        actions.state['stop_confirmed'] = True
                    except Exception as stop_error:
                        logging.warning('[multiACE] short insertion STOP unconfirmed')
                        raise RuntimeError('停止未确认，请检查 ACE：%s' % stop_error) from stop_error
                    raise
                finally:
                    self.active = None
            if (peer is None and auto_at_start and not actions.cancel
                    and self.options.enabled('auto_rfid', idx)):
                self.connected(idx, entry)
                gcmd = a.gcode.create_gcode_command('ACE_SLOT_RFID', 'ACE_SLOT_RFID',
                    {'ACE': str(idx), 'SLOT': str(slot), 'MAX_MM': str(SCAN_MM)})
                gcmd._short_insert_context = (entry['transport'], entry['identity'],
                                             a._insert_epochs.get((idx, slot)))
                a.cmd_ACE_SLOT_RFID(gcmd)
        except Exception as exc:
            entry['error'] = str(exc)
            logging.info('[multiACE] insertion %d/%d: %s', idx, slot, exc)

    def status(self):
        units = []
        for idx, connected in self.ace._connected_per_ace.items():
            entry = self.units.get(idx, {})
            snapshot = entry.get('snapshot') or {}
            units.append({'ace': idx, 'connected': bool(connected), 'supported': self.capable(idx),
                          'applied': entry.get('applied') if connected else None,
                          'firmware_pending': snapshot.get('pending'),
                          'firmware_epochs': snapshot.get('epochs'),
                          'native_enabled': snapshot.get('enabled'),
                          'rfid_enabled': self.options.enabled('rfid', idx),
                          'remaining_enabled': self.options.enabled('remaining', idx),
                          'error': entry.get('error', '')})
        return {'enabled': self.enabled, 'persisted': self.options.saved['rfid'], 'park_mm': GRIP_MM,
                'advanced': self.options.status(),
                'changing': self.changing, 'poll_blocked': self.busy(), 'units': units}
