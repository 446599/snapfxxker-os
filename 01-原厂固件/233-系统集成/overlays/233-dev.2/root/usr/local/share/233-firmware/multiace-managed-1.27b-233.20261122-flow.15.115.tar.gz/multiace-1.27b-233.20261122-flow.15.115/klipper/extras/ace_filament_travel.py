"""Per-load Bowden travel, independent of absolute position and calibration.

Only completed finite ACE moves count. Printing/thermal assistance is excluded:
its encoder includes consumed filament and cannot be a return-to-start distance.
A persisted in-flight move becomes unknown on restart, never a guessed length.
"""
import copy
import math
import json
import logging
import os
import tempfile


class FilamentTravel:
    LIMIT_MM = 20000.0
    # The finite-move ledger does not include hot tip-form/assist and is not
    # an inlet position. Keep part of the first measured feed in reserve.
    PARK_RESERVE_MM = 250.0
    MIN_FIXED_PARK_MM = 60
    MAX_FIXED_PARK_MM = 2100

    def __init__(self, saved=None, persist=None):
        self.persist = persist or (lambda value: None)
        self.records = {}
        self.active = {}
        self.receipts = set()
        saved = saved if isinstance(saved, dict) else {}
        parks = saved.get('_park_references', {})
        self.park_references = {}
        if isinstance(parks, dict):
            for route, distance in parks.items():
                if (isinstance(route, str) and self._valid(distance)
                        and 0 <= distance <= self.LIMIT_MM):
                    self.park_references[route] = distance
        fixed = saved.get('_fixed_park_references', {})
        self.fixed_park_references = {}
        if isinstance(fixed, dict):
            for route, row in fixed.items():
                if (isinstance(route, str) and isinstance(row, dict)
                        and self._valid_fixed_park(row.get('scope'), row.get('target_mm'))):
                    self.fixed_park_references[route] = copy.deepcopy(row)
        for key, value in saved.items():
            if str(key) not in ('0', '1', '2', '3'):
                continue
            if (not isinstance(value, dict) or type(value.get('ace')) is not int
                    or value['ace'] < 0 or type(value.get('slot')) is not int
                    or not 0 <= value['slot'] < 4):
                continue
            row = copy.deepcopy(value)
            if (row.get('known') is not True or type(row.get('samples')) is not int
                    or row['samples'] < 1 or row.get('phase') not in
                    ('loading', 'loaded', 'unloading', 'parked', 'head_empty')):
                row.update(known=False, reason='invalid_record')
            if row.get('pending'):
                row.update(known=False, reason='interrupted_move', pending=False)
            if not self._valid(row.get('remaining_mm')):
                row.update(known=False, remaining_mm=0.0)
            self.records[str(key)] = row

    @classmethod
    def from_path(cls, path):
        try:
            with open(path) as source:
                saved = json.loads(source.read(65537))
        except FileNotFoundError:
            saved = {}
        except (OSError, ValueError):
            logging.warning('[multiACE] previous load distances unavailable')
            saved = {}

        def persist(records):
            directory = os.path.dirname(path)
            os.makedirs(directory, exist_ok=True)
            fd, temporary = tempfile.mkstemp(prefix='.head-travel-', dir=directory)
            try:
                with os.fdopen(fd, 'w') as target:
                    json.dump(records, target, allow_nan=False)
                    target.flush()
                    os.fsync(target.fileno())
                os.replace(temporary, path)
                directory_fd = os.open(directory, os.O_RDONLY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
        return cls(saved, persist)

    @classmethod
    def _valid(cls, value):
        return type(value) in (int, float) and math.isfinite(value) and abs(value) <= cls.LIMIT_MM

    def _save(self):
        try:
            saved = copy.deepcopy(self.records)
            if self.park_references:
                saved['_park_references'] = self.park_references.copy()
            if self.fixed_park_references:
                saved['_fixed_park_references'] = self.fixed_park_references.copy()
            self.persist(saved)
        except Exception:
            for row in self.records.values():
                row.update(known=False, reason='persistence_failed')
            raise

    def _row(self, head, ace, slot):
        row = self.records.get(str(head))
        return row if row and (row.get('ace'), row.get('slot')) == (ace, slot) else None

    def begin_load(self, head, ace, slot):
        row = self._row(head, ace, slot)
        # A failed load can resume from its measured partial progress. A new
        # load after unloading gets its own starting point.
        if not row or row.get('phase') != 'loading':
            row = dict(ace=ace, slot=slot, phase='loading', known=True,
                       remaining_mm=0.0, samples=0, pending=False, reason='')
            self.records[str(head)] = row
        self._save()

    def finish_load(self, head, ace, slot):
        row = self._row(head, ace, slot)
        if row:
            if not row.get('samples') or row['remaining_mm'] <= 0:
                row.update(known=False, reason='no_measured_feed')
            row['phase'] = 'loaded'
            row['loaded_mm'] = row['remaining_mm']
            self._save()

    def begin_unload(self, head, ace, slot):
        row = self._row(head, ace, slot)
        if not row:
            row = dict(ace=ace, slot=slot, known=False, remaining_mm=0.0,
                       pending=False, reason='no_load_record')
            self.records[str(head)] = row
        row['phase'] = 'unloading'
        self._save()
        return self.remaining(head, ace, slot)

    def remaining(self, head, ace, slot):
        row = self._row(head, ace, slot)
        if not row or not row.get('known') or row.get('pending'):
            return None
        return max(0.0, row['remaining_mm'])

    @staticmethod
    def _park_key(head, ace, slot):
        return '%d:%d:%d' % (ace, slot, head)

    def _park_reference(self, row, head, ace, slot):
        return self.park_references.get(
            self._park_key(head, ace, slot),
            max(0.0, row['loaded_mm'] - self.PARK_RESERVE_MM))

    def park_distance(self, head, ace, slot):
        row = self._row(head, ace, slot)
        if (not row or not row.get('known') or row.get('pending')
                or not self._valid(row.get('loaded_mm')) or row['loaded_mm'] <= 0):
            return None
        # The verified park is referenced to the nozzle, not to the starting
        # position of the next load. Subtracting the same reserve every time
        # would progressively move the parked filament farther into the tube.
        already_retracted = max(0.0, row['loaded_mm'] - row['remaining_mm'])
        wanted = max(0.0, self._park_reference(row, head, ace, slot) - already_retracted)
        # A measured lower bound remains useful even if the first encoder
        # sample was delayed. An older park reference must not enlarge it.
        return min(wanted, max(0.0, row['remaining_mm']))

    def measured_park_distance(self, head, ace, slot, scope):
        """Remaining measured return after a finite short retract on this load."""
        row = self._row(head, ace, slot)
        if (not row or not row.get('known') or row.get('pending') or row.get('phase') != 'unloading'
                or not self._valid(row.get('loaded_mm')) or not self._valid(row.get('remaining_mm'))):
            return None
        fixed = self.fixed_park_references.get(self._park_key(head, ace, slot))
        if fixed is not None:
            if fixed['scope'] != scope:
                return None
            reference = fixed['target_mm']
        else:
            reference = self._park_reference(row, head, ace, slot)
        withdrawn = row['loaded_mm'] - row['remaining_mm']
        remaining = reference - withdrawn
        if withdrawn <= 0 or reference > row['loaded_mm'] or not 0 < remaining <= self.MAX_FIXED_PARK_MM:
            return None
        return remaining

    def finish_park(self, head, ace, slot, *, measured_mm=None, measured_target=None):
        row = self._row(head, ace, slot)
        if measured_mm is not None:
            if (not row or not row.get('pending') or not row.get('known')
                    or not self._valid(measured_mm) or measured_mm < 0):
                raise ValueError('回停计距未确认')
            if not self._valid(measured_target) or abs(measured_target - measured_mm) > 3:
                raise ValueError('实测回退未到停泊距离')
            reference = row['loaded_mm'] - row['remaining_mm'] + measured_target
            row['remaining_mm'] -= measured_mm
            row['samples'] += 1
            row.update(pending=False, park_reference_basis='measured_travel')
        if self.park_distance(head, ace, slot) is None:
            raise ValueError('回停计距未确认')
        key = self._park_key(head, ace, slot)
        if measured_mm is not None:
            self.park_references[key] = reference
        else:
            self.park_references.setdefault(key, self._park_reference(row, head, ace, slot))
        retracted = max(0.0, row['loaded_mm'] - row['remaining_mm'])
        reference = self._park_reference(row, head, ace, slot)
        row['park_reference_reached'] = (abs(reference - retracted) <= 3.0 if measured_mm is not None
                                         else retracted >= reference - 2.0)
        if measured_mm is not None and not row['park_reference_reached']:
            raise ValueError('实测回退未到停泊距离')
        row['phase'] = 'parked' if row['park_reference_reached'] else 'head_empty'
        self._save()

    @classmethod
    def _valid_fixed_park(cls, scope, target):
        if not isinstance(scope, dict):
            return False
        uid = scope.get('uid')
        return (isinstance(scope.get('port'), str) and bool(scope['port'])
                and scope.get('mode') in ('head', 'multi', 'normal')
                and isinstance(uid, list) and len(uid) == 3
                and all(type(part) is int for part in uid)
                and type(target) is int and cls.MIN_FIXED_PARK_MM <= target <= cls.MAX_FIXED_PARK_MM)

    def fixed_park_target(self, head, ace, slot, scope):
        row = self._row(head, ace, slot)
        if row is None or row.get('pending'):
            return None
        saved = self.fixed_park_references.get(self._park_key(head, ace, slot))
        if saved is not None and saved['scope'] == scope:
            return saved['target_mm']
        return self._measured_load_park_target(head, ace, slot, scope, row)

    def _measured_load_park_target(self, head, ace, slot, scope, row):
        receipt = row.get('load_receipt') or {}
        loaded = row.get('loaded_mm')
        if (not row.get('known') or not self._valid(loaded)
                or receipt.get('uid') != scope.get('uid')
                or (receipt.get('ace'), receipt.get('slot'), receipt.get('head')) != (ace, slot, head)):
            return None
        # A witnessed move from a gripped starting point provides a
        # conservative first target. Later loads can start anywhere in the
        # tube and must not resize the fixed head-relative target.
        target = math.floor(loaded - self.PARK_RESERVE_MM)
        return target if self._valid_fixed_park(scope, target) else None

    def swap_park_target(self, head, ace, slot, scope, configured, *, automatic):
        saved = self.fixed_park_references.get(self._park_key(head, ace, slot))
        if saved is not None and saved['scope'] != scope:
            saved = None
        if saved is not None and saved.get('basis') != 'measured_load':
            return saved['target_mm'], False
        if not automatic or not self._valid_fixed_park(scope, configured):
            return configured, False
        row = self._row(head, ace, slot)
        measured = (self._measured_load_park_target(head, ace, slot, scope, row)
                    if row is not None and not row.get('pending') else None)
        previous = saved['target_mm'] if saved is not None else configured
        # A later load can begin from the previous park point and be shorter.
        # Keep the scoped target rather than moving it towards the head.
        target = max(configured, previous, measured or 0)
        return target, measured is not None and measured > max(configured, previous)

    def forward_decoder_sign(self, head, ace, slot, scope, insert_epoch):
        row = self._row(head, ace, slot)
        receipt = (row or {}).get('load_receipt') or {}
        sign = receipt.get('forward_decoder_sign')
        if (type(sign) is int and sign in (-1, 1)
                and (receipt.get('ace'), receipt.get('slot'), receipt.get('head')) == (ace, slot, head)
                and receipt.get('uid') == scope.get('uid')
                and receipt.get('insert_epoch') == insert_epoch):
            return sign
        return None

    def begin_fixed_park(self, head, ace, slot):
        row = self._row(head, ace, slot)
        if row is None or row.get('pending') or row.get('phase') != 'unloading':
            raise ValueError('回停缺少本次退料记录')
        row.update(pending=True, park_reference_reached=False)
        self._save()

    def finish_fixed_park(self, head, ace, slot, scope, target, distance, net):
        row = self._row(head, ace, slot)
        if row is None or not row.get('pending') or not self._valid_fixed_park(scope, target):
            raise ValueError('回停完成记录不匹配')
        if row.get('known'):
            row['remaining_mm'] += net
            row['samples'] += 1
        self.fixed_park_references[self._park_key(head, ace, slot)] = {
            'scope': copy.deepcopy(scope), 'target_mm': target}
        row.update(pending=False, phase='parked', park_reference_reached=True,
                   park_reference_basis='head_sensor_falling_edge',
                   park_target_mm=target, park_retracted_mm=distance)
        self._save()

    def finish_commanded_park(self, head, ace, slot, *, measured_load_plan=None):
        row = self._row(head, ace, slot)
        if not row or not row.get('pending') or row.get('phase') != 'unloading':
            raise ValueError('回停完成记录不匹配')
        # The head is clear and the inlet still occupied. Do not publish a
        # new edge calibration or a measured position from a command length.
        row.update(phase='head_empty', pending=False, known=False,
                   reason='commanded_return', park_reference_reached=False)
        if measured_load_plan is not None:
            scope, target = measured_load_plan
            if not self._valid_fixed_park(scope, target):
                raise ValueError('进料距离推算的回停目标无效')
            self.fixed_park_references[self._park_key(head, ace, slot)] = {
                'scope': copy.deepcopy(scope), 'target_mm': target, 'basis': 'measured_load'}
        self._save()

    def finish_fixed_park_probe(self, head, ace, slot, retracted_mm):
        row = self._row(head, ace, slot)
        if (row is None or not row.get('pending') or row.get('phase') != 'unloading'
                or not self._valid(retracted_mm) or retracted_mm < 0):
            raise ValueError('短退料的停稳记录不匹配')
        if row.get('known') and retracted_mm > 0:
            row['remaining_mm'] -= retracted_mm
            row['samples'] += 1
        row['pending'] = False
        self._save()

    def forget_park(self, ace, slot):
        prefix = '%d:%d:' % (ace, slot)
        expired = [key for key in self.park_references if key.startswith(prefix)]
        for key in expired:
            del self.park_references[key]
        if expired:
            self._save()

    def motion_started(self, token, head, ace, slot, kind):
        if token in self.active or token in self.receipts:
            return
        row = self._row(head, ace, slot)
        if not row or row.get('phase') not in ('loading', 'unloading'):
            return
        if kind not in ('feed', 'retract', 'unload'):
            return
        self.active[token] = (str(head), ace, slot)
        row['pending'] = True
        self._save()

    def motion_finished(self, token, travelled_mm, confirmed=True, receipt=None):
        identity = self.active.pop(token, None)
        if identity is None:
            return
        self.receipts.add(token)
        if len(self.receipts) > 256:
            self.receipts = {token}
        key, ace, slot = identity
        row = self._row(int(key), ace, slot)
        if row is None:
            return
        row['pending'] = False
        if not confirmed or not self._valid(travelled_mm):
            row.update(known=False, reason='unconfirmed_motion')
        elif (not row.get('known') and row.get('phase') == 'loading'
              and receipt is not None and travelled_mm > 0):
            # A verified successful feed on the retained original lane can
            # supply a new lower bound. Do not credit unknown earlier travel.
            basis = 'observed_span_lower_bound'
            row.update(known=True, reason='', remaining_mm=travelled_mm,
                       samples=1, measurement_basis=basis,
                       load_receipt=dict(copy.deepcopy(receipt), basis=basis))
        elif row.get('known'):
            distance = row['remaining_mm'] + travelled_mm
            if not self._valid(distance):
                row.update(known=False, reason='invalid_distance')
            else:
                # Preserve signed net travel across retries. Clamp only when
                # querying a retreat budget, not after every reverse movement.
                row['remaining_mm'] = distance
                row['samples'] = row.get('samples', 0) + 1
                if receipt is not None:
                    row['measurement_basis'] = receipt['basis']
                    row['load_receipt'] = copy.deepcopy(receipt)
        self._save()

    def unknown(self, head, ace, slot, reason):
        row = self._row(head, ace, slot)
        if row:
            row.update(known=False, pending=False, reason=reason)
            self._save()

    def finish_unload(self, head, ace, slot, cleared):
        row = self._row(head, ace, slot)
        if row and cleared:
            row['phase'] = 'parked' if row.get('known') and row['remaining_mm'] <= 2 else 'head_empty'
            self._save()

    def reset_route(self, ace, slot):
        self.forget_park(ace, slot)
        changed = False
        for key, row in list(self.records.items()):
            if (row.get('ace'), row.get('slot')) == (ace, slot):
                del self.records[key]
                changed = True
        for token, identity in list(self.active.items()):
            if identity[1:] == (ace, slot):
                del self.active[token]
        if changed:
            self._save()

    def status(self):
        return copy.deepcopy(self.records)
