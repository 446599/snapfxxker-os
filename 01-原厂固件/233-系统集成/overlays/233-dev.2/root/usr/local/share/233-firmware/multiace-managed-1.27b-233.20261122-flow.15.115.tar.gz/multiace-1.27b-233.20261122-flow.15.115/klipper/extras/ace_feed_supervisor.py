"""Observe one legacy V2 load until the physical head switch or a fault.

This is a live integration helper, not a second transport or a position oracle.
One CMD76 request is outstanding at most; a sensor poll never waits on serial.
The writer checks ``allows_wire`` before sending queued motion. A failed load
reports its own outcome before the caller can start a bounded same-route retry.
"""
import logging
import math
from time import monotonic as status_clock

from .ace_stop_guard import StopUnconfirmedError
from .ace_v2_standstill import stop_and_verify


class FeedSupervisionError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


class FeedChannelBusy(FeedSupervisionError):
    def __init__(self):
        super().__init__('channel_busy', '送料通道正在执行另一操作')


class FeedSupervisor:
    # These are conservative software observation limits, not pipe calibration.
    PRECHECK_TIMEOUT_S = 3.0
    ACK_TIMEOUT_S = 2.0
    MIN_PROGRESS_RATIO = 0.5
    READY_GUARD_S = 4.0
    STARTUP_RESET_S = 1.0
    STARTUP_ZERO_MOTOR_MM = 8
    # ACE V2 can report six motor steps of offset at zero motor distance.
    STARTUP_ZERO_STEPS = (0, 6)
    STOP_VERIFY_S = 3.0
    BACKOFF_MM = 20
    BACKOFF_SPEED = 10
    RETRY_SPEED = 40
    MOVING = frozenset(('feeding', 'rollback', 'assisting', 'rollback_assisting',
                        'preloading', 'upgrading'))
    STOPPED = frozenset(('ready', 'feed_error', 'rollback_error', 'assist_error',
                        'preload_error', 'stuck_error', 'tangled_error', 'motor_error'))
    MOTION_METHODS = frozenset(('feed_filament', 'unwind_filament',
                              'feed_or_rollback_raw', 'start_feed_assist',
                              'update_feeding_speed', 'insert_policy_start', 'raw'))

    def __init__(self, ace, idx, slot, head, sensor, length, speed):
        self.ace, self.idx, self.slot, self.head = ace, idx, slot, head
        previous_seq = getattr(ace, '_flow_feed_seq', 0)
        self.seq = (previous_seq if type(previous_seq) is int and previous_seq >= 0 else 0) + 1
        ace._flow_feed_seq = self.seq
        self.epoch = getattr(getattr(ace, '_slot_actions', None), 'epoch', None)
        self.sensor = sensor
        self.length, self.speed = float(length), float(speed)
        if not all(math.isfinite(x) and x > 0 for x in (self.length, self.speed)):
            raise FeedSupervisionError('invalid_motion_budget', '送料长度或速度无效')
        if self.length != int(self.length) or self.length >= 0xFFFFFFFF:
            raise FeedSupervisionError('invalid_motion_budget', '请为原槽设置有限的送料长度')
        self.transport = ace._serials.get(idx)
        self.identity = ace._location_identity(idx)
        self.insertion_epoch = getattr(ace, '_insert_epochs', {}).get((idx, slot))
        self.token = object()
        self.active = False
        self.cancelled = False
        self.stopping = False
        self.ack = False
        self.feed_admitted = False
        self.feed_enqueued = False
        self.backoff_params = None
        self.backoff_admitted = False
        self.retry_backoff_mm = None
        self.prior_observed_mm = 0.0
        self.after_retry = False
        self.error = None
        self.pending = None
        self.last_sample = None
        self.origin_sample = None
        self.observed_samples = 0
        self.forward_status_seen = False
        self.terminal_only_mm = None
        self.measurement_error = None
        self.decoder_sign = None
        direction = getattr(ace, '_insert_encoder_direction', {}).get((idx, slot))
        if (direction and len(direction) == 3 and direction[0] is self.transport
                and direction[1] == self.identity and direction[2] in (-1, 1)):
            self.decoder_sign = direction[2]
        self.known_decoder_sign = self.decoder_sign
        self.startup_rebases = 0
        self.terminal_sample = None
        self.terminal_slot_status = None
        self._arm_deadlines()
        self.result = 'preparing'
        self._check_identity()
        present = self.sensor()
        if present is None:
            raise FeedSupervisionError('head_sensor_unknown', '喷头原始到料状态未知')
        if present is not False:
            raise FeedSupervisionError('head_already_loaded', '喷头原始开关已检测到料，未开始送料')
        if self.gate() is not True:
            raise FeedSupervisionError('inlet_unconfirmed', 'ACE 入口有料状态未确认')
        owners = getattr(ace, '_feed_supervisors', None)
        if owners is None:
            ace._feed_supervisors = owners = {}
        old = owners.get((idx, slot))
        if old is not None and old.active:
            raise FeedChannelBusy()
        owners[(idx, slot)] = self
        self.active = True
        self.result = 'feeding'

    def gate(self):
        rows = self.ace._gate_status_per_ace.get(self.idx) or []
        value = rows[self.slot] if self.slot < len(rows) else None
        return True if value == 1 else False if value == 0 else None

    def _check_identity(self, require_insertion=True):
        a = self.ace
        if (self.transport is None or a._serials.get(self.idx) is not self.transport
                or not a._connected_per_ace.get(self.idx)
                or a._reconnecting_per_ace.get(self.idx)
                or a._location_identity(self.idx) != self.identity
                or not self.identity or self.identity[1] is None):
            raise FeedSupervisionError('connection_changed', '送料期间 ACE 连接或设备身份改变')
        if require_insertion and getattr(a, '_insert_epochs', {}).get((self.idx, self.slot)) != self.insertion_epoch:
            raise FeedSupervisionError('insertion_changed', '送料期间入口插料代次改变')

    @staticmethod
    def _ok(response, command):
        return (isinstance(response, dict) and type(response.get('code')) is int
                and response['code'] == 0
                and response.get('_v2_command') == command
                and response.get('_v2_frame_valid') is True
                and response.get('_v2_payload_valid') is True
                and str(response.get('msg', '')).strip().upper() != 'FORBIDDEN')

    def _decode(self, response, *, at_feed_start=False):
        if not self._ok(response, 76):
            raise FeedSupervisionError('telemetry_invalid', '送料编码器响应无效')
        result = response.get('result')
        if not isinstance(result, dict) or not isinstance(result.get('feed_info'), list):
            raise FeedSupervisionError('telemetry_invalid', '送料计数格式无效')
        rows = [row for row in result['feed_info']
                if isinstance(row, dict) and type(row.get('index')) is int and row['index'] == self.slot]
        if (result.get('_feed_wire_valid') is not True or len(rows) != 1
                or rows[0].get('_wire_valid') is not True):
            raise FeedSupervisionError('decoder_unavailable', '送料编码器未提供有效数值')
        row = rows[0]
        if any(type(row.get(name)) is not int or not 0 <= row[name] < 1 << 64
               for name in ('length', 'steps', 'decoder')):
            raise FeedSupervisionError('telemetry_invalid', '送料计数格式无效')
        if row.get('_decoder_present') is not True:
            # Proto3 omits zero. Use it as the origin only in the fresh
            # start reply with a zero motor distance and the native step offset.
            if (row.get('_decoder_present') is False and row['decoder'] == 0
                    and row['length'] <= self.STARTUP_ZERO_MOTOR_MM
                    and self.ace.reactor.monotonic() - self.started_at <= self.STARTUP_RESET_S):
                if at_feed_start and row['length'] == 0 and row['steps'] in self.STARTUP_ZERO_STEPS:
                    return (0., 0., row['steps'])
                return None
            raise FeedSupervisionError('decoder_unavailable', '送料编码器未提供有效数值')
        decoder = row['decoder'] - (1 << 64) if row['decoder'] >= 1 << 63 else row['decoder']
        return (float(row['length']), float(decoder), row['steps'])

    def feed_request(self, request):
        request['_feed_supervisor'] = self
        request['_feed_supervisor_token'] = self.token
        self.feed_enqueued = True

    def _arm_deadlines(self):
        # Preflight can wait for the old assist to stop. Its budget is separate
        # from the subsequent command ACK and movement observation windows.
        now = self.ace.reactor.monotonic()
        self.started_at = now
        # Heartbeat provenance in ace.py uses Python's monotonic clock.
        self.status_started_at = status_clock()
        self.deadline = now + self.length / self.speed + 30.

    def wait_before_feed(self):
        """Fresh, bounded CMD6 admission, without legacy reconnect/wait loops."""
        needs_stop = getattr(self.ace, '_native_assist_needs_stop', None)
        if needs_stop is not None and needs_stop(self.idx, self.slot):
            # An armed buffer can report ready while waiting for the toolhead.
            # Hand off this slot only; other heads may still need assistance.
            self.result = 'stopping_assist'
            self.stop_bound()
            self.ace._clear_fa_cache_for(self.idx, self.slot)
            self.stopping = False
            self.terminal_sample = self.terminal_slot_status = None
        deadline = self.ace.reactor.monotonic() + self.PRECHECK_TIMEOUT_S
        self.result = 'preparing'
        while self.ace.reactor.monotonic() < deadline:
            response = self._query('get_status', 6, deadline=deadline,
                                   cancellable=True, require_insertion=True)
            result = response.get('result') or {}
            rows = [row for row in result.get('slots', [])
                    if isinstance(row, dict) and row.get('index') == self.slot]
            if (result.get('_status_wire_valid') is not True or len(rows) != 1
                    or rows[0].get('_wire_valid') is not True
                    or result.get('status') not in ('ready', 'busy')):
                raise FeedSupervisionError('preflight_invalid', '送料前的槽位状态无效')
            if self.sensor() is not False or self.gate() is not True:
                raise FeedSupervisionError('preflight_changed', '送料前的到料或入口信号改变，未开始长推')
            all_rows = result.get('slots') or []
            if (len(all_rows) != 4
                    or any(not isinstance(row, dict) or row.get('_wire_valid') is not True
                           or type(row.get('index')) is not int for row in all_rows)
                    or sorted(row['index'] for row in all_rows) != [0, 1, 2, 3]):
                raise FeedSupervisionError('preflight_invalid', '送料前四槽状态缺失或重复')
            owned_assist = getattr(self.ace, '_native_assist_is_armed', None)
            other_busy = [row for row in all_rows if row.get('index') != self.slot
                          and row.get('slot_status') not in self.STOPPED
                          and not (row.get('slot_status') in ('assisting', 'rollback_assisting')
                                   and owned_assist is not None
                                   and owned_assist(self.idx, row.get('index')))]
            if rows[0].get('slot_status') == 'ready' and not other_busy:
                self._arm_deadlines()
                self.result = 'feeding'
                return
            self.ace.reactor.pause(min(deadline, self.ace.reactor.monotonic() + 0.1))
        raise FeedSupervisionError('preflight_busy', 'ACE 未在短时预检内就绪，未开始长推')

    def allows_wire(self, idx, request, serial):
        method = request.get('method')
        if method not in self.MOTION_METHODS:
            return True  # STOP/read commands must remain available.
        try:
            self._check_identity()
            params = request.get('params') or {}
            if not (self.active and not self.stopping and not self.cancelled
                    and idx == self.idx and serial is self.transport
                    and request.get('_feed_supervisor') is self
                    and request.get('_feed_supervisor_token') is self.token
                    and self.sensor() is False and self.gate() is True):
                return False
            if self.backoff_params is not None:
                if (method != 'unwind_filament' or params != self.backoff_params
                        or self.backoff_admitted):
                    return False
                self.backoff_admitted = True
                return True
            if (self.feed_admitted or method != 'feed_filament'
                    or params.get('index') != self.slot or params.get('length') != self.length
                    or params.get('speed') != self.speed):
                return False
            # An uncertain write is never resent as a new feed.
            self.feed_admitted = True
            self._arm_deadlines()
            return True
        except Exception:
            return False

    def feed_ack(self, response, token):
        if not self.active or self.token is not token:
            return
        if not self._ok(response, 8):
            self.error = FeedSupervisionError('feed_rejected', 'ACE 未确认本次送料指令')
        elif not self.ack:
            self.ack = True
            # The sensor stays live while this optional start sample is in flight.
            self._read_start()

    def cancel(self):
        self.cancelled = True
        self.result = 'cancelling'

    def _observe(self, sample, now):
        current = sample + (now,)
        previous = self.last_sample
        if previous is None:
            self.last_sample = current
            self.origin_sample = current
            self.observed_samples = 1
            return
        motor = sample[0] - previous[0]
        decoder = sample[1] - previous[1]
        elapsed = now - previous[3]
        reset = motor < 0 or sample[2] < previous[2]
        implausible = (elapsed <= 0 or
                       max(abs(motor), abs(decoder)) > self.speed * max(elapsed, 0) * 3 + 10)
        if reset or implausible:
            if now - self.started_at <= self.STARTUP_RESET_S and self.startup_rebases == 0:
                # One initial per-command reset is expected on legacy V2. It
                # supplies no movement evidence and never adds a travel span.
                self.startup_rebases += 1
                self.last_sample = current
                self.origin_sample = current
                self.observed_samples = 1
                self.decoder_sign = self.known_decoder_sign
                return
            raise FeedSupervisionError('counter_reset', '送料计数重置或跳变，本次位置待核')
        if abs(decoder) >= 1:
            sign = 1 if decoder > 0 else -1
            if self.decoder_sign is not None and sign != self.decoder_sign:
                raise FeedSupervisionError('decoder_reversed', '同一次前送中编码器方向反转')
            self.decoder_sign = sign
        self.last_sample = current
        self.observed_samples += 1

    def _measurement_issue(self, detail):
        if self.measurement_error is None:
            logging.info('[multiACE] ACE=%d slot=%d head=%d distance unavailable: %s',
                         self.idx, self.slot, self.head, detail)
            self.measurement_error = detail

    def _read_start(self):
        marker = object()
        self.pending = marker
        token = self.token
        request = {'method': 'get_feed_info', '_insert_stop_transport': self.transport}

        def callback(*args, **kwargs):
            if not self.active or self.token is not token or self.pending is not marker or self.stopping:
                return
            self.pending = None
            response = kwargs.get('response', args[-1] if args else None)
            try:
                if (not isinstance(response, dict) or type(request.get('id')) is not int
                        or type(response.get('id')) is not int
                        or response['id'] != request['id']):
                    raise FeedSupervisionError('telemetry_invalid', '送料遥测不是本次请求的响应')
                sample = self._decode(response, at_feed_start=True)
                now = self.ace.reactor.monotonic()
                logging.info('[multiACE feed-endpoint] start ACE=%d slot=%d head=%d speed=%.1f sample=%s',
                             self.idx, self.slot, self.head, self.speed, sample)
                # The previous command can still be visible immediately after ACK.
                if (sample is None or sample[:2] != (0, 0)
                        or sample[2] not in self.STARTUP_ZERO_STEPS
                        or now - self.started_at > self.STARTUP_RESET_S):
                    return
                self._observe(sample, now)
            except (FeedSupervisionError, TypeError, ValueError) as exc:
                logging.debug('[multiACE] optional feed start sample ignored: %s', exc)
        try:
            accepted = self.ace.send_request_to(self.idx, request, callback)
            if accepted is False:
                self.pending = None
        except Exception as exc:
            self.pending = None
            logging.debug('[multiACE] optional feed start request failed: %s', exc)

    def check(self):
        self._check_identity()
        now = self.ace.reactor.monotonic()
        if self.cancelled:
            raise FeedSupervisionError('cancelled', '已取消本次进料，正在确认停止')
        value = self.sensor()
        if value is None:
            raise FeedSupervisionError('head_sensor_unknown', '喷头原始到料信号未知')
        if self.error is not None:
            raise self.error
        lane = None
        stamp = getattr(self.ace, '_slot_status_provenance', {}).get(self.idx)
        if self.ack and stamp and stamp[0] is self.transport and stamp[1] >= self.status_started_at:
            lane = self.ace._v2_get_slot_status(self.idx, self.slot)
            if lane == 'feeding':
                self.forward_status_seen = True
            if lane in self.STOPPED and lane != 'ready':
                raise FeedSupervisionError('feed_device_error', '原槽报告送料故障：%s' % lane)
        if value is True:
            return True
        gate = self.gate()
        if gate is not True:
            raise FeedSupervisionError('inlet_empty' if gate is False else 'inlet_unknown',
                                       'ACE 入口已无料' if gate is False else 'ACE 入口状态未知')
        if not self.ack and now - self.started_at >= self.ACK_TIMEOUT_S:
            raise FeedSupervisionError('feed_ack_timeout', '送料指令确认超时')
        if lane == 'ready' and stamp[1] - self.status_started_at > self.READY_GUARD_S:
            raise FeedSupervisionError('head_not_reached', '本段送料已结束，喷头仍未到料')
        if now >= self.deadline:
            raise FeedSupervisionError('head_not_reached', '本次送料已超时，喷头仍未到料')
        return False

    def _query(self, method, command, params=None, deadline=None,
               cancellable=False, require_insertion=False, owned_motion=False):
        def guard():
            self._check_identity(require_insertion=require_insertion)
            if cancellable and self.cancelled:
                raise FeedSupervisionError('cancelled', '已取消本次送料预检，未开始长推')
        guard()
        box = []
        token = self.token

        def callback(*args, **kwargs):
            if self.active and self.token is token:
                box.append(kwargs.get('response', args[-1] if args else None))
        request = {'method': method, 'params': params or {},
                   '_insert_stop_transport': self.transport, '_insert_reject': callback}
        if owned_motion:
            request.update(_feed_supervisor=self, _feed_supervisor_token=self.token)
        self.ace.send_request_to(self.idx, request, callback)
        end = min(deadline, self.ace.reactor.monotonic() + 1.0) if deadline is not None else self.ace.reactor.monotonic() + 1.0
        while not box and self.ace.reactor.monotonic() < end:
            guard()
            self.ace.reactor.pause(min(end, self.ace.reactor.monotonic() + 0.02))
        guard()
        if (not box or not self._ok(box[0], command)
                or type(request.get('id')) is not int
                or type(box[0].get('id')) is not int or box[0]['id'] != request['id']):
            if cancellable:
                raise FeedSupervisionError('preflight_unavailable', '送料前的新鲜状态不可用，未开始长推')
            raise FeedSupervisionError('stop_evidence_unavailable', '停止确认遥测不可用')
        return box[0]

    def stop_bound(self, *, before_retry=False):
        """Original transport STOP ACK plus fresh per-slot stationary samples."""
        self.stopping = True
        self.pending = None  # Late in-flight feeding polls cannot mutate evidence.
        self.terminal_sample = self.terminal_slot_status = None
        self.terminal_only_mm = None
        try:
            receipt = stop_and_verify(self.ace, self.idx, self.slot,
                transport=self.transport, identity=self.identity, timeout=self.STOP_VERIFY_S,
                ready_status_only=self.feed_admitted)
            self.terminal_sample = receipt['sample']
            self.terminal_slot_status = receipt['slot_status']
            self.result = 'stopped'
            if self.feed_admitted and self.ack and self.terminal_slot_status == 'ready':
                # STOP and slot READY already established completion. Sample once
                # for the unload ledger; a missing counter cannot veto arrival.
                try:
                    reply = self._query('get_feed_info', 76)
                    self.terminal_sample = self._decode(reply)
                    if self.terminal_sample is not None:
                        now = self.ace.reactor.monotonic()
                        self._observe(self.terminal_sample, now)
                        if self.observed_samples == 1:
                            self._use_terminal_counter(now, before_retry=before_retry)
                except Exception as exc:
                    self._measurement_issue(str(exc))
                self._check_identity()
            if self.feed_admitted and self.ack:
                logging.info('[multiACE feed-endpoint] end ACE=%d slot=%d head=%d status=%s sample=%s',
                             self.idx, self.slot, self.head, self.terminal_slot_status, self.terminal_sample)
                if self.terminal_sample is None and self.terminal_slot_status == 'ready':
                    self._measurement_issue('缺少送料终点的有效编码器读数')
                elif self.terminal_sample and self.terminal_slot_status == 'ready':
                    motor, decoder, _ = self.terminal_sample
                    if motor <= 0 or abs(decoder) < motor * self.MIN_PROGRESS_RATIO:
                        self._measurement_issue('终点测量轮读数偏低，本次距离未确认')
            return
        except StopUnconfirmedError:
            self.result = 'stop_unconfirmed'
            raise

    def _use_terminal_counter(self, now, *, before_retry=False):
        # The ACE resets this counter for each finite feed. With no usable
        # start frame, require observed native forward motion on this slot and
        # a real head arrival, or a stopped attempt that will be retried.
        motor, decoder, steps = self.terminal_sample
        direction = 1 if decoder > 0 else -1
        limit = min(self.length, self.speed * max(0., now - self.started_at) * 1.25 + 25.)
        head = self.sensor()
        if (not self.forward_status_seen or self.gate() is not True
                or (head is not True and (not before_retry or head is not False))
                or steps <= 0 or not 0 < motor <= limit or not 0 < abs(decoder) <= limit
                or abs(decoder) < motor * self.MIN_PROGRESS_RATIO
                or self.known_decoder_sign not in (None, direction)):
            self._measurement_issue('本次送料终点读数无法和送达动作对应')
            return
        self.decoder_sign = direction
        self.terminal_only_mm = abs(decoder)

    def observed_forward_mm(self):
        """Lower bound from this command's actual forward material samples."""
        if (not self.ack or not self.feed_admitted or self.cancelled
                or self.terminal_sample is None or self.terminal_slot_status != 'ready'
                or self.measurement_error or self.origin_sample is None
                or self.decoder_sign not in (-1, 1)):
            return None
        if self.observed_samples < 2:
            return self.terminal_only_mm
        distance = (self.terminal_sample[1] - self.origin_sample[1]) * self.decoder_sign
        # Reject a pre-reset sample from the preceding reverse command.
        distance = min(distance, self.terminal_sample[1] * self.decoder_sign)
        return distance if math.isfinite(distance) and 0 < distance <= self.length else None

    def short_backoff(self, configured_mm=None):
        """Return measured reverse travel when a fresh endpoint is available."""
        a = self.ace
        before = self.terminal_sample
        manual = configured_mm is None
        length = self.BACKOFF_MM if manual else configured_mm
        self._check_identity()
        if (self.terminal_slot_status != 'ready' or self.sensor() is not False
                or self.gate() is not True or self.cancelled):
            raise FeedSupervisionError('backoff_unavailable', '原槽状态改变，已结束重试')
        if manual and (before is None or before[0] <= length + 1 or self.retry_backoff_mm is not None):
            raise FeedSupervisionError('backoff_unavailable', '原槽短退条件不足，请检查卡点')
        if length == 0:
            return None
        speed = self.BACKOFF_SPEED if manual else a.get_retract_speed(self.idx)
        if not 0 < length < 0xFFFFFFFF or not math.isfinite(speed) or speed <= 0:
            raise FeedSupervisionError('invalid_motion_budget', '原槽短退长度或速度无效')
        polarity = self.decoder_sign
        deadline = a.reactor.monotonic() + length / speed + 4.0
        self.pending = None
        self.stopping = False
        self.result = 'retry_backoff'
        self.backoff_params = {'index': self.slot, 'length': length, 'speed': speed}
        self.terminal_sample = self.terminal_slot_status = None
        seen_rollback = False
        try:
            self._query('unwind_filament', 8, dict(self.backoff_params), deadline=deadline,
                        cancellable=True, require_insertion=True, owned_motion=True)
            ready_after = a.reactor.monotonic() + length / speed + .3
            while a.reactor.monotonic() < deadline:
                if self.sensor() is not False or self.gate() is not True:
                    raise FeedSupervisionError('backoff_changed', '短退期间原槽入口或到料状态改变')
                reply = self._query('get_status', 6, deadline=deadline,
                                    cancellable=True, require_insertion=True)
                status = reply.get('result') or {}
                rows = [r for r in status.get('slots', [])
                        if isinstance(r, dict) and r.get('index') == self.slot]
                if (status.get('_status_wire_valid') is not True or len(rows) != 1
                        or rows[0].get('_wire_valid') is not True):
                    raise FeedSupervisionError('backoff_invalid', '短退原槽状态未确认')
                lane = rows[0].get('slot_status')
                if lane == 'rollback':
                    seen_rollback = True
                elif lane == 'ready' and (seen_rollback or (not manual and a.reactor.monotonic() >= ready_after)):
                    break
                elif lane != 'ready':
                    raise FeedSupervisionError('backoff_fault', '短退原槽状态异常：%s' % lane)
                a.reactor.pause(min(deadline, a.reactor.monotonic() + .1))
            else:
                raise FeedSupervisionError('backoff_incomplete', '短退未在时限内完成')
        finally:
            self.backoff_params = None
            self.stopping = True
            # The reverse has its own counters. Do not extend the forward
            # measurement using the post-reverse STOP samples.
            try:
                receipt = stop_and_verify(a, self.idx, self.slot, transport=self.transport,
                                          identity=self.identity, timeout=self.STOP_VERIFY_S,
                                          ready_status_only=not manual)
            except StopUnconfirmedError:
                self.result = 'stop_unconfirmed'
                raise
            self.terminal_sample = receipt['sample']
            self.terminal_slot_status = receipt['slot_status']
        self._check_identity()
        if (not self.backoff_admitted or self.cancelled or self.sensor() is not False
                or self.gate() is not True or self.terminal_slot_status != 'ready'):
            raise FeedSupervisionError('backoff_unverified', '短退后原槽状态未确认')
        if not manual:
            # Slot status already proved completion. This optional endpoint
            # read is for distance accounting only and cannot veto the retry.
            try:
                sample = self._decode(self._query('get_feed_info', 76))
            except Exception as exc:
                logging.debug('[multiACE] optional retry reverse sample unavailable: %s', exc)
                sample = None
            if sample is not None and polarity in (-1, 1):
                motor, decoder, steps = sample
                backoff = -decoder * polarity
                if steps > 0 and 0 < motor <= length + 1 and 0 < backoff <= length + 1:
                    return backoff
            return None
        motor, decoder, steps = self.terminal_sample
        if polarity is None and decoder:
            polarity = 1 if decoder < 0 else -1
        backoff = -decoder * polarity if polarity is not None else 0
        if (not 0 < motor <= self.BACKOFF_MM + 1 or not 0 < steps < before[2]
                or not 8 <= backoff <= self.BACKOFF_MM + 1):
            raise FeedSupervisionError('backoff_unverified', '短退后实际反向位移或停稳未确认')
        self.retry_backoff_mm = backoff
        logging.info('[multiACE] verified ACE %d slot %d reverse %.1f mm before one retry',
                     self.idx, self.slot, backoff)
        return backoff

    def travel_receipt(self):
        """Observed material travel, never commanded distance."""
        distance = self.observed_forward_mm()
        if self.error is not None or distance is None:
            return None
        basis = 'observed_span_lower_bound'
        if self.terminal_only_mm is not None:
            basis = 'observed_feed_end'
        elif not self.after_retry and self.origin_sample[:3] == (0.0, 0.0, 0):
            basis = 'observed_zero_origin'
        distance += self.prior_observed_mm
        if distance <= 0:
            return None
        return {'distance_mm': distance,
                'basis': basis,
                'samples': self.observed_samples, 'seq': self.seq,
                'ace': self.idx, 'slot': self.slot, 'head': self.head,
                'uid': list(self.identity[1]), 'insert_epoch': self.insertion_epoch,
                'forward_decoder_sign': self.decoder_sign}

    def snapshot(self):
        return {'ace': self.idx, 'slot': self.slot, 'head': self.head,
                'seq': self.seq, 'kind': 'feed', 'active': self.active,
                'epoch': self.epoch,
                'message': ('原槽低速短退，待实测后重试' if self.result == 'retry_backoff'
                            else str(self.error) if self.error is not None else self.result),
                'state': self.result, 'cancelled': self.cancelled,
                'code': self.error.code if self.error is not None else None,
                'motor_mm': self.last_sample[0] if self.last_sample else None,
                'decoder_mm': self.last_sample[1] if self.last_sample else None,
                'bad_windows': 0,  # Retained for existing status clients.
                'retry_backoff_mm': self.retry_backoff_mm,
                'travel_receipt': self.travel_receipt(),
                'measurement_error': self.measurement_error,
                'terminal_slot_status': self.terminal_slot_status,
                'stop_verified': self.terminal_slot_status is not None}

    def close(self):
        self.active = False
        self.pending = None
        self.token = None
        owners = getattr(self.ace, '_feed_supervisors', {})
        if owners.get((self.idx, self.slot)) is self:
            del owners[(self.idx, self.slot)]
        results = getattr(self.ace, '_feed_supervisor_results', None)
        if results is None:
            self.ace._feed_supervisor_results = results = {}
        results[(self.idx, self.slot)] = self.snapshot()
