"""Connection-scoped ACE dryer control. All deadlines use Klipper's reactor."""
import logging
import uuid

from .ace_flow_guard import configured_route_heads, dynamic_route_blocked, raw_head_state, source_conflict
from .ace_error_recovery import _motion_request


class DryerTimeout(RuntimeError):
    """No valid acknowledgement arrived before the request deadline."""


class DryCycles:
    CLOSED_SECONDS = 240.
    VENT_SECONDS = 45.
    ACK_TIMEOUT = 4.
    DEVICE_RUNNING = ('starting', 'keeping', 'drying', 'stopping', 'ptc_error', 'ntc_error')
    ACTIVE = ('starting', 'warming', 'drying', 'venting')

    def __init__(self, ace):
        self.ace = ace
        self.printing = None
        self.cycles = {}
        self.telemetry = {}
        self.pulses = {}
        self.unresolved = set()

    def restore(self, saved):
        if isinstance(saved, (list, tuple)):
            self.unresolved.update(i for i in saved if type(i) is int and 0 <= i < 4)

    def _remember(self, idx, running):
        if (idx in self.unresolved) == running:
            return
        if running:
            self.unresolved.add(idx)
        else:
            self.unresolved.discard(idx)
        if self.ace.save_variables:
            self.ace.save_variable('ace__dryer_pending', sorted(self.unresolved), write=True)

    def online(self, idx):
        a = self.ace
        return (a._connected_per_ace.get(idx) and not a._serial_failed_per_ace.get(idx)
                and idx not in a._fw_update_hold and a._serials.get(idx) is not None)

    def _live(self, idx, c):
        return (self.cycles.get(idx) is c and self.online(idx)
                and self.ace._serials.get(idx) is c['transport'])

    def _observation(self, idx):
        value = self.telemetry.get(idx)
        if (self.online(idx) and value and value[0] is self.ace._serials.get(idx)
                and 0 <= self.ace.reactor.monotonic() - value[1] <= 8.):
            return value[2]
        return {}

    def observe(self, idx, transport, info, valid, issued_at=None):
        if transport is not self.ace._serials.get(idx):
            return
        if not valid:
            self.telemetry.pop(idx, None)
            return
        now = self.ace.reactor.monotonic()
        issued_at = now if issued_at is None else issued_at
        previous = self.telemetry.get(idx)
        if previous and previous[1] > issued_at:
            return
        self.telemetry[idx] = (transport, issued_at, info)
        # Reconcile automatic ownership restored from an earlier process with
        # a NEW heartbeat. No heater start, flap or motor action is replayed.
        if idx not in self.cycles:
            observed = info.get('dryer_status') or {}
            if observed.get('status') in self.DEVICE_RUNNING or observed.get('rotisserie'):
                self._remember(idx, True)
            elif ((idx in self.unresolved or idx in self.ace._auto_dry_started)
                  and self.stopped(idx)):
                # Old installs may have only the humidity ownership marker.
                self._remember(idx, False)
                self.ace._auto_dry_release(idx, '收到设备停止确认')

    def stopped(self, idx):
        info = self._observation(idx)
        dry = info.get('dryer_status') or {}
        if self.ace._is_v2(idx):
            return (bool(info) and info.get('_dryer_stopped_confirmed') is True
                    and dry.get('status') == 'stop' and not dry.get('rotisserie'))
        return dry.get('status') == 'stop' and not dry.get('rotisserie')

    def safe_for_maintenance(self, idx):
        phase = self._visible(idx)[0]
        return (idx not in self.unresolved and idx not in self.pulses
                and phase in ('idle', 'complete') and self.stopped(idx))

    def disconnect(self, idx):
        self.telemetry.pop(idx, None)
        c = self.cycles.get(idx)
        if c and c['phase'] not in ('idle', 'complete'):
            c.update(phase='unknown', message='连接已断开，重连后请确认停止',
                     exhaust='unknown', roll_slot=None, pending=None)

    def _slot_ok(self, idx, slot, own=False, moving=False):
        a = self.ace
        if self.printing and self.printing.active():
            return False
        if not self.online(idx) or not a._is_v2(idx) or not a._rfid_identity_known(idx):
            return False
        if (getattr(a, '_homing_active', False)
                or getattr(a, '_initializing_motion_devices', False)
                or getattr(a, '_fixed_park_motion', None) or a._feed_supervisors
                or (not own and (a._insert_policy.owner or a._insert_policy.busy()))):
            return False
        operations = a._path_operations
        if any(op.phase not in ('complete', 'cancelled', 'error') for op in operations.operations.values()):
            return False
        for (unit, _), controller in operations.calibration.controllers.items():
            if unit == idx and controller.device.motion_owners:
                return False
        if a._feed_assist_per_ace.get(idx, -1) >= 0 or dynamic_route_blocked(a, idx=idx, slot=slot):
            return False
        heads = configured_route_heads(a, idx, slot)
        if not heads or any(a._head_source.get(h) or raw_head_state(a, h) is not False
                            or source_conflict(a, h, idx, slot) for h in heads):
            return False
        a._slot_actions._check(idx, slot, transport=a._serials.get(idx), own=own)
        info = self._observation(idx)
        lanes = info.get('slots') or []
        if (len(lanes) != 4 or any(lane.get('slot_status') not in (
                ('ready', 'rollback') if moving and lane.get('index') == slot else ('ready',))
                for lane in lanes)):
            return False
        feedback = a._native_buffer.status(idx, a._serials[idx], a._location_identity(idx)[1],
                                           a.reactor.monotonic())
        return (feedback['fresh'] and not feedback['assist'] and not feedback['reconnect_hold']
                and any(lane['index'] == slot and lane['inserted'] is False
                        for lane in feedback['slots']))

    def eligible(self, idx, slot, own=False, moving=False):
        try:
            return bool(self._slot_ok(idx, slot, own, moving))
        except Exception:
            # Klipper command_error can carry a printer-specific exception type.
            return False

    def _visible(self, idx):
        c = self.cycles.get(idx)
        if c and (c['phase'] != 'complete' or self.stopped(idx)):
            return c['phase'], c['message']
        status = self._observation(idx).get('dryer_status', {}).get('status')
        if status == 'stop' and not self.stopped(idx):
            return 'unknown', '等待有效的烘干停止状态'
        return {'stop': ('idle', '烘干已停止'), 'starting': ('warming', '设备正在升温'),
                'keeping': ('drying', '设备正在烘干'), 'drying': ('drying', '设备正在烘干'),
                'stopping': ('stopping', '设备正在结束烘干'),
                'ptc_error': ('error', '加热器故障'), 'ntc_error': ('error', '温度传感器故障')
               }.get(status, ('unknown', '等待烘干器状态'))

    def status(self, idx):
        c = self.cycles.get(idx) or {}
        phase, message = self._visible(idx)
        if not self.online(idx):
            phase, message = 'unknown', '设备离线'
        exhaust = bool(self.online(idx) and self.ace._is_v2(idx) and self.ace.dry_exhaust_delay > 0)
        dry = self._observation(idx).get('dryer_status', {})
        print_state = self.printing.status(idx) if self.printing else 'idle'
        confirmed_target = dry.get('target_temp')
        requested_target = c.get('target')
        if print_state == 'available':
            message = '空闲箱 · ' + message
        elif print_state == 'limited':
            cap = self.printing.limit(idx)
            if phase in self.ACTIVE:
                message = '打印中限温 %s°C · 原设 %s°C · 当前目标 %s°C' % (
                    cap or '—', requested_target or '—', confirmed_target or '—')
            else:
                message = '打印中可限温烘干，上限 %s°C' % (cap or '—')
        elif print_state in ('preparing', 'cooling', 'reserved'):
            message = {'preparing': '正在核对打印料路', 'cooling': '正在降温，暂缓送料',
                       'reserved': '打印或续料预留，等待任务结束'}[print_state]
            if phase in ('stopping', 'unknown', 'error'):
                message += ' · ' + self._visible(idx)[1]
        return dict(target_temp=c.get('target', confirmed_target or None),
                    effective_target_temp=confirmed_target if confirmed_target else None,
                    print_mode=print_state,
                    print_allows_start=print_state in ('idle', 'available', 'limited'),
                    duration_min=c.get('minutes', dry.get('duration') or None),
                    phase=phase, message=message, cycle_id=c.get('cycle_id'),
                    requires_stop=(idx in self.unresolved or idx in self.pulses
                                   or bool(c and c['phase'] not in ('idle', 'complete'))), exhaust=c.get('exhaust', 'unknown'),
                    exhaust_supported=exhaust,
                    roll_supported=exhaust and print_state == 'idle',
                    roll_slots=[s for s in range(4) if self.eligible(idx, s)]
                               if exhaust and phase in ('idle', 'complete') else [],
                    roll_slot=c.get('roll_slot'), roll_count=c.get('roll_count', 0),
                    max_temp=(min(self.ace.max_dryer_temperature, 55)
                              if self.ace._is_v1(idx) else self.ace.max_dryer_temperature))

    def _new(self, idx, phase, message, slot=None):
        c = dict(cycle_id=uuid.uuid4().hex, phase=phase, message=message, transport=self.ace._serials.get(idx),
                 roll_slot=slot, roll_count=0, exhaust='unknown', pending=None)
        self.cycles[idx] = c
        return c

    def _request(self, idx, c, method, params, cmd, monitor=None, pulse=None):
        if not self._live(idx, c):
            raise RuntimeError('烘干器连接已改变')
        a = self.ace
        permit = object()
        c['pending'] = permit
        request = dict(method=method, params=params, _dryer_permit=permit)
        if pulse is not None:
            request['_dryer_pulse'] = pulse
        result = []
        deadline = a.reactor.monotonic() + self.ACK_TIMEOUT
        def callback(self, response):
            if c['pending'] is permit:
                result.append((a.reactor.monotonic(), response))
        request['_insert_reject'] = callback
        try:
            a.send_request_to(idx, request, callback)
            while not result and a.reactor.monotonic() < deadline:
                if not self._live(idx, c) or c['pending'] is not permit:
                    raise RuntimeError('烘干操作已被停止或连接改变')
                if monitor:
                    monitor()
                a.reactor.pause(min(deadline, a.reactor.monotonic() + .05))
            if not self._live(idx, c) or c['pending'] is not permit:
                raise RuntimeError('烘干操作已被替换')
            request_id = request.get('id', '?')
            if not result:
                raise DryerTimeout('设备应答超时（%s id=%s）' % (method, request_id))
            received, row = result[0]
            if not isinstance(row, dict):
                raise RuntimeError('设备应答无效（%s id=%s）' % (method, request_id))
            if a._tipform_rejected(row):
                raise RuntimeError('设备拒绝指令（%s id=%s code=%s）'
                                   % (method, request_id, row.get('code')))
            if a._is_v2(idx) and (row.get('_v2_frame_valid') is not True
                    or row.get('_v2_payload_valid') is not True or row.get('_v2_command') != cmd):
                raise RuntimeError('设备确认帧无效（%s id=%s）' % (method, request_id))
            if received >= deadline:
                raise DryerTimeout('设备应答超时（%s id=%s）' % (method, request_id))
            return request_id
        finally:
            if c['pending'] is permit:
                c['pending'] = None

    def owns_motor(self, idx, request):
        pulse = self.pulses.get(idx)
        if pulse is None:
            return False
        method, params = request.get('method'), request.get('params', {})
        if params.get('index') != pulse['slot']:
            return False
        if method == 'unwind_filament':
            return (request.get('_dryer_pulse') is pulse and params.get('length') == 5
                    and params.get('speed') == 10)
        return (pulse.get('revoked') is True and method == 'stop_feed_filament'
                and request.get('_insert_stop_transport') is pulse['cycle']['transport'])

    def allows(self, idx, request, transport):
        c = self.cycles.get(idx)
        pulse = self.pulses.get(idx)
        method = request.get('method')
        if self.printing and self.printing.active():
            if method in ('drying', 'set_dry_temp'):
                params = request.get('params') or {}
                target = params.get('temp')
                try:
                    if (type(target) is not int or params.get('auto_roll', False)
                            or self.printing.temperature_for(idx, target) != target):
                        return False
                except RuntimeError:
                    return False
            if _motion_request(request) and not request.get('_dryer_pulse'):
                # A changed source cannot take over a still-hot box omitted
                # by the print's planned routes. STOP and reads remain usable.
                if not self.printing.ready_to_feed(idx):
                    return False
        if '_dryer_permit' in request:
            if (not c or not self._live(idx, c) or transport is not c['transport']
                    or request['_dryer_permit'] is not c['pending'] or c['pending'] is None):
                return False
            if (c['phase'] in self.ACTIVE and 'end' in c
                    and self.ace.reactor.monotonic() >= c['end']):
                return False
            if (request.get('method') == 'set_valve' and c['phase'] in self.ACTIVE
                    and not self._can_switch_valve(idx, c)):
                return False
        if '_dryer_pulse' in request:
            if not self.owns_motor(idx, request):
                return False
            try:
                self._monitor(idx, pulse, moving=False)
                return True
            except Exception:
                return False
        # STOP and read-only probes remain available during the short jog.
        return not (pulse and _motion_request(request))

    def _monitor(self, idx, p, moving=True):
        a = self.ace
        c, slot = p['cycle'], p['slot']
        if (not self._live(idx, c) or c['phase'] != 'venting'
                or a.reactor.monotonic() >= min(c['valve_at'], c['end'])
                or self._observation(idx).get('dryer_status', {}).get('status')
                   not in ('starting', 'keeping', 'drying')
                or self.pulses.get(idx) is not p or p.get('revoked')
                or a._location_identity(idx) != p['identity']
                or a._slot_actions.cancel or a._insert_policy.owner is not p['owner']
                or not self.eligible(idx, slot, own=True, moving=moving)):
            raise RuntimeError('回卷已取消，请检查入口、喷头和料路状态')

    def _roll(self, idx, c):
        a, slot = self.ace, c['roll_slot']
        if slot is None or not self.eligible(idx, slot):
            raise RuntimeError('回卷槽不再空闲或入口信号无效')
        actions = a._slot_actions
        with a._insert_policy.claim('dry_roll', idx, slot) as owner:
            p = dict(cycle=c, slot=slot, owner=owner, identity=a._location_identity(idx))
            self.pulses[idx] = p
            attempted = False
            try:
                monitor = lambda: self._monitor(idx, p)
                if actions._gate(idx, slot, monitor=monitor) or any(
                        state != 'ready' for state in actions._lane_states(idx, monitor=monitor).values()):
                    raise RuntimeError('入口有耗材或槽位未就绪')
                monitor()
                attempted = True
                started = a.reactor.monotonic()
                self._request(idx, c, 'unwind_filament', {'index': slot, 'length': 5, 'speed': 10},
                              8, monitor, pulse=p)
                while a.reactor.monotonic() < started + .55:
                    monitor()
                    a.reactor.pause(min(started + .55, a.reactor.monotonic() + .05))
            finally:
                p['revoked'] = True
                try:
                    if attempted:
                        if (a._serials.get(idx) is not c['transport']
                                or a._location_identity(idx) != p['identity']):
                            raise RuntimeError('回卷原设备连接改变')
                        gate = actions._eject_stop_ready(idx, slot, c['transport'], empty_path=True)
                        if gate:
                            raise RuntimeError('回卷后检测到入口有料')
                except Exception as exc:
                    a._latch_stop_fault(idx, slot, '烘干回卷停止未确认：%s' % exc,
                                        identity=p['identity'])
                    raise
                finally:
                    self.pulses.pop(idx, None)
        c['roll_count'] += 1

    def start(self, idx, target, minutes, slot=None, first=None, print_scope=None):
        a = self.ace
        phase = self._visible(idx)[0]
        if not self.online(idx) or phase not in ('idle', 'complete') or not self._observation(idx):
            raise RuntimeError('请先确认烘干器在线并已停止')
        if not self.stopped(idx) or idx in self.unresolved:
            raise RuntimeError('设备正在烘干或状态未知')
        if not 35 <= target <= a.max_dryer_temperature or not 1 <= minutes <= 1440:
            raise RuntimeError('温度或烘干时长超出范围')
        if print_scope is not None:
            if (self.printing is None or self.printing.job is not print_scope
                    or not print_scope.get('dry_enabled') or slot is not None):
                raise RuntimeError('Print drying is no longer active')
        elif self.printing:
            self.printing.temperature_for(idx, target)
        if slot is not None and (not a.dry_exhaust_delay or not self.eligible(idx, slot)):
            raise RuntimeError('此槽未通过空载回卷检查')
        c = self._new(idx, 'starting', '正在启动烘干', slot)
        c.update(target=target, minutes=minutes)
        if print_scope is not None:
            c['print_scope'] = print_scope
        try:
            self._remember(idx, True)
            if not self._live(idx, c):
                raise RuntimeError('启动请求已被替换')
            self.set_temp(idx, first if first is not None else target, minutes)
            if not self._live(idx, c):
                raise RuntimeError('设备已断开')
            now = a.reactor.monotonic()
            c.update(phase='warming', message='正在升温', target=target, end=now+minutes*60.,
                     valve_at=now+a.dry_exhaust_delay,
                     acknowledged=now, seen_running=False)
            a.reactor.register_timer(lambda eventtime: self._tick(idx, c, eventtime), now+1.)
        except Exception as exc:
            if self.cycles.get(idx) is c:
                c.update(phase='unknown', message='启动未确认，请停止并复核：%s' % exc)
            raise

    def set_temp(self, idx, temp, minutes):
        c = self.cycles[idx]
        if c['phase'] not in self.ACTIVE or not 35 <= temp <= self.ace.max_dryer_temperature:
            raise RuntimeError('当前阶段不能调整烘干温度')
        requested = temp
        if self.printing:
            temp = self.printing.temperature_for(idx, temp)
        if self.ace._is_v2(idx) and c['phase'] != 'starting':
            # CMD12 changes only the temperature. CMD11 also writes the duration.
            self._request(idx, c, 'set_dry_temp', dict(temp=temp), 12)
        else:
            self._request(idx, c, 'drying', dict(temp=temp, duration=minutes, fan_speed=7000,
                                                 auto_roll=False), 11)
        c['effective_target'] = temp
        c['print_limited'] = temp < requested or c.get('print_limited', False)

    def stop(self, idx, detail=None):
        a = self.ace
        old = self.cycles.get(idx) or {}
        c = self._new(idx, 'stopping', '正在停止烘干')
        c.update(cycle_id=old.get('cycle_id') or c['cycle_id'], target=old.get('target'),
                 minutes=old.get('minutes'), roll_count=old.get('roll_count', 0), exhaust=old.get('exhaust', 'unknown'))
        c['effective_target'] = old.get('effective_target')
        try:
            self._remember(idx, True)
            try:
                self._request(idx, c, 'drying_stop', {}, 11)
            finally:
                # A missing heater reply cannot rule out an open flap. Close
                # it only while this stop still owns the original connection.
                if (self._live(idx, c) and c['phase'] == 'stopping'
                        and a._is_v2(idx) and a.dry_exhaust_delay):
                    self._request(idx, c, 'set_valve', dict(v1=False, v2=False), 66)
                    c['exhaust'] = 'closed'
            deadline = a.reactor.monotonic() + 12.
            def confirm(now):
                if not self._live(idx, c) or c['phase'] != 'stopping':
                    return a.reactor.NEVER
                observed = self.telemetry.get(idx)
                if (observed and observed[1] > since and self.stopped(idx)
                        and idx not in self.pulses):
                    self._remember(idx, False)
                    c.update(phase='error' if detail else 'complete', message=detail or '烘干已停止')
                    return a.reactor.NEVER
                if now >= deadline:
                    c.update(phase='unknown', message='停止状态未确认，请复核设备并重试停止')
                    return a.reactor.NEVER
                return now + .5
            since = a.reactor.monotonic()
            a.reactor.register_timer(confirm, since + .5)
        except Exception as exc:
            if self.cycles.get(idx) is c:
                c.update(phase='unknown', message='停止未确认：%s' % exc, exhaust='unknown')
            raise

    def _can_switch_valve(self, idx, c):
        return (self._live(idx, c) and c['phase'] in self.ACTIVE
                and self.ace.reactor.monotonic() < c['end']
                and self._observation(idx).get('dryer_status', {}).get('status')
                    in ('starting', 'keeping', 'drying'))

    def _switch_valve(self, idx, c, opening):
        direction = 'open' if opening else 'close'
        for attempt in (1, 2):
            try:
                seq = self._request(idx, c, 'set_valve', dict(v1=opening, v2=opening), 66)
            except Exception as exc:
                logging.warning('[multiACE] dryer ACE %d cycle=%s valve=%s attempt=%d: %s',
                                idx, c['cycle_id'], direction, attempt, exc)
                if not (isinstance(exc, DryerTimeout) and attempt == 1
                        and self._can_switch_valve(idx, c)):
                    raise
            else:
                if attempt == 2:
                    logging.info('[multiACE] dryer ACE %d cycle=%s valve=%s recovered attempt=%d id=%s',
                                 idx, c['cycle_id'], direction, attempt, seq)
                return

    def _update_exhaust(self, idx, c, now):
        if (not c['seen_running'] or now < c['valve_at'] or c['pending'] is not None
                or idx in self.pulses):
            return
        # Unknown on startup: close after firmware self-test, then start the
        # first full drying interval from the valve acknowledgement.
        opening = c['exhaust'] == 'closed'
        self._switch_valve(idx, c, opening)
        confirmed = self.ace.reactor.monotonic()
        if opening:
            c.update(exhaust='open', phase='venting', message='开门排湿',
                     valve_at=confirmed + self.VENT_SECONDS)
            if c['roll_slot'] is not None and confirmed < c['end']:
                self._roll(idx, c)
        else:
            c.update(exhaust='closed', phase='drying', message='关门烘干',
                     valve_at=confirmed + self.CLOSED_SECONDS)

    def _reconcile_print_temperature(self, idx, c, info, now):
        policy = self.printing
        if policy.active():
            c['roll_slot'] = None
        if c['pending'] is not None or policy.planning():
            return
        cap = policy.limit(idx)
        if cap == 0:
            self.stop(idx)
            self.ace._auto_dry_release(idx, '打印预留')
            return
        current = c.get('effective_target', c['target'])
        reported = info['dryer_status'].get('target_temp') or 0
        box_temp = info.get('temp')
        if (cap is not None and policy.job and policy.job['started']
                and type(box_temp) in (int, float) and box_temp > cap):
            raise RuntimeError('供料箱实际温度高于打印限温')
        if cap is not None and (current > cap or reported > cap):
            pending = c.get('derate_confirmation')
            if pending:
                if now >= pending:
                    raise RuntimeError('打印限温未获设备确认')
                return
            target = min(c['target'], cap)
            self.set_temp(idx, target, c['minutes'])
            c['print_limited'] = True
            c['derate_confirmation'] = self.ace.reactor.monotonic() + 12.
        elif cap is None and c.get('print_limited'):
            self.set_temp(idx, c['target'], c['minutes'])
            c['print_limited'] = False
            c.pop('derate_confirmation', None)
        else:
            c.pop('derate_confirmation', None)

    def _tick(self, idx, c, now):
        a = self.ace
        if not self._live(idx, c) or c['phase'] not in self.ACTIVE:
            return a.reactor.NEVER
        try:
            info = self._observation(idx)
            state = info.get('dryer_status', {}).get('status')
            if state in ('ptc_error', 'ntc_error'):
                raise RuntimeError('加热器或温度传感器故障')
            if state == 'stopping':
                self.stop(idx)
                a._auto_dry_release(idx, '设备正在停止')
                return a.reactor.NEVER
            if state in ('starting', 'keeping', 'drying'):
                c['seen_running'] = True
            if (now >= c['end'] or (self.stopped(idx) and c['seen_running'])):
                self.stop(idx)
                a._auto_dry_release(idx, '烘干结束')
                return a.reactor.NEVER
            if (state == 'stop' and not self.stopped(idx)):
                raise RuntimeError('设备停止状态无效')
            if (not info or state not in ('starting', 'keeping', 'drying', 'stop', 'stopping')
                    or (not c['seen_running'] and now-c['acknowledged'] > 15.)):
                raise RuntimeError('未收到有效的烘干运行状态')
            if self.printing:
                self._reconcile_print_temperature(idx, c, info, now)
                if not self._live(idx, c):
                    return a.reactor.NEVER
                if (c.get('print_scope') is not None and self.printing.owns_cycle(idx)
                        and not c['pending'] and now + 300. >= c['end']
                        and state in ('starting', 'keeping', 'drying')):
                    self._request(idx, c, 'drying', dict(temp=c['target'], duration=c['minutes'],
                                                        fan_speed=7000, auto_roll=False), 11)
                    c['end'] = a.reactor.monotonic() + c['minutes'] * 60.
            if a._is_v2(idx) and a.dry_exhaust_delay > 0:
                self._update_exhaust(idx, c, now)
            elif state in ('keeping', 'drying'):
                c.update(phase='drying', message='正在烘干')
            if not self._live(idx, c):
                return a.reactor.NEVER
            if a.reactor.monotonic() >= c['end']:
                self.stop(idx)
                a._auto_dry_release(idx, '烘干结束')
                return a.reactor.NEVER
            return a.reactor.monotonic() + 1.
        except Exception as exc:
            if self._live(idx, c) and c['phase'] in self.ACTIVE:
                logging.warning('[multiACE] dryer ACE %d cycle=%s stopped during %s: %s',
                                idx, c['cycle_id'], c['phase'], exc)
                try:
                    self.stop(idx, '烘干已中止：%s' % exc)
                except Exception:
                    logging.warning('[multiACE] dryer shutdown unconfirmed on %d: %s', idx, self.cycles[idx]['message'])
                a._auto_dry_release(idx, '烘干异常')
            return a.reactor.NEVER
