"""One-slot STOP with fresh V2 evidence, shared by feed and buffer handoff.

The first STOP is immediate. A second STOP after the setup window handles a
firmware task that accepted the first request before its motor was armed.
Neither an ACK nor cached ready releases ownership on its own.
"""
from collections import deque
import logging
import math

from .ace_stop_guard import StopUnconfirmedError


STOPPED = frozenset(('ready', 'feed_error', 'rollback_error', 'assist_error',
                    'preload_error', 'stuck_error', 'tangled_error', 'motor_error'))
STOP_DEFAULT_ZERO_MM = 2
DECODER_UNAVAILABLE_MESSAGE = 'CMD76 缺少耗材编码器，未用电机距离代替'
DECODER_UNAVAILABLE_REASONS = frozenset((
    DECODER_UNAVAILABLE_MESSAGE,
    'CMD76 未提供有效耗材编码器，不能用电机长度代替',
))


def assist_stop_keys(result, slot):
    """Return stable inlet evidence; buffer switches do not gate a stopped lane."""
    keys = result.get('buffer_keys') or {}
    mask = keys.get('raw_mask')
    if (result.get('_key_wire_valid') is not True or type(mask) is not int
            or not 0 <= mask < (1 << 17)):
        raise ValueError('CMD73 缓冲信号无效')
    gate = 1 << (slot * 4)
    if not mask & gate:
        raise ValueError('原槽入口无料')
    return mask & gate


class DecoderUnavailable(ValueError):
    def __init__(self, row):
        super().__init__(DECODER_UNAVAILABLE_MESSAGE)
        self.motor_counters = row['steps'], row['length']


def decode_sample(response, slot, allow_empty_zero=False, ready_zero_mm=None):
    result = response.get('result') or {}
    rows = result.get('feed_info')
    if result.get('_feed_wire_valid') is not True or not isinstance(rows, list):
        raise ValueError('CMD76 编码器帧无效')
    rows = [row for row in rows if isinstance(row, dict)
            and type(row.get('index')) is int and row['index'] == slot]
    if len(rows) != 1 or rows[0].get('_wire_valid') is not True:
        raise ValueError('CMD76 原槽反馈缺失或重复')
    row = rows[0]
    if any(type(row.get(key)) is not int or not 0 <= row[key] < (1 << 64)
           for key in ('steps', 'length', 'decoder')):
        raise ValueError('CMD76 计数无效')
    if row.get('_decoder_present') is False and row['decoder'] == 0:
        if not ((allow_empty_zero and row['length'] == row['steps'] == 0)
                or (ready_zero_mm is not None and row['length'] <= ready_zero_mm)):
            raise DecoderUnavailable(row)
    elif row.get('_decoder_present') is not True:
        raise ValueError('CMD76 缺少耗材编码器，未用电机距离代替')
    decoder = row['decoder'] - (1 << 64) if row['decoder'] >= (1 << 63) else row['decoder']
    return float(row['length']), float(decoder), row['steps']


def stop_and_verify(ace, idx, slot, *, transport=None, identity=None,
                    timeout=3.0, monitor=None, ready_zero_mm=None,
                    ready_without_decoder=False, stopped_assist_without_decoder=False,
                    trace_failure=False, stock_unload=False, assist_handoff=False,
                    ready_status_only=False, stopped_fault_without_decoder=False):
    """Return a target-lane stillness receipt; retain a fault on uncertainty.

Other slots may keep assisting their own toolheads. This receipt says nothing
about an empty tube, a cleared mechanical fault, or the position of a Y joint.
The caller must inhibit rearming its own slot until its transaction finishes.
"""
    if (type(idx) is not int or not 0 <= idx < 4 or type(slot) is not int
            or not 0 <= slot < 4 or type(timeout) not in (int, float)
            or not math.isfinite(timeout) or timeout <= 0):
        raise ValueError('停止目标或时限无效')
    reactor = ace.reactor
    transport = ace._serials.get(idx) if transport is None else transport
    identity = ace._location_identity(idx) if identity is None else identity
    started = reactor.monotonic()
    deadline = started + timeout
    wire_trace = deque(maxlen=28) if trace_failure else None
    stop_trace = [] if trace_failure else None

    def guard():
        if (transport is None or ace._serials.get(idx) is not transport
                or ace._connected_per_ace.get(idx) is not True
                or getattr(ace, '_reconnecting_per_ace', {}).get(idx)
                or ace._location_identity(idx) != identity
                or not isinstance(identity, (tuple, list)) or len(identity) != 2
                or not identity[0] or identity[1] is None):
            raise ValueError('原 ACE 连接或 UID 已变化，停止证据未转移到新设备')
        if reactor.monotonic() >= deadline:
            raise ValueError('停止确认超过时限')
        if monitor is not None:
            monitor()

    def query(method, command, params=None):
        guard()
        box = {'active': True, 'done': False, 'response': None}
        def callback(*args, **kwargs):
            if box['active'] and not box['done']:
                box['response'] = kwargs.get('response', args[-1] if args else None)
                box['done'] = True
        request = {'method': method, 'params': params or {},
                   '_insert_stop_transport': transport, '_insert_reject': callback}
        detail = 'no validated reply'
        try:
            accepted = ace.send_request_to(idx, request, callback)
            if accepted is False:
                raise ValueError('%s 请求被本地保护拒绝' % method)
            reply_deadline = min(deadline, reactor.monotonic() + .8)
            while not box['done'] and reactor.monotonic() < reply_deadline:
                guard()
                reactor.pause(min(reply_deadline, reactor.monotonic() + .02))
            guard()
            if not box['done']:
                raise ValueError('%s 响应超时（800ms）' % method)
            response = box['response']
            if not isinstance(response, dict):
                raise ValueError('%s 响应内容为空或格式无效' % method)
            if str(response.get('msg', '')).strip().upper() == 'FORBIDDEN':
                raise ValueError('%s 被 ACE 拒绝（FORBIDDEN）' % method)
            if type(response.get('code')) is not int:
                raise ValueError('%s 响应缺少有效 code' % method)
            if response['code'] != 0:
                raise ValueError('%s 返回错误 code=%s' % (method, response['code']))
            if response.get('_v2_command') != command:
                raise ValueError('%s 响应命令不匹配' % method)
            if response.get('_v2_frame_valid') is not True:
                raise ValueError('%s 响应帧无效' % method)
            if response.get('_v2_payload_valid') is not True:
                raise ValueError('%s 响应载荷无效' % method)
            if type(request.get('id')) is not int:
                raise ValueError('%s 请求缺少有效 ID' % method)
            if type(response.get('id')) is not int:
                raise ValueError('%s 响应缺少有效 ID' % method)
            if response['id'] != request['id']:
                raise ValueError('%s 响应 ID 与请求不匹配' % method)
            detail = 'ok'
            if trace_failure:
                result = response.get('result')
                if isinstance(result, dict):
                    if command == 6:
                        detail = lane_state(response)
                    elif command == 76:
                        rows = result.get('feed_info')
                        if isinstance(rows, list):
                            detail = [tuple(row.get(key) for key in (
                                'steps', 'length', 'decoder', '_decoder_present', '_wire_valid'))
                                for row in rows if isinstance(row, dict) and row.get('index') == slot]
                    elif command == 73:
                        keys = result.get('buffer_keys')
                        if isinstance(keys, dict):
                            detail = (result.get('_key_wire_valid'), keys.get('raw_mask'))
            return response
        except ValueError as exc:
            detail = str(exc)
            raise
        finally:
            box['active'] = False
            if trace_failure:
                row = (round(reactor.monotonic() - started, 3), command, request.get('id'), detail)
                (stop_trace if command == 9 else wire_trace).append(row)

    def lane_state(response):
        result = response.get('result') or {}
        rows = result.get('slots')
        if result.get('_status_wire_valid') is not True or not isinstance(rows, list):
            raise ValueError('CMD6 槽位状态帧无效')
        rows = [row for row in rows if isinstance(row, dict)
                and type(row.get('index')) is int and row['index'] == slot]
        if len(rows) != 1 or rows[0].get('_wire_valid') is not True:
            raise ValueError('CMD6 原槽状态缺失或重复')
        return rows[0].get('slot_status')

    try:
        # An uncertain first ACK is retryable because STOP is idempotent.
        first_error = None
        try:
            query('stop_feed_filament', 9, {'index': slot})
        except ValueError as exc:
            first_error = str(exc)
        while reactor.monotonic() < started + .25:
            guard()
            reactor.pause(min(started + .25, reactor.monotonic() + .05))
        try:
            query('stop_feed_filament', 9, {'index': slot})
        except ValueError:
            # This is the STOP sent after the setup window. An invalid
            # reply does not invalidate the channel, but we still require
            # a fresh accepted STOP in that window and later standstill.
            query('stop_feed_filament', 9, {'index': slot})
        acknowledged_at = reactor.monotonic()
        previous = None
        stable_since = None
        count = 0
        last_error = first_error
        while reactor.monotonic() < deadline:
            guard()
            try:
                state = lane_state(query('get_status', 6))
                gates = ace._gate_status_per_ace.get(idx) or []
                empty = slot < len(gates) and gates[slot] == 0
                motor_counters = None
                keys = None
                sample = None
                # A confirmed STOP followed by stable READY can release
                # this slot without providing a distance receipt.
                if (stock_unload or ready_status_only) and state == 'ready':
                    pass
                elif stock_unload and assist_handoff and state == 'assist_error':
                    # Only the trusted source's handoff to a finite rollback
                    # uses this receipt. Stable 0x83 after ACKed STOP carries
                    # the same command-readiness evidence as stable READY;
                    # ignore the buffer bits and keep the inlet check.
                    keys = assist_stop_keys(query('get_key_state', 73)['result'], slot)
                else:
                    try:
                        sample = decode_sample(query('get_feed_info', 76), slot,
                                               allow_empty_zero=empty and state == 'ready',
                                               ready_zero_mm=ready_zero_mm if state == 'ready' else None)
                    except DecoderUnavailable as exc:
                        if state == 'assist_error' and stopped_assist_without_decoder:
                            keys = assist_stop_keys(query('get_key_state', 73)['result'], slot)
                        elif not ((state == 'ready' and ready_without_decoder)
                                  or (state in STOPPED and state != 'ready'
                                      and stopped_fault_without_decoder)):
                            raise
                        motor_counters = exc.motor_counters
                after = lane_state(query('get_status', 6))
                now = reactor.monotonic()
                current = (state, sample, motor_counters, keys)
                if state not in STOPPED or after != state:
                    previous, stable_since, count = None, None, 0
                elif current == previous:
                    count += 1
                else:
                    previous, stable_since, count = current, now, 1
                if count >= 3 and now - stable_since >= .3:
                    guard()
                    if motor_counters is not None:
                        logging.info('[multiACE] ACE %d slot %d stop: %s and unchanged motor'
                                     ' counters in %d samples (steps=%d, mm=%d); decoder omitted',
                                     idx + 1, slot + 1, state, count, *motor_counters)
                    return {'slot_status': state, 'sample': sample, 'at': now,
                            'motor_counters': motor_counters,
                            'acknowledged_at': acknowledged_at, 'samples': count,
                            'transport': transport, 'identity': identity,
                            'first_stop_error': first_error}
            except ValueError as exc:
                # Read-only queries may be retried within the same finite deadline.
                # A missed response cannot become a stationary sample.
                guard()
                last_error = str(exc)
                previous, stable_since, count = None, None, 0
            reactor.pause(min(deadline, reactor.monotonic() + .15))
        raise ValueError(last_error or '停止后仍在运动或缺少连续静止证据')
    except Exception as exc:
        if trace_failure:
            logging.info('[multiACE] ACE %d slot %d stock tip STOP trace '
                         '(seconds, command, id, reply): stop=%s samples=%s',
                         idx + 1, slot + 1, stop_trace, list(wire_trace))
        ace._latch_stop_fault(idx, slot, str(exc), identity=identity)
        raise StopUnconfirmedError('ACE %d 槽 %d 停止未确认：%s' %
                                   (idx + 1, slot + 1, exc)) from exc
