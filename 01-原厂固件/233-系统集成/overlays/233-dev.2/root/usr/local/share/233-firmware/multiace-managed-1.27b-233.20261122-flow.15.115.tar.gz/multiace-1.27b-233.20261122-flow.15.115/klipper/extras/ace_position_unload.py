"""Bounded original-route unload admission for a held, loaded ACE path."""
import copy

from .ace_flow_guard import dynamic_route_blocked, raw_head_state, source_conflict, source_route


PROBE_MM = 150
PROBE_BUDGET_MM = 450
ASSIST_SPEED_MAX = 50
SESSION_TIMEOUT_S = 480
LIVE_SLOT_STATES = frozenset(('ready', 'assisting', 'rollback_assisting'))


class PositionUnloadRecovery:
    """Permit only the existing sensor-verified unload on one held route."""

    def __init__(self, ace):
        self.ace = ace
        self.active = None
        self.handoff = None

    def _eject_hold(self, slot, head, identity):
        hold = getattr(self.ace, '_location_hold', None)
        if hold is None or not hold.refresh_routes():
            return None
        exact = [row for row in hold.routes
                 if hold._same_route(row, identity[0], identity[1], slot)]
        if len(exact) != 1 or exact[0].get('scope', 'ace') != 'route':
            return None
        if exact[0].get('heads') != [head]:
            return None
        for row in hold.routes:
            if row is exact[0]:
                continue
            if (row.get('heads') is None or head in row.get('heads', ())
                    or row.get('scope', 'ace') == 'ace'
                    and (row.get('port') == identity[0]
                         or tuple(row.get('uid', ())) == identity[1])):
                return None
        # Only a matching record can be handed off to the full eject flow.
        return (identity[0], tuple(identity[1]), slot, head)

    def prepare(self, head, stage='all'):
        a = self.ace
        if (type(head) is not int or not 0 <= head < 4 or stage != 'all'
                or self.active is not None or not a.head_uses_ace(head)):
            return None
        source = a._head_source.get(head)
        route = source_route(source)
        # The live head, physical ACE identity, and current route mapping
        # authorize reversal; historical load/session flags do not override them.
        if route is None:
            return None
        idx, slot = route
        if not dynamic_route_blocked(a, head=head, idx=idx, slot=slot):
            return None
        if (not a._is_v2_idx(idx) or not a._connected_per_ace.get(idx)
                or a._serial_failed_per_ace.get(idx)
                or a._reconnecting_per_ace.get(idx)):
            return None
        transport = a._serials.get(idx)
        identity = a._location_identity(idx)
        physical = a._rfid_identity_status(idx)
        if (transport is None or physical is None
                or identity != (physical.get('port'), tuple(physical.get('uid', ())))
                or source.get('connection_identity') != physical
                or raw_head_state(a, head) is not True
                or tuple(a._rfid_route_heads(idx, slot) or ()) != (head,)
                or source_conflict(a, head, idx, slot)
                or a._stop_message(idx, slot, head) is not None):
            return None
        ps = a.printer.lookup_object('print_stats', None)
        state = (getattr(ps, 'state', '') or '').lower()
        if (state not in ('standby', 'complete', 'cancelled', 'paused', 'error', 'printing')
                or state == 'printing' and not a._swap_in_progress):
            return None
        action = getattr(a, '_slot_actions', None)
        task = getattr(action, 'state', {}) or {}
        if (task.get('state') in ('running', 'preparing')
                and not (task.get('kind') == 'eject' and task.get('state') == 'preparing'
                         and (task.get('ace'), task.get('slot')) == route)):
            return None
        if (getattr(a, '_tag_read_busy', False) or getattr(a, '_unload_all_active', False)
                or getattr(getattr(a, '_path_calibration', None), 'task', {}).get('active')):
            return None
        if self._peer_assisting(idx, slot, transport, identity):
            return None
        if a._v2_get_slot_status(idx, slot) != 'ready':
            return None
        return {
            'head': head, 'idx': idx, 'slot': slot, 'transport': transport,
            'identity': (identity[0], tuple(identity[1])),
            'source': copy.deepcopy(source), 'insert_epoch': (a._insert_epochs or {}).get((idx, slot)),
            'insert_session': getattr(a, '_insert_session', None),
            'token': object(), 'used_mm': 0,
            'speed_limit': max(1, int(a.get_retract_speed(idx))),
        }

    def _peer_assisting(self, idx, slot, transport, identity):
        buffer = self.ace._native_buffer.status(
            idx, transport, identity[1], self.ace.reactor.monotonic())
        return any(item.get('slot') != slot and item.get('phase') in
                   ('pending', 'armed', 'assisting', 'rollback_assisting')
                   for item in buffer.get('assist', ()))

    def _same_live_source(self, owner):
        a = self.ace
        head, idx, slot = owner['head'], owner['idx'], owner['slot']
        return (a._serials.get(idx) is owner['transport']
                and a._connected_per_ace.get(idx)
                and not a._serial_failed_per_ace.get(idx)
                and not a._reconnecting_per_ace.get(idx)
                and a._location_identity(idx) == owner['identity']
                and a._head_source.get(head) == owner['source']
                and source_route(owner['source']) == (idx, slot)
                and tuple(a._rfid_route_heads(idx, slot) or ()) == (head,)
                and not source_conflict(a, head, idx, slot)
                and a._stop_message(idx, slot, head) is None)

    def _live(self, owner, idx, request, serial):
        a = self.ace
        if (self.active is not owner or serial is not owner['transport']
                or idx != owner['idx'] or a.reactor.monotonic() >= owner['deadline']
                or not self._same_live_source(owner)
                or raw_head_state(a, owner['head']) is not True):
            return False
        # A full or stale buffer is not a source conflict. Reverse assist is
        # what relieves buffer pressure; the ACE still enforces its end stops.
        if self._peer_assisting(idx, owner['slot'], serial, owner['identity']):
            return False
        lane_state = a._v2_get_slot_status(idx, owner['slot'])
        if lane_state not in LIVE_SLOT_STATES:
            return False
        params = request.get('params') or {}
        if params.get('index') != owner['slot']:
            return False
        method = request.get('method')
        if method == 'unwind_filament':
            length, speed = params.get('length'), params.get('speed')
            return (type(length) is int and 0 < length <= PROBE_MM
                    and type(speed) is int and 0 < speed <= owner['speed_limit']
                    and owner['used_mm'] + length <= PROBE_BUDGET_MM)
        if method == 'start_feed_assist':
            return params.get('speed', 10) == 10 and len(params) <= 2
        if method == 'feed_or_rollback_raw':
            return (params.get('mode') == 3 and params.get('length') == 0
                    and type(params.get('speed')) is int
                    and 1 <= params['speed'] <= ASSIST_SPEED_MAX)
        if method == 'update_feeding_speed':
            return (type(params.get('speed')) is int
                    and 1 <= params['speed'] <= ASSIST_SPEED_MAX)
        return False

    def begin(self, candidate):
        if candidate is None or self.active is not None:
            raise RuntimeError('原料路恢复卸料授权不可用')
        a = self.ace
        if (not self._same_live_source(candidate)
                or raw_head_state(a, candidate['head']) is not True):
            raise RuntimeError('原设备、来源或喷头传感器已变化，未开始原槽卸料')
        if self._peer_assisting(candidate['idx'], candidate['slot'],
                                candidate['transport'], candidate['identity']):
            raise RuntimeError('同一 ACE 的其他料槽正在使用缓冲助力，未开始位置恢复卸料')
        if a._v2_get_slot_status(candidate['idx'], candidate['slot']) != 'ready':
            raise RuntimeError('原槽状态已变化，未开始位置恢复卸料')
        # The live head and original route authorize head unload. The old
        # position record is only relevant to a later full eject handoff.
        candidate['hold_token'] = self._eject_hold(candidate['slot'], candidate['head'],
                                                  candidate['identity'])
        candidate['deadline'] = a.reactor.monotonic() + SESSION_TIMEOUT_S
        candidate['sources'] = copy.deepcopy(a._head_source)
        self.handoff = None
        self.active = candidate
        return candidate

    def allows_wire(self, idx, request, serial):
        owner = self.active
        return bool(owner is not None
                    and request.get('_position_unload_token') is owner['token']
                    and self._live(owner, idx, request, serial))

    def owns_source(self, head, idx, slot):
        owner = self.active
        a = self.ace
        return (owner is not None
                and (head, idx, slot) == (owner['head'], owner['idx'], owner['slot'])
                and a.reactor.monotonic() < owner['deadline']
                and self._same_live_source(owner)
                and not self._peer_assisting(idx, slot, owner['transport'], owner['identity']))

    def allows_unload_command(self, head, idx, slot):
        return raw_head_state(self.ace, head) is True and self.owns_source(head, idx, slot)

    def stamp(self, idx, request):
        owner = self.active
        if (owner is not None and idx == owner['idx']
                and request.get('method') in ('unwind_filament', 'start_feed_assist',
                                              'feed_or_rollback_raw', 'update_feeding_speed')
                and (request.get('params') or {}).get('index') == owner['slot']):
            request['_position_unload_token'] = owner['token']

    def wrote(self, idx, request, serial):
        owner = self.active
        if (owner is not None and request.get('_position_unload_token') is owner['token']
                and idx == owner['idx'] and serial is owner['transport']
                and request.get('method') == 'unwind_filament'):
            owner['used_mm'] += (request.get('params') or {}).get('length', 0)

    def finish(self, owner):
        if self.active is owner:
            a = self.ace
            if (owner['hold_token'] is not None
                    and raw_head_state(a, owner['head']) is False
                    and self._head_cleared(a)
                    and a._serials.get(owner['idx']) is owner['transport']
                    and a._location_identity(owner['idx']) == owner['identity']
                    and a._head_source == owner.get('sources')
                    and (a._insert_epochs or {}).get((owner['idx'], owner['slot'])) == owner['insert_epoch']
                    and getattr(a, '_insert_session', None) == owner['insert_session']
                    and self._eject_hold(owner['slot'], owner['head'],
                                         owner['identity']) == owner['hold_token']):
                self.handoff = dict(owner, expires=a.reactor.monotonic() + 300.)
            self.active = None

    @staticmethod
    def _head_cleared(a):
        # distance_unknown is only set after the stock short retract and
        # toolhead probe verified that the filament cleared the sensor.
        return (getattr(a, '_last_unload_ok', False) is True
                or getattr(a, '_last_unload_reason', None) == 'distance_unknown')

    def valid_handoff(self, idx, slot, transport=None):
        owner = self.handoff
        if owner is None:
            return False
        a = self.ace
        if (a.reactor.monotonic() >= owner['expires']
                or (idx, slot) != (owner['idx'], owner['slot'])
                or transport is not None and transport is not owner['transport']
                or a._serials.get(idx) is not owner['transport']
                or a._location_identity(idx) != owner['identity']
                or a._head_source != owner.get('sources')
                or (a._insert_epochs or {}).get((idx, slot)) != owner['insert_epoch']
                or getattr(a, '_insert_session', None) != owner['insert_session']
                or raw_head_state(a, owner['head']) is not False
                or self._eject_hold(slot, owner['head'], owner['identity']) != owner['hold_token']):
            return False
        return True

    def clear_handoff(self, idx, slot):
        if self.handoff is not None and (idx, slot) == (self.handoff['idx'], self.handoff['slot']):
            self.handoff = None
