"""Run the upstream v0.16.0 updater on the one ACE port released by MultiACE."""

import asyncio
import hashlib
import os
import re
import sys
from collections import deque
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOOL = HERE / "vendor" / "ace2k_flash.pyz"
TOOL_SHA256 = "290a47cc677b9000eaf6d7edc5bcefb8947a0659ca71b5367865560dfc91547b"
IMAGES = {
    "open": ("ACE2-1.2.04O-insert-policy.bin", "V1.2.04O", "v2",
             "818200b199c1d121bd7f1919e5ca507a443b650fe0debe3ddaf6d77e3b5d3251"),
    "ace2k": ("ace2k-0.16.0-233b.bin", "0.16.0-233b", "ace2k",
              "6f4a0e38c481fb0fc057031bb05bdb07900d4f9f64a2007d12c80c7ff59d6d18"),
}


def verify_files(target):
    filename, _, _, expected = IMAGES[target]
    for path, digest in ((HERE / "firmware" / filename, expected), (TOOL, TOOL_SHA256)):
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f"{path.name}: SHA-256 校验失败")


async def flash(target, port, calibration_dir, moonraker, progress):
    filename, version, _, _ = IMAGES[target]
    calibration_dir.mkdir(parents=True, exist_ok=True)
    # The web service already owns a per-device hold. A global service restart
    # would release that hold and interrupt other boxes on the same printer.
    argv = [sys.executable, "-u", str(TOOL), str(HERE / "firmware" / filename),
            "--port", port, "--version", version.lstrip("V"), "--yes", "--config-follows",
            "--calibration-dir", str(calibration_dir), "--moonraker", moonraker,
            "--klipper-stop", "/bin/false", "--klipper-start", "/bin/false"]
    env = os.environ.copy()
    vendor = str(TOOL.parent)
    env["PYTHONPATH"] = os.pathsep.join(filter(None, [vendor, env.get("PYTHONPATH")]))
    proc = await asyncio.create_subprocess_exec(
        *argv, stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT, env=env)
    recent = deque(maxlen=4)
    try:
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if line:
                recent.append(line)
                chunk = re.fullmatch(r"(\d+)/(\d+) chunks", line)
                percent = (100 * int(chunk[1]) / int(chunk[2])) if chunk and int(chunk[2]) else None
                progress(percent, line)
        code = await proc.wait()
    finally:
        # Never return the serial port to Klipper while the child still owns it.
        if proc.returncode is None:
            proc.terminate()
            await proc.wait()
    # With --config-follows, exit 2 asks the caller to prove the new ace2k
    # version after installing the new driver mapping. It is not success yet.
    if code != 0 and not (code == 2 and target == "ace2k"):
        raise RuntimeError(f"ACE 更新器退出 {code}: " + " / ".join(recent))
