"""Reserve ACE boxes for the lifetime of a U1 print, including pauses."""

from concurrent.futures import ThreadPoolExecutor
import logging
import math
import os
import re

from .ace_flow_guard import raw_head_state, source_route
from .ace_path_store import configured_route_heads


_TOOL = re.compile(rb'T([0-9]+)$')
_ARG = re.compile(rb'([A-Z_]+)=([0-9]+)$')
_ROUTE_COMMANDS = {b'ACE_SWAP_HEAD', b'ACE_BG_SWAP', b'ACE_LOAD_HEAD'}
_PASSIVE_ACE = {b'ACE_SET_PURGE', b'ACE_PICKUP_CLEAN', b'ACE_BG_SYNC',
                b'ACE_SET_OOZE_OVERRIDE'}
_PRINT_LIMITS = {'PLA': 45, 'PETG': 55}
_COOL_WITH_HEAT_OFF = 40
_START_TIMEOUT = 600.
PRINT_DRY_TEMP = 55
PRINT_DRY_LEASE_MINUTES = 15


def read_print_routes(path):
    """Read the complete job off the reactor. Unknown routing reserves all boxes."""
    tools, routes, guarded_feeds = set(), set(), set()
    with open(path, 'rb') as stream:
        before = os.fstat(stream.fileno())
        for line in stream:
            line = line.lstrip()
            if not line or line[:1] in (b';', b'G', b'g'):
                continue
            raw = line.upper().split(b';', 1)[0].split()
            if not raw:
                continue
            command = raw[0]
            tool = _TOOL.fullmatch(command)
            if tool:
                tools.add(int(tool[1]))
            elif command in _ROUTE_COMMANDS or command == b'SM_PRINT_AUTO_FEED':
                params = {}
                for arg in raw[1:]:
                    match = _ARG.fullmatch(arg)
                    if match:
                        params[match[1]] = int(match[2])
                if command == b'SM_PRINT_AUTO_FEED':
                    tool = params.get(b'EXTRUDER', -1)
                    if not 0 <= tool < 4:
                        return None
                    guarded_feeds.add(tool)
                else:
                    head, box, slot = (params.get(key, -1)
                                       for key in (b'HEAD', b'ACE', b'SLOT'))
                    if not all(0 <= v < 4 for v in (head, box, slot)):
                        return None
                    routes.add((head, box, slot))
            elif ((command.startswith(b'ACE_') and command not in _PASSIVE_ACE)
                  or command.startswith(b'N') and command[1:2].isdigit()
                  or command in (b'M6', b'M600', b'ACTIVATE_EXTRUDER',
                                 b'SET_PRINT_EXTRUDER_MAP', b'SDCARD_LOOP_BEGIN',
                                 b'FEED_AUTO', b'AUTO_FEEDING')):
                return None
        after = os.fstat(stream.fileno())
    stamp = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)
    if stamp(before) != stamp(after) or not (tools or routes or guarded_feeds):
        return None
    return tools, routes, stamp(after), guarded_feeds


class PrintDrying:
    def __init__(self, ace, inventories):
        self.ace = ace
        self.dryer = ace._dry_cycles
        self.inventories = inventories
        self.sd = None
        self.job = None
        self.armed_until = 0.
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='ace-print-routes')

    def install(self):
        sd = self.ace.printer.lookup_object('virtual_sdcard', None)
        if sd is None or self.sd is sd:
            return
        self.sd = sd
        original = sd.work_handler

        def prepare(eventtime):
            if sd.must_pause_work or sd.current_file is None:
                self._release_sd_timer()
                if self.job and not self.job['started']:
                    self.release()
                return self.ace.reactor.NEVER
            try:
                if not self._ready(eventtime):
                    return self.ace.reactor.monotonic() + .25
            except Exception as exc:
                message = '打印未开始：ACE 烘干温度未确认（%s）' % exc
                logging.warning('[multiACE] %s', message)
                self._release_sd_timer()
                sd.do_cancel()
                self.release()
                self.ace.gcode.respond_info(message)
                return self.ace.reactor.NEVER
            self.job['started'] = True
            self.job['deadline'] = None
            return original(eventtime)

        sd.work_handler = prepare

    def _release_sd_timer(self):
        if self.sd.work_timer is not None:
            self.ace.reactor.unregister_timer(self.sd.work_timer)
            self.sd.work_timer = None

    def release(self, *args):
        job, self.job = self.job, None
        if job is None:
            return
        if job.get('scan') is not None:
            job['scan'].cancel()
        if job.get('dry_enabled'):
            self.ace.reactor.register_callback(lambda now: self._stop_owned(job))

    def arm(self, gcmd):
        enabled = gcmd.get_int('ENABLE', 0, minval=0, maxval=1)
        now = self.ace.reactor.monotonic()
        self.armed_until = now + _START_TIMEOUT if enabled and not self.active() else 0.

    def begin(self):
        job = self.job
        if job is None or not job.get('started') or 'dry_enabled' in job:
            return
        reactor = self.ace.reactor
        now = reactor.monotonic()
        job['dry_enabled'] = self.armed_until > now
        self.armed_until = 0.
        if job['dry_enabled']:
            job['dry_attempts'] = set()
            reactor.register_timer(lambda when: self._try_start(job, when), now + 1.)

    def _try_start(self, job, now):
        a, d = self.ace, self.dryer
        if self.job is not job:
            return a.reactor.NEVER
        stats = a.printer.lookup_object('print_stats', None)
        if getattr(stats, 'state', None) != 'printing' or self.planning():
            return now + 2.
        boxes = set(job.get('dry_boxes', ()))
        for head in job['heads']:
            src = source_route(a._head_source.get(head))
            if src and a.head_uses_ace(head):
                boxes.add(src[0])
        for idx in sorted(boxes - job['dry_attempts']):
            if self.job is not job:
                break
            if not d.safe_for_maintenance(idx):
                continue
            job['dry_attempts'].add(idx)
            try:
                d.start(idx, PRINT_DRY_TEMP, PRINT_DRY_LEASE_MINUTES, print_scope=job)
                logging.info('[multiACE] print drying ACE %d started at %d C', idx, PRINT_DRY_TEMP)
            except (RuntimeError, OSError) as exc:
                logging.warning('[multiACE] print drying ACE %d not started: %s', idx, exc)
                self._stop_owned(job, only=idx)
        return a.reactor.monotonic() + 2. if self.job is job else a.reactor.NEVER

    def _stop_owned(self, job, only=None):
        d = self.dryer
        for idx, cycle in sorted(d.cycles.items()):
            if ((only is None or idx == only) and cycle.get('print_scope') is job
                    and cycle['phase'] != 'stopping' and d._live(idx, cycle)):
                try:
                    d.stop(idx)
                    logging.info('[multiACE] print drying ACE %d stop requested', idx)
                except (RuntimeError, OSError) as exc:
                    logging.warning('[multiACE] print drying ACE %d stop not confirmed: %s', idx, exc)

    def owns_cycle(self, idx):
        cycle = self.dryer.cycles.get(idx, {})
        return (self.job is not None and cycle.get('print_scope') is self.job
                and self.dryer._live(idx, cycle))

    def dry_status(self):
        return dict(armed=self.armed_until > self.ace.reactor.monotonic(),
                    enabled=bool(self.job and self.job.get('dry_enabled')),
                    aces=sorted(i for i in self.dryer.cycles if self.owns_cycle(i)))

    def active(self):
        state = self.ace.printer.lookup_object('print_stats', None)
        return self.job is not None or getattr(state, 'state', None) in ('printing', 'paused')

    def reserved(self, idx):
        if self.job is not None:
            if idx in self.job['reserved']:
                return True
            return any(route is not None and route[0] == idx
                       for route in (source_route(self.ace._head_source.get(head))
                                     for head in self.job['heads']))
        return self.active()

    def planning(self):
        return self.job is not None and self.job['scan'] is not None

    def allows_slot_maintenance(self, idx, slot):
        """Authorize inlet-only handling on a verified, unused physical path."""
        a = self.ace
        job = self.job
        if (job is None or self.sd is None or not job.get('routes_verified')
                or self.sd.current_file is not job['file'] or not job.get('started')
                or not a._is_v2_idx(idx) or not a._connected_per_ace.get(idx)
                or a._serial_failed_per_ace.get(idx) or a._reconnecting_per_ace.get(idx)
                or idx in self.dryer.pulses):
            return False
        operations = getattr(a, '_path_operations', None)
        if operations is not None and operations.handles(idx, slot):
            return False
        ptc = a.printer.lookup_object('print_task_config', None)
        if ptc is None or ptc.print_task_config.get('auto_replenish_filament') or a.quad_replenish:
            return False
        heads = configured_route_heads(a, idx, slot)
        if len(heads) != 1:
            return False
        head = heads[0]
        ext = a.toolhead.get_extruder()
        active = getattr(ext, 'extruder_index', getattr(ext, 'extruder_num', None))
        return (type(active) is int and active != head and head not in job['heads']
                and a._head_source.get(head) is None
                and raw_head_state(a, head) is False
                and all(source_route(source) != (idx, slot)
                        for source in a._head_source.values())
                and head not in getattr(a, '_bg_staged', {}))

    def _routes(self, parsed, file):
        a = self.ace
        boxes = set(range(len(a._ace_devices)))
        if parsed is None or a._ace_mode not in ('multi', 'head'):
            return boxes
        raw_tools, routes, stamp, guarded_feeds = parsed
        # U1 VirtualSD keeps an AsyncFileReader rather than an IOBase.
        # Compare the open descriptor, since its path can be replaced by an upload.
        fileno = getattr(file, 'fileno', None)
        fd = fileno() if callable(fileno) else getattr(file, '_fd', None)
        if type(fd) is not int or fd < 0:
            return boxes
        st = os.fstat(fd)
        if stamp != (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns):
            return boxes
        ptc = a.printer.lookup_object('print_task_config', None)
        if ptc is None:
            return boxes
        table = ptc.get_extruder_map_table()
        if any(tool >= len(table) or type(table[tool]) is not int
               or not 0 <= table[tool] < 4 for tool in raw_tools):
            return boxes
        heads = {table[tool] for tool in raw_tools}
        # Bare T commands may also address already-remapped physical heads.
        heads.update(tool for tool in raw_tools if tool < 4)
        heads.update(head for head, _, _ in routes)
        stock = ptc.print_task_config
        if guarded_feeds:
            # The stock SM_PRINT_AUTO_FEED macro uses physical extruders_used.
            # VirtualSDFile's set_new_print_info populates it from filament_used_g
            # when the caller did not set explicit heads.
            used = stock.get('extruders_used')
            if not isinstance(used, (tuple, list)) or len(used) != 4:
                return boxes
            enabled = {head for head, used_flag in enumerate(used) if used_flag}
            if not enabled:
                extra = getattr(ptc, 'print_task_config_2', None) or {}
                grams = extra.get('filament_used_g')
                if not isinstance(grams, (tuple, list)) or len(grams) > len(table):
                    return boxes
                active_tools = {tool for tool, weight in enumerate(grams) if weight > 0}
                if any(type(table[tool]) is not int or not 0 <= table[tool] < 4
                       for tool in active_tools):
                    return boxes
                enabled = {table[tool] for tool in active_tools}
            heads.update(guarded_feeds & enabled)
        if getattr(a, 'toolhead', None) is not None:
            extruder = a.toolhead.get_extruder()
            current = getattr(extruder, 'extruder_index',
                              getattr(extruder, 'extruder_num', None))
            if type(current) is int and 0 <= current < 4 and a._head_source.get(current):
                heads.add(current)
        mapped = {box for _, box, _ in routes}
        if not mapped <= boxes:
            return boxes
        self.job['dry_boxes'] = set(mapped)
        planned = {head for head, _, _ in routes}
        self.job['heads'].update(heads)
        for head in heads:
            if not a.head_uses_ace(head):
                continue
            src = source_route(a._head_source.get(head))
            if src:
                mapped.add(src[0])
            if a._ace_mode == 'head':
                mapped.add(a.head_ace_for(head))
            elif head not in planned and not src:
                return boxes
        # Stock can switch to another already-loaded printhead. Include its
        # physical source throughout the job even when Flow's refill is off.
        if stock.get('auto_replenish_filament'):
            types = stock.get('filament_type') or ()
            colors = stock.get('filament_color_rgba') or ()
            if len(types) < 4 or len(colors) < 4 or routes:
                candidates = range(4)
            else:
                candidates = (candidate for candidate in range(4) if any(
                    not types[head] or not types[candidate]
                    or (types[head], colors[head]) == (types[candidate], colors[candidate])
                    for head in heads))
            for head in candidates:
                if not a.head_uses_ace(head):
                    continue
                src = source_route(a._head_source.get(head))
                if src:
                    mapped.add(src[0])
                    self.job['heads'].add(head)
                elif a._ace_mode == 'head':
                    mapped.add(a.head_ace_for(head))
                    self.job['heads'].add(head)
        if a.quad_replenish and a._ace_mode == 'multi' and mapped:
            # Refill can select a different unit of the same lane at runout.
            # Its material can change after slicing or during a paused job.
            return boxes
        self.job['routes_verified'] = True
        return mapped & boxes

    def _ready(self, now):
        a, sd = self.ace, self.sd
        file = sd.current_file
        if not self.job or self.job['file'] is not file:
            self.release()
            self.job = dict(file=file, scan=self.executor.submit(read_print_routes, file.name),
                            reserved=set(range(len(a._ace_devices))), heads=set(), cooling=set(),
                            deadline=now + _START_TIMEOUT, started=False)
        job = self.job
        if job['deadline'] is None:
            job['deadline'] = now + _START_TIMEOUT
        if now >= job['deadline']:
            raise RuntimeError('等待 ACE 降温超时')
        scan = job['scan']
        if scan is not None:
            if not scan.done():
                return False
            try:
                job['reserved'] = self._routes(scan.result(), file)
            except (OSError, ValueError, AttributeError, TypeError, IndexError) as exc:
                logging.info('[multiACE] ACE print route unavailable; reserving all boxes: %s', exc)
            job['scan'] = None
            logging.info('[multiACE] ACE dryer reservations: %s', sorted(job['reserved']))
        job['cooling'] = {idx for idx in range(len(a._ace_devices))
                          if self.reserved(idx) and not self.ready_to_feed(idx)}
        return not job['cooling'] and not self.dryer.pulses

    def limit(self, idx):
        """Zero means that a reserved box must remain unheated."""
        if self.owns_cycle(idx):
            return PRINT_DRY_TEMP
        if not self.reserved(idx):
            return None
        a = self.ace
        inventory = self.inventories.get(idx)
        if not inventory or not (a._is_v2(idx) or getattr(a, '_is_ace2k', lambda _i: False)(idx)):
            return 0
        info = self.dryer._observation(idx)
        lanes = info.get('slots') or []
        if len(lanes) != 4:
            return 0
        inserted = a._gate_status_per_ace.get(idx, ())
        if len(inserted) != 4:
            return 0
        for slot, (gate, declared) in enumerate(zip(inserted, inventory)):
            if gate not in (0, 1):
                return 0
            if gate:
                observed = a._slot_declared_identity(idx, slot)
                if not observed or observed[0].upper() != declared:
                    return 0
        return min(_PRINT_LIMITS[mat] for mat in inventory if mat != 'EMPTY')

    def temperature_for(self, idx, target):
        if self.planning():
            raise RuntimeError('正在核对打印料路，暂缓启动烘干')
        cap = self.limit(idx)
        if cap == 0:
            raise RuntimeError('该 ACE 已为打印预留，打印结束后可烘干')
        return target if cap is None else min(target, cap)

    def ready_to_feed(self, idx):
        d = self.dryer
        if idx in d.pulses:
            return False
        info = d._observation(idx)
        c = d.cycles.get(idx) or {}
        was_heated = c.get('effective_target') is not None or idx in d.unresolved
        # Normal, never-heated boxes (including unused/offline candidates)
        # retain their existing print-start checks.
        if not info and not was_heated:
            return True
        status = info.get('dryer_status') or {}
        limit = self.limit(idx) or _COOL_WITH_HEAT_OFF
        temp = info.get('temp')
        if not was_heated and d.stopped(idx) and temp is None:
            return True
        if type(temp) not in (int, float) or not math.isfinite(temp) or not 0 < temp <= limit:
            return False
        if self.owns_cycle(idx) and c['phase'] in d.ACTIVE and not status.get('rotisserie'):
            # The print cycle never rotates the spool. A heater ACK in flight
            # must not reject a feed request on the same connection.
            if status.get('status') == 'stop' and d.stopped(idx):
                return True
            target = status.get('target_temp')
            return (type(target) is int and 35 <= target <= PRINT_DRY_TEMP
                    and status.get('status') in ('starting', 'keeping', 'drying'))
        if d.stopped(idx):
            return idx not in d.unresolved
        cap = self.limit(idx)
        target = status.get('target_temp')
        return (bool(cap) and type(target) is int and 35 <= target <= cap
                and status.get('status') in ('starting', 'keeping', 'drying')
                and not status.get('rotisserie') and c.get('pending') is None
                and c.get('effective_target') == target)

    def status(self, idx):
        if not self.active():
            return 'idle'
        if self.planning():
            return 'preparing'
        if self.job and idx in self.job['cooling']:
            return 'cooling'
        limit = self.limit(idx)
        if limit is None:
            return 'available'
        return 'limited' if limit else 'reserved'


def parse_inventory(config, name):
    value = config.get(name, '').strip()
    if not value:
        return None
    materials = tuple(part.strip().upper() for part in value.split(','))
    if (len(materials) != 4 or all(mat == 'EMPTY' for mat in materials)
            or any(mat not in (*_PRINT_LIMITS, 'EMPTY') for mat in materials)):
        raise config.error('%s must declare four bays as PLA, PETG, or EMPTY' % name)
    return materials
