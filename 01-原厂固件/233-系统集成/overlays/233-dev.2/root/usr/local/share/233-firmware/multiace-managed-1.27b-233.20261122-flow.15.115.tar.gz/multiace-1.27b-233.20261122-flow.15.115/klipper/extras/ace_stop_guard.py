"""Retain unresolved STOP faults on the affected ACE and filament path."""
import threading
import os
import logging
import json
from .ace_controlled_motion import request_operation, MotionError, QUERY, STOP, CLOSE


def controlled_cleanup(request):
    try:
        return request_operation(request) in (QUERY, STOP, CLOSE)
    except MotionError:
        return False

def recovery_disables_insertion(request):
    if not isinstance(request, dict):
        return False
    method = request.get('method')
    params = request.get('params') or {}
    return ((method == 'insert_policy_set' and params.get('enabled') is False)
            or (method == 'set_rfid_enable' and params.get('enable') is False))


FAULT_PATH = '/home/lava/printer_data/controlled-exploration/fault-checkpoint4.json'
LEGACY_FAULT_PATH = '/home/lava/printer_data/controlled-exploration/fault-checkpoint3.json'


class StopUnconfirmedError(RuntimeError):
    pass


def stop_response_accepted(response):
    """Validate STOP acceptance only. This is not mechanical standstill."""
    if (not isinstance(response, dict)
            or type(response.get('code')) is not int or response['code'] != 0
            or str(response.get('msg', '')).strip().upper() == 'FORBIDDEN'):
        return False
    if any(key in response for key in ('_v2_frame_valid', '_v2_payload_valid', '_v2_command')):
        return (response.get('_v2_frame_valid') is True
                and response.get('_v2_payload_valid') is True
                and response.get('_v2_command') == 9)
    return True  # V1 has no V2 framing metadata.


class StopFaultLatch:
    # Positive allowlist: raw/tunnel/unknown commands cannot bypass a fault.
    ALLOWED = frozenset((
        'stop_feed_filament', 'stop_feed_assist', 'drying_stop',
        'get_info', 'get_status', 'get_temp', 'get_feed_info',
        'get_key_state', 'get_filament_info', 'discover_device', 'insert_policy_query', 'insert_policy_discard'))

    def __init__(self, store_path=None):
        self.store_path = store_path
        self._faults = []
        self.persistence_error = None
        self._lock = threading.Lock()
        # Device writes remain serialized by the existing per-device writer.
        # This lock protects only admission/publication, never a syscall.
        self._fault = None
        self._generation = 0

    def _matching_fault(self, targets):
        if targets is None or self._fault is None:
            return self._fault
        for fault in self._faults or (self._fault,):
            if fault['ace_idx'] < 0:
                return fault
            if any((device == fault['ace_idx'] or
                    (uid is not None and list(uid) == fault.get('uid')))
                   and (bay is None or fault['slot'] < 0 or bay == fault['slot'])
                   for device, bay, uid in targets):
                return fault
        return None

    def snapshot(self, targets=None):
        with self._lock:
            fault = self._matching_fault(targets)
            return None if fault is None else {
                name: fault[name] for name in ('ace_idx', 'slot', 'reason')}

    def recovery_snapshot(self):
        with self._lock:
            faults = [dict(f) for f in self._faults]
            if self._fault is not None and not faults:
                faults = [dict(self._fault)]
            return self._generation, faults

    def clear_verified(self, generation, ace_idx, slot, identity):
        """Release an unchanged route fault after a fresh STOP and stable READY.

        CMD76 may be absent; the caller has verified repeated fresh READY
        status on the same transport and identity. This never clears a position
        hold, source record, or another device's fault.
        """
        if (type(generation) is not int or type(ace_idx) is not int
                or type(slot) is not int or not 0 <= ace_idx < 4 or not 0 <= slot < 4
                or not isinstance(identity, (tuple, list)) or len(identity) != 2):
            return False
        port, uid = identity
        if (not isinstance(port, str) or not port or not isinstance(uid, (tuple, list))
                or len(uid) != 3 or any(type(value) is not int for value in uid)):
            return False
        with self._lock:
            if self._generation != generation:
                return False
            faults = list(self._faults)
            if self._fault is not None and not faults:
                faults = [dict(self._fault)]
            if not faults:
                return self._fault is None
            targets = [fault for fault in faults
                       if (fault.get('ace_idx'), fault.get('slot')) == (ace_idx, slot)]
            if not targets or any(fault.get('port') != port or fault.get('uid') != list(uid)
                                  for fault in targets):
                return False
            remaining = [fault for fault in faults if fault not in targets]
            try:
                self._persist(remaining)
            except Exception as exc:
                self.persistence_error = str(exc)
                logging.exception('Could not persist verified STOP recovery')
                return False
            self._faults = remaining
            self._fault = (None if not remaining else
                           {key: remaining[0][key] for key in ('ace_idx', 'slot', 'reason')})
            self._generation += 1
            self.persistence_error = None
            return True

    def _persist(self, faults):
        if self.store_path is None:
            return
        directory = os.path.dirname(self.store_path)
        os.makedirs(directory, mode=0o700, exist_ok=True)
        temp = self.store_path + '.tmp-' + os.urandom(8).hex()
        try:
            fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w') as stream:
                json.dump({'version': 1, 'faults': faults}, stream)
                stream.flush(); os.fsync(stream.fileno())
            os.replace(temp, self.store_path)
            fd = os.open(directory, os.O_RDONLY)
            try: os.fsync(fd)
            finally: os.close(fd)
        finally:
            if os.path.exists(temp): os.unlink(temp)

    def restore_persistent(self):
        # A journal entry only says that an earlier STOP response was not
        # observed. It is not evidence that the ACE is still moving after a
        # process restart, so it must not become a current route lock.
        return

    def latch(self, ace_idx, slot, reason, identity=None):
        with self._lock:
            self._generation += 1
            if self._fault is None:
                self._fault = {'ace_idx': int(ace_idx), 'slot': int(slot),
                               'reason': str(reason)}
            detail = {'ace_idx': int(ace_idx), 'slot': int(slot), 'reason': str(reason)}
            if identity is not None:
                detail['port'], uid = identity
                detail['uid'] = list(uid) if uid is not None else None
            if detail not in self._faults:
                self._faults.append(detail)
            if self.store_path is not None:
                try:
                    self._persist(self._faults)
                    self.persistence_error = None
                except Exception as exc:
                    self.persistence_error = str(exc)
                    logging.exception('Could not persist STOP fault')
                return dict(self._fault)
            path = FAULT_PATH
            if os.path.lexists(path):
                try:
                    extra = path + '.additional-fault'
                    fd = os.open(extra, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
                    try:
                        os.write(fd, b'additional fault while latched\n')
                        os.fsync(fd)
                    finally:
                        os.close(fd)
                    fd = os.open(os.path.dirname(path), os.O_RDONLY)
                    try:
                        os.fsync(fd)
                    finally:
                        os.close(fd)
                except Exception:
                    logging.exception('STOP guard could not persist additional fault')
            return dict(self._fault)

    def message(self, targets=None):
        f = self.snapshot(targets)
        if f is None:
            return None
        target = ('ACE %d 槽 %d' % (f['ace_idx'] + 1, f['slot'] + 1)
                  if f['ace_idx'] >= 0 and f['slot'] >= 0 else '未确认的料路')
        return '[multiACE] STOP UNCONFIRMED: %s 停稳未确认，请先复核。%s' % (
            target, f['reason'])

    def require_clear(self, targets=None):
        msg = self.message(targets)
        if msg is not None:
            raise StopUnconfirmedError(msg)

    def _allows(self, request, targets):
        return self._matching_fault(targets) is None or (
            isinstance(request, dict) and (request.get('method') in self.ALLOWED
                or (request.get('method') == 'set_valve'
                    and request.get('params') == {'v1': False, 'v2': False})
                or controlled_cleanup(request) or recovery_disables_insertion(request)))

    def allows(self, request, targets=None):
        with self._lock:
            return self._allows(request, targets)

    def write(self, serial, data, request, targets=None):
        # Admission is atomic with fault publication. The syscall is not:
        # a previously admitted write may BEGIN after a fault is published.
        # Do not hold the publication lock across a potentially blocked write.
        with self._lock:
            if not self._allows(request, targets):
                return False
        written = serial.write(data)
        if type(written) is not int or written != len(data):
            raise IOError('short serial write: %r of %d bytes' % (written, len(data)))
        return True


def guard_for_printer(printer):
    ace = printer.lookup_object('ace', None)
    if ace is None:
        return None
    guard = getattr(ace, '_stop_guard', None)
    if guard is None:
        raise StopUnconfirmedError('STOP guard candidate bundle is incomplete')
    return guard


def require_printer_clear(printer, gcmd=None, *, head=None):
    guard = guard_for_printer(printer)
    if guard is not None:
        targets = (printer.lookup_object('ace')._stop_targets(head=head)
                   if head is not None else None)
        message = guard.message(targets)
        if message is not None and gcmd is not None:
            raise gcmd.error(message=message, action='pause', id=525,
                             code=210, oneshot=1, level=2)
        guard.require_clear(targets)


class StopGuardGCode:
    """Guard scripts issued by these three candidate modules only.

    An already-running macro may continue internally. Other users of the
    original gcode object are NOT intercepted. No global monkey-patching.
    """
    CLEANUP = frozenset((
        'M107', 'M104 S0', 'SET_ACTION_CODE ACTION=IDLE',
        'SET_MAIN_STATE MAIN_STATE=IDLE ACTION=IDLE'))

    def __init__(self, target, get_guard, get_targets=None):
        self._target = target
        self._get_guard = get_guard
        self._get_targets = get_targets

    def __getattr__(self, name):
        return getattr(self._target, name)

    def _check(self, script):
        guard = self._get_guard()
        if guard is None:
            return
        lines = [s.strip().upper() for s in str(script).splitlines()
                 if s.strip()]
        if not lines or not all(s in self.CLEANUP for s in lines):
            targets = self._get_targets() if self._get_targets is not None else None
            guard.require_clear(targets)

    def run_script_from_command(self, script):
        self._check(script)
        return self._target.run_script_from_command(script)

    def run_script(self, script):
        self._check(script)
        return self._target.run_script(script)
