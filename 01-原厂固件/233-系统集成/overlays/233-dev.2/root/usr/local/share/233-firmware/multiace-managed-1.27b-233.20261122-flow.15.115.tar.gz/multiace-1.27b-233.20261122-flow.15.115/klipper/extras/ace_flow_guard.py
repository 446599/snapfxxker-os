"""Shared route admission for the live flow.14 command and serial paths.

Operation completion does not erase a physical source.  The source map and
dynamic location journal remain authoritative until a verified unload/eject.
The old one-machine location marker is deliberately not a global admission
rule.  No motion, serial polling or automatic source reassignment happens here.
"""
from .ace_path_store import configured_route_heads


MOTION = frozenset(('feed_filament', 'unwind_filament',
                    'feed_or_rollback_raw', 'start_feed_assist',
                    'update_feeding_speed', 'insert_policy_start', 'raw'))


def raw_head_state(ace, head, sensor=None):
    """True/False/None; U1's delayed runout latch is not a position sensor."""
    if sensor is None:
        sensor = ace.printer.lookup_object(
            'filament_motion_sensor e%d_filament' % head, None)
    if sensor is None:
        return None
    if hasattr(sensor, 'runout_buttun_state'):
        value = sensor.runout_buttun_state
    elif getattr(ace, 'host', 'u1') == 'u1':
        return None
    else:
        value = sensor.get_status(0).get('filament_detected')
    # Some button adapters expose the documented binary level as 0/1.
    if type(value) is bool:
        return value
    if type(value) is int and value in (0, 1):
        return bool(value)
    return None


def source_route(source):
    if not isinstance(source, dict):
        return None
    idx, slot = source.get('ace_index'), source.get('slot')
    if (type(idx) is int and 0 <= idx < 4
            and type(slot) is int and 0 <= slot < 4):
        return idx, slot
    return None


def same_slot_reinsert(ace, source, idx, slot):
    """A later inlet observation on the same live ACE can reuse its tube."""
    if source_route(source) != (idx, slot) or 'insert_epoch' not in source:
        return False
    session = getattr(ace, '_insert_session', None)
    if not session or source.get('insert_session') != session:
        return False
    saved = source['insert_epoch']
    if saved is None:
        saved = 0  # No inlet changes observed when the route was first recorded.
    current = ace._insert_epochs.get((idx, slot))
    floor = ace._last_disconnect_epoch.get((idx, slot), 0)
    return (type(saved) is int and type(current) is int and floor <= saved < current
            and isinstance(source.get('connection_identity'), dict)
            and source['connection_identity'] == ace._rfid_identity_status(idx))


def eject_peer_source(ace, idx, slot, head):
    """Prove an occupied Multi-mode head belongs to a different live ACE."""
    if (getattr(ace, '_ace_mode', None) != 'multi'
            or raw_head_state(ace, head) is not True):
        return None
    source = ace._head_source.get(head)
    route = source_route(source)
    if route is None or route[0] == idx or source.get('load_failed') is not False:
        return None
    other, other_slot = route
    if head not in configured_route_heads(ace, other, other_slot):
        return None
    if any(source_route(entry) == (idx, slot) for entry in ace._head_source.values()):
        return None
    identity = ace._rfid_identity_status(other)
    gates = ace._gate_status_per_ace.get(other) or ()
    # Only the selected branch moves. An old insertion stamp on the loaded
    # branch cannot change which ACE owns the occupied head.
    if (identity is None or source.get('connection_identity') != identity
            or tuple(identity['uid']) == ace._location_identity(idx)[1]
            or other_slot >= len(gates) or gates[other_slot] != 1):
        return None
    return route


def isolated_assist_stop_generation(ace, idx, old_slot, new_slot, transport, identity):
    """Admit a second print assist only for the two separate U1 paths."""
    if (ace.host != 'u1' or ace._ace_mode != 'multi' or ace._fa_context != 'print'
            or not ace._is_v2_idx(idx) or old_slot == new_slot
            or transport is None or ace._serials.get(idx) is not transport
            or ace._connected_per_ace.get(idx) is not True
            or ace._reconnecting_per_ace.get(idx)
            or ace._location_identity(idx) != identity
            or ace._stop_message(idx, new_slot) is not None):
        return None
    port, uid = identity
    if not port or not uid:
        return None
    current = {'port': port, 'uid': list(uid)}
    for bay in (old_slot, new_slot):
        owners = [(head, source) for head, source in ace._head_source.items()
                  if source_route(source) == (idx, bay)]
        if len(owners) != 1 or configured_route_heads(ace, idx, bay) != (bay,):
            return None
        head, source = owners[0]
        if (head != bay or source.get('connection_identity') != current
                or not ace._source_insertion_matches(source, idx, bay)):
            return None
    generation, faults = ace._stop_guard.recovery_snapshot()
    local = [fault for fault in faults if fault['ace_idx'] == idx or fault.get('uid') == current['uid']]
    if (len(local) == 1 and local[0]['ace_idx'] == idx and local[0]['slot'] == old_slot
            and local[0].get('port') == port and local[0].get('uid') == current['uid']):
        # One uncertain lane can occupy one of the two firmware operations.
        # The new lane still has to pass normal admission and receive its ACK.
        return generation
    return None


def stop_targets(ace, idx=None, slot=None, head=None):
    """Physical bays that can interfere with this operation."""
    bays = set()
    heads = set()
    sources = getattr(ace, '_head_source', {})
    if type(idx) is int and 0 <= idx < 4:
        if type(slot) is not int or not 0 <= slot < 4:
            return ((idx, None, ace._location_identity(idx)[1]),)
        bays.add((idx, slot))
        heads.update(configured_route_heads(ace, idx, slot))
        heads.update(h for h, source in sources.copy().items() if source_route(source) == (idx, slot))
    if type(head) is int and 0 <= head < 4:
        heads.add(head)
    if heads:
        for device in range(4):
            for bay in range(4):
                if heads.intersection(configured_route_heads(ace, device, bay)):
                    bays.add((device, bay))
        for owned_head in heads:
            original = source_route(sources.get(owned_head))
            if original is not None:
                bays.add(original)
    return tuple((device, bay, ace._location_identity(device)[1]) for device, bay in sorted(bays))


def dynamic_route_blocked(ace, head=None, idx=None, slot=None):
    holder = getattr(ace, '_location_hold', None)
    if holder is None:
        return False
    port, uid = ace._location_identity(idx) if idx is not None else (None, None)
    heads = list(configured_route_heads(ace, idx, slot)) if idx is not None and slot is not None else None
    # This is the general route journal. PATH/PORT/UID in the legacy class
    # describe a historical commissioning incident, not every installation.
    return holder._route_blocked(head, slot, port, uid, heads=heads)


def source_conflict(ace, head, idx, slot):
    source = getattr(ace, '_head_source', {}).get(head)
    if source:
        route = source_route(source)
        if route is None:
            return '喷头 %d 的原料路记录不完整，请先复核来源' % (head + 1)
        if route != (idx, slot):
            return ('喷头 %d 共用料管仍归属 ACE %d 槽 %d；'
                    '请先完成原槽退料，不能覆盖为另一来源'
                    % (head + 1, route[0] + 1, route[1] + 1))
        bound = source.get('connection_identity')
        if bound is not None:
            port, uid = ace._location_identity(idx)
            if (not isinstance(bound, dict) or not isinstance(uid, (list, tuple))
                    or bound.get('port') != port or bound.get('uid') != list(uid)):
                return '原送料设备的身份或物理端口已变化；保留原来源，请复核接管'
    staged = getattr(ace, '_bg_staged', {}).get(head)
    if staged is not None and tuple(staged[:2]) != (idx, slot):
        return '喷头 %d 仍有另一料槽的待完成送料' % (head + 1)
    return None


def wire_rejection(ace, idx, request, serial):
    """Return a reason at the last write boundary, or None to admit.

    STOP and queries always pass this layer. A dynamic position hold permits
    only the exact, still-valid ejection/recovery token checked by SlotActions.
    """
    if not isinstance(request, dict):
        return '无效串口请求'
    method = request.get('method')
    if method not in MOTION:
        return None
    params = request.get('params') or {}
    slot = params.get('index', params.get('slot'))
    park = getattr(ace, '_fixed_park_motion', None)
    requested_park = request.get('_fixed_park_motion')
    if requested_park is not None:
        if requested_park is not park or not park.allows_wire(idx, request, serial):
            return '原槽回停授权已结束或已变化'
    elif park is not None and (idx, slot) == (park.idx, park.slot):
        return '原槽正在回停'
    if type(slot) is not int or not 0 <= slot < 4:
        # Raw bytes have no trustworthy slot scope. They cannot bypass a
        # running owner or an unresolved physical route.
        holder = getattr(ace, '_location_hold', None)
        if (getattr(ace, '_feed_supervisors', {})
                or park is not None or any(getattr(ace, '_head_source', {}).values())
                or holder is not None and (not holder.refresh_routes() or holder.routes)):
            return '无明确料槽的运动不能越过现有料路记录'
        return None
    try:
        heads = configured_route_heads(ace, idx, slot)
        actions = getattr(ace, '_slot_actions', None)
        exact_eject = (request.get('_eject_token') is not None and actions is not None
                       and actions.eject_allows(idx, request, serial))
        position_unload = (getattr(ace, '_position_unload_recovery', None) is not None
                           and ace._position_unload_recovery.allows_wire(idx, request, serial))
        policy = getattr(ace, '_insert_policy', None)
        for head in heads:
            reason = source_conflict(ace, head, idx, slot)
            if (reason and not (exact_eject or position_unload)
                    and not (policy is not None and policy.allows_branch_grip(idx, request, serial, head))):
                return reason
        for owner in list(getattr(ace, '_feed_supervisors', {}).values()):
            if owner.active and owner.head in heads and (owner.idx, owner.slot) != (idx, slot):
                return '共用喷头料管正在由另一送料任务占用'
        if dynamic_route_blocked(ace, idx=idx, slot=slot):
            if not (exact_eject or position_unload):
                return '该料路位置尚未确认；请复核原槽并完成退出 ACE'
        return None
    except Exception:
        return '料路归属暂不可确认，未发送运动'
