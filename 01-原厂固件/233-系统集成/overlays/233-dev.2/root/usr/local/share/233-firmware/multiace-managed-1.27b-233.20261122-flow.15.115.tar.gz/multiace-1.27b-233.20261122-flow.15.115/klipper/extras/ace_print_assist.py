"""Guard ordinary U1 print extrusion with bounded, same-route ACE recovery."""
import logging
import math

from .ace_fixed_park import ParkMotion
from .ace_flow_guard import dynamic_route_blocked, raw_head_state, source_conflict, source_route
from .ace_ready_wait import ReadyWaitError, status_rows, separate_paths
from .ace_stop_guard import StopUnconfirmedError
from .ace_v2_standstill import DECODER_UNAVAILABLE_REASONS, stop_and_verify

PRINT_SLOT_STATES = ('ready', 'assisting')
REARM_SLOT_STATES = (*PRINT_SLOT_STATES, 'assist_error', 'unwind_assist_error')
RECOVERY_TIMEOUT = 10.0
ACK_TIMEOUT = 1.0
STATUS_MAX_AGE = 4.0
TIP_SLOW_REVERSE_MM_S = 0.3
TIP_REVERSE_START_TIMEOUT = 1.15
STALE_SOURCE_SESSION_REASON = '重启、重连或插料状态已改变；请在原槽确认原来源后再启用助送'


class AssistArmUnconfirmed(ReadyWaitError):
    pass


class PrintAssist:
    def __init__(self, ace):
        self.ace = ace
        self.sd = None
        self.pending_links = set()
        self.pending_stops = set()
        self.checked = {}
        self.operator_epoch = 0
        self.tip_epoch = 0
        self.stock_tip = None
        self.tip_moves = False
        self.retry_head = None

    def install(self):
        a = self.ace
        self.sd = a.printer.lookup_object('virtual_sdcard', None)
        if self.sd is None:
            return
        move = a.printer.lookup_object('gcode_move', None)
        if move is None:
            self.sd = None
            return
        for name in ('G0', 'G1', 'G2', 'G3'):
            previous = a.gcode.register_command(name, None)
            if previous is not None:
                a.gcode.register_command(name, self.wrap_move(previous, move))
        previous = a.gcode.register_command('CONTROL_RETRACT_ACTION', None)
        if previous is not None:
            a.gcode.register_command('CONTROL_RETRACT_ACTION', self.wrap_stock_retract(previous))
            self.tip_moves = True
        a.printer.register_event_handler('pause_resume:pause', self.interrupt)
        a.printer.register_event_handler('pause_resume:cancel', self.interrupt)
        a.printer.register_event_handler('virtual_sdcard:reset_file', self.interrupt)

    def interrupt(self, *args):
        self.operator_epoch += 1

    def active_head(self):
        ext = self.ace.toolhead.get_extruder()
        return getattr(ext, 'extruder_index', getattr(ext, 'extruder_num', None))

    def is_v2_source(self, idx, source=None):
        return self.ace._is_v2_idx(idx) or bool(
            isinstance(source, dict) and source.get('connection_identity'))

    def manages(self, head, source):
        a = self.ace
        route = source_route(source)
        if self.sd is None or route is None or a._ace_mode not in ('multi', 'head'):
            return False
        idx, slot = route
        operations = getattr(a, '_path_operations', None)
        return (self.is_v2_source(idx, source) and idx not in a._fa_print_disable
                and a.head_uses_ace(head)
                and not (operations is not None and operations.handles(idx, slot)))

    def owns_active(self, idx, slot=None):
        a = self.ace
        if (self.sd is None or self.sd.current_file is None
                or a._fa_context != 'print' or a._swap_in_progress):
            return False
        head = self.active_head()
        source = a._head_source.get(head)
        return self.manages(head, source) and source['ace_index'] == idx and (
            slot is None or source['slot'] == slot)

    def request_reconnect(self, idx):
        a = self.ace
        if (idx in self.pending_links or a._reconnecting_per_ace.get(idx)
                or idx in a._fw_update_hold or not 0 <= idx < len(a._ace_devices)):
            return
        self.pending_links.add(idx)

        def reconnect(_event):
            try:
                if not self.online(idx):
                    a._reconnect_or_pause(idx, '打印料路连接待恢复')
            finally:
                self.pending_links.discard(idx)

        try:
            a.reactor.register_callback(reconnect)
        except Exception:
            self.pending_links.discard(idx)
            raise

    def online(self, idx):
        a = self.ace
        return (a._connected_per_ace.get(idx) is True
                and not a._serial_failed_per_ace.get(idx)
                and not a._reconnecting_per_ace.get(idx)
                and a._serials.get(idx) is not None)

    def retire_independent(self, idx, slot, new_idx, new_slot):
        """Stop a retired assist without making an independent head wait."""
        a = self.ace
        if not (self.is_v2_source(idx) and separate_paths(a, idx, slot, new_idx, new_slot)):
            return False
        key = idx, slot
        if key in self.pending_stops:
            return True
        transport = a._serials.get(idx)
        identity = a._location_identity(idx)

        def guard():
            if (self.owns_active(idx, slot) or a._swap_in_progress
                    or a._serials.get(idx) is not transport
                    or a._location_identity(idx) != identity
                    or getattr(a, '_feed_supervisors', {}).get(key) is not None):
                raise ReadyWaitError('原槽助送归属已变化')

        def stop(_event):
            try:
                guard()
                if self.online(idx) and a._feed_assist_per_ace.get(idx) == slot:
                    generation, _ = a._stop_guard.recovery_snapshot()
                    stop_and_verify(a, idx, slot, transport=transport, identity=identity,
                                    monitor=guard, ready_without_decoder=True)
                    a._clear_fa_cache_for(idx, slot)
                    a._stop_guard.clear_verified(generation, idx, slot, identity)
            except RuntimeError as exc:
                a.log_warn('[multiACE] ACE %d 槽 %d 停止复核：%s' % (idx + 1, slot + 1, exc))
            finally:
                self.pending_stops.discard(key)

        self.pending_stops.add(key)
        try:
            a.reactor.register_callback(stop)
        except Exception:
            self.pending_stops.discard(key)
            raise
        return True

    def prepare_unload_retry(self, head):
        a = self.ace
        source = a._head_source.get(head)
        route = source_route(source)
        if (not self.tip_moves or route is None or source.get('load_failed') is not False
                or not a.head_uses_ace(head) or not ParkMotion.idle(a) or a._swap_in_progress):
            return False
        idx, slot = route
        ops = getattr(a, '_path_operations', None)
        if not self.online(idx) or not a._is_v2_idx(idx) or (ops is not None and ops.handles(idx, slot)):
            return False
        fault = a._stop_guard.snapshot(a._stop_targets(idx, slot, head))
        if fault is not None and ((fault['ace_idx'], fault['slot']) != route
                or fault['reason'] not in DECODER_UNAVAILABLE_REASONS):
            return False
        if fault is None and a._v2_get_slot_status(idx, slot) != 'assist_error':
            return False
        if a._native_reconnect_block_reason(head, idx, slot, allow_stop_fault=True):
            return False
        module, ch = a.EXTRUDER_MAP[head]
        feeder = a.printer.lookup_object('filament_feed %s' % module)
        if (feeder._get_filament_soft(ch) or a.tipform_table_for(
                a._tipform_material_for(head), vendor=a._tipform_vendor_for(head), soft=False) is not None):
            return False
        receipt = a._slot_actions.recover_slot(idx, slot, allow_probe=False, clear_latch=True)
        a._require_no_stop_fault(idx=idx, slot=slot, head=head)
        return (receipt.get('slot_status') == 'assist_error' and receipt.get('stopped') is True
                and receipt.get('requires_hot_unload') is True
                and not receipt.get('requires_position_review'))

    def run_stock_tipform(self, head, script, soft):
        a = self.ace
        route = source_route(a._head_source.get(head))
        operations = getattr(a, '_path_operations', None)
        if (not self.tip_moves or soft or route is None or not a.head_uses_ace(head)
                or not a._is_v2_idx(route[0]) or not ParkMotion.idle(a)
                or a._swap_in_progress or (operations is not None and operations.handles(*route))):
            return a.gcode.run_script_from_command(script)
        if self.stock_tip is not None:
            raise ReadyWaitError('原厂拉尖助送已被占用')
        # A held route can already be owned by a bounded original-slot unload.
        # Keep the stock assist and wire checks; do not apply the print gate twice.
        reason = a._native_reconnect_block_reason(head, *route, for_stock_unload=True)
        stale_session_unload = False
        if reason == STALE_SOURCE_SESSION_REASON:
            stale_session_unload = self._stale_session_unload_allowed(head, *route)
            if stale_session_unload:
                reason = None
        if reason:
            raise a.printer.command_error(reason)
        self.tip_epoch += 1
        self.stock_tip = StockTipAssist(
            self, head, *route, allow_stale_session_unload=stale_session_unload)
        if self.retry_head == head:
            self.retry_head = None
        try:
            return a.gcode.run_script_from_command(script)
        finally:
            a._v2_active_rev_assist = False
            self.stock_tip = None

    def _stale_session_unload_allowed(self, head, idx, slot):
        a = self.ace
        source = a._head_source.get(head)
        identity = a._location_identity(idx)
        if (not self.online(idx) or source_route(source) != (idx, slot)
                or source.get('load_failed') is not False
                or source_conflict(a, head, idx, slot) is not None
                or not isinstance(identity, (tuple, list)) or len(identity) != 2
                or not isinstance(identity[1], (tuple, list))
                or source.get('connection_identity') != {
                    'port': identity[0], 'uid': list(identity[1])}
                or raw_head_state(a, head) is not True
                or a._stop_message(idx, slot, head) is not None
                or dynamic_route_blocked(a, head=head, idx=idx, slot=slot)):
            return False
        return True

    def wrap_stock_retract(self, previous):
        def wrapped(gcmd):
            tip = self.stock_tip
            if tip is None or tip.controlling:
                return previous(gcmd)
            tip.controlling = True
            try:
                return previous(gcmd)
            finally:
                try:
                    tip.finish()
                except (ReadyWaitError, StopUnconfirmedError) as exc:
                    raise gcmd.error(str(exc)) from exc
                finally:
                    tip.controlling = False
        return wrapped

    def wrap_move(self, previous, move):
        def wrapped(gcmd):
            a = self.ace
            tip = self.stock_tip
            if tip is not None and tip.controlling:
                try:
                    reverse = tip.before_move(gcmd, move)
                    result = previous(gcmd)
                    if reverse is not None:
                        tip.arm_reverse_after_start(*reverse)
                    return result
                except (ReadyWaitError, StopUnconfirmedError) as exc:
                    raise gcmd.error(str(exc)) from exc
            if (self.sd.is_cmd_from_sd() and a._fa_context == 'print'
                    and not a._swap_in_progress and not a._pickcheck_active
                    and not a._v2_active_rev_assist and a._is_actively_printing()
                    and self.forward_move(gcmd, move)):
                self.check_move(gcmd)
            elif not self.sd.is_cmd_from_sd() and self.manual_forward_move(gcmd, move):
                return self.run_idle_extrusion(previous, gcmd)
            return previous(gcmd)
        return wrapped

    @staticmethod
    def manual_forward_move(gcmd, move):
        params = gcmd.get_command_parameters()
        # The U1 parser includes G, and optional line numbering / checksum.
        if gcmd.get_command() not in ('G0', 'G1') or set(params) - {'G', 'N', '*', 'E', 'F'}:
            return False
        try:
            speed = float(params['F']) if 'F' in params else move.speed
        except ValueError:
            return False
        return math.isfinite(speed) and speed > 0 and PrintAssist.forward_move(gcmd, move)

    def _idle_route_ready(self, head, idx, slot):
        a = self.ace
        if (a._ace_mode not in ('multi', 'head')
                or self.sd.current_file is not None or not ParkMotion.idle(a)
                or a._auto_feed_enabled or a._fa_context != 'idle'
                or a._swap_in_progress or a._pickcheck_active
                or a._v2_active_rev_assist or self.stock_tip is not None
                or head != self.active_head() or not self.online(idx)
                or not a._is_v2_idx(idx) or not a.head_uses_ace(head)
                or any(owner.active for owner in a._feed_supervisors.values())
                or getattr(a, '_fixed_park_motion', None) is not None):
            return False
        if not a.toolhead.get_extruder().get_heater().can_extrude:
            return False
        machine = a.printer.lookup_object('machine_state_manager', None)
        if (machine is not None and str(machine.get_status().get('main_state'))
                not in ('IDLE', 'MANUAL_LOAD')):
            return False
        bg = a.printer.lookup_object('ace_bg_swap', None)
        if bg is not None and any(bg.is_busy(h) for h in range(4)):
            return False
        operations = getattr(a, '_path_operations', None)
        if operations is not None and operations.handles(idx, slot):
            return False
        if a._slot_actions.state.get('state') == 'running' or self.pending_stops:
            return False
        return not (a._native_buffer.hold_reason(idx, slot)
                    or a._native_reconnect_block_reason(head, idx, slot))

    def run_idle_extrusion(self, previous, gcmd):
        """Assist one explicit forward E move without taking the print gate."""
        a = self.ace
        head = self.active_head()
        route = source_route(a._head_source.get(head))
        if route is None:
            return previous(gcmd)
        idx, slot = route
        if (not self._idle_route_ready(head, idx, slot)
                or self.recent_state(idx, slot) != 'ready'):
            return previous(gcmd)

        transport = a._serials.get(idx)
        identity = a._location_identity(idx)
        buffer = a._native_buffer
        if (a._feed_assist_per_ace.get(idx, -1) != -1
                or buffer.active_slots(idx, transport, identity[1])):
            return previous(gcmd)

        def check_start():
            if (a._serials.get(idx) is not transport or a._location_identity(idx) != identity
                    or not self._idle_route_ready(head, idx, slot)):
                raise ReadyWaitError('手动挤料助送的喷头或料路已变化')

        a.toolhead.wait_moves()
        request = {'method': 'start_feed_assist', 'params': {'index': slot},
                   '_insert_stop_transport': transport, '_print_assist_monitor': check_start}
        try:
            check_start()
            if (self.recent_state(idx, slot) != 'ready'
                    or a._feed_assist_per_ace.get(idx, -1) != -1
                    or buffer.active_slots(idx, transport, identity[1])):
                return previous(gcmd)
            response = a._tipform_send(idx, request, timeout=ACK_TIMEOUT)
            check_start()
        except (RuntimeError, ValueError) as exc:
            logging.info('[multiACE] manual extrusion assist skipped: %s', exc)
            response = None

        token = request.get('_native_buffer_token')
        if (a._tipform_rejected(response) or not token
                or not buffer.recovery_current(token, transport, identity[1])
                or not self.accepted(idx, slot)):
            self._stop_idle_extrusion(idx, slot, transport, identity, token)
            return previous(gcmd)

        logging.info('[multiACE] manual extrusion assist on: head %d, ACE %d slot %d',
                     head + 1, idx + 1, slot + 1)
        try:
            result = previous(gcmd)
            a.toolhead.wait_moves()
            return result
        finally:
            self._stop_idle_extrusion(idx, slot, transport, identity, token)

    def _stop_idle_extrusion(self, idx, slot, transport, identity, token):
        a = self.ace
        if (not token or a._serials.get(idx) is not transport
                or a._location_identity(idx) != identity
                or not a._native_buffer.recovery_current(token, transport, identity[1])):
            return
        # The explicit move has drained. Retire only its own assist lease.
        # A ready reply is sufficient and does not require an encoder sample.
        try:
            stop_and_verify(a, idx, slot, transport=transport, identity=identity,
                            ready_without_decoder=True, ready_status_only=True)
            logging.info('[multiACE] manual extrusion assist off: ACE %d slot %d',
                         idx + 1, slot + 1)
        except (RuntimeError, ValueError) as exc:
            logging.warning('[multiACE] manual extrusion assist stop: %s', exc)

    @staticmethod
    def extrusion_delta(gcmd, move):
        value = gcmd.get_command_parameters().get('E')
        if value is None:
            return 0.
        try:
            value = float(value) * move.extrude_factor
        except ValueError:
            return 0.  # Leave invalid command handling to stock G-code.
        if move.absolute_coord and move.absolute_extrude:
            value += move.base_position[3] - move.last_position[3]
        return value if math.isfinite(value) else 0.

    @staticmethod
    def forward_move(gcmd, move):
        return PrintAssist.extrusion_delta(gcmd, move) > 1e-8

    def accepted(self, idx, slot):
        a = self.ace
        return (a._native_assist_is_armed(idx, slot)
                and a._native_buffer.direction(idx, slot) == 2
                and a._native_buffer.hold_reason(idx, slot) is None)

    def recent_state(self, idx, slot):
        a = self.ace
        transport = a._serials.get(idx)
        now = a.reactor.monotonic()
        heartbeat = getattr(a, '_slot_status_provenance', {}).get(idx)
        direct = self.checked.get((idx, slot))
        if (direct is not None and direct[0] is transport
                and 0 <= now - direct[1] <= STATUS_MAX_AGE
                and (heartbeat is None or heartbeat[0] is not transport
                     or direct[1] > heartbeat[1])):
            return direct[2]
        if (heartbeat is not None and heartbeat[0] is transport
                and 0 <= now - heartbeat[1] <= STATUS_MAX_AGE):
            return a._v2_get_slot_status(idx, slot)
        return None

    def check_move(self, gcmd):
        a = self.ace
        head = self.active_head()
        source = a._head_source.get(head)
        if not self.manages(head, source):
            return
        idx, slot = source_route(source)
        if (not self.sd.must_pause_work and self.online(idx)
                and self.accepted(idx, slot) and a._source_insertion_matches(source, idx, slot)
                and self.recent_state(idx, slot) in PRINT_SLOT_STATES
                and (a._stop_guard.snapshot() is None or a._stop_message(idx, slot) is None)):
            return
        job = self.sd.current_file
        try:
            self.ensure(head, idx, slot)
        except (RuntimeError, ValueError) as exc:
            stop_error = self.stop_failed_assist(job, head, idx, slot)
            detail = '[multiACE] 喷头 %d · ACE %d 槽 %d：%s' % (head + 1, idx + 1, slot + 1, exc)
            if stop_error:
                detail += '；' + stop_error
            logging.warning(detail)
            raise gcmd.error(message=detail[:400], action='pause', id=525,
                             index=head, code=210, oneshot=1, level=2)

    def stop_failed_assist(self, job, head, idx, slot):
        a = self.ace
        transport = a._serials.get(idx)
        identity = a._location_identity(idx)
        key = idx, slot
        # A queued START or a valid START whose following status read failed
        # may already be running. Handle that exact slot before yielding it.
        if (not self.online(idx) or key in self.pending_stops or identity[1] is None
                or not a._native_assist_needs_stop(idx, slot)
                and slot not in a._native_buffer.active_slots(idx, transport, identity[1])):
            return None

        def monitor():
            source = a._head_source.get(head)
            if (job is None or self.sd.current_file is not job or self.active_head() != head
                    or source_route(source) != key or not a._source_insertion_matches(source, idx, slot)
                    or source.get('connection_identity') != {'port': identity[0], 'uid': list(identity[1])}
                    or a._serials.get(idx) is not transport or a._location_identity(idx) != identity
                    or a._swap_in_progress or key in getattr(a, '_feed_supervisors', {})):
                raise ReadyWaitError('原槽助送归属或连接已变化')

        try:
            monitor()
            stop_and_verify(a, idx, slot, transport=transport, identity=identity,
                            monitor=monitor, ready_without_decoder=True)
            a._clear_fa_cache_for(idx, slot)
        except (RuntimeError, ValueError) as exc:
            return str(exc)
        return None

    def ensure(self, head, idx, slot):
        a = self.ace
        now = a.reactor.monotonic
        deadline = now() + RECOVERY_TIMEOUT
        job = self.sd.current_file
        operator_epoch = self.operator_epoch
        parked_stops = self.pending_stops

        def guard():
            if (job is None or self.sd.current_file is not job or self.sd.must_pause_work
                    or self.operator_epoch != operator_epoch or not a._is_actively_printing()
                    or a._swap_in_progress or not a._auto_feed_enabled
                    or self.active_head() != head
                    or source_route(a._head_source.get(head)) != (idx, slot)):
                raise ReadyWaitError('打印、喷头或送料来源已变化，已停止自动重试')
            if now() >= deadline:
                raise ReadyWaitError('自动恢复已达到等待时限')

        guard()
        if not self.online(idx):
            self.request_reconnect(idx)
            while not self.online(idx):
                guard()
                if idx not in self.pending_links and not a._reconnecting_per_ace.get(idx):
                    raise ReadyWaitError('目标 ACE 自动重连失败')
                a.reactor.pause(min(deadline, now() + .05))
        while (idx, slot) in parked_stops:
            guard()
            a.reactor.pause(min(deadline, now() + .05))

        transport = a._serials.get(idx)
        identity = a._location_identity(idx)
        # DISCOVER is asynchronous even when the link has just reopened.
        identity_deadline = min(deadline, now() + 1.5)
        if identity[1] is None:
            a._refresh_location_identity(idx, now())
        while identity[1] is None and now() < identity_deadline:
            guard()
            if not self.online(idx) or a._serials.get(idx) is not transport:
                raise ReadyWaitError('目标 ACE 连接在复核时变化')
            a.reactor.pause(min(identity_deadline, now() + .05))
            identity = a._location_identity(idx)
        reason = a._native_reconnect_block_reason(head, idx, slot, allow_stop_fault=True)
        if reason:
            raise ReadyWaitError(reason)
        expected = a._head_source.get(head)

        def monitor():
            guard()
            source = a._head_source.get(head)
            if (not self.online(idx) or a._serials.get(idx) is not transport
                    or a._location_identity(idx) != identity
                    or not a._source_insertion_matches(source, idx, slot)
                    or source.get('connection_identity') != expected.get('connection_identity')
                    or source.get('load_failed') or raw_head_state(a, head) is not True):
                raise ReadyWaitError('原设备连接、耗材来源或喷头到料已变化')

        # Preserve the dryer/route interlock and single assist owner.
        printing = a._dry_cycles.printing
        if printing is not None and not printing.ready_to_feed(idx):
            raise ReadyWaitError('供料箱尚未降到打印允许温度')
        a._native_buffer.clear_hold(idx, slot)
        state = self.read_slot(idx, slot, transport, deadline, monitor)
        fault = a._stop_message(idx, slot, head)
        if self.accepted(idx, slot) and state in PRINT_SLOT_STATES and not fault:
            return
        a.log_warn('[multiACE] 正在自动复核 ACE %d 槽 %d 助送' % (idx + 1, slot + 1))
        for attempt in range(2):
            monitor()
            fault = a._stop_message(idx, slot, head)
            if (fault or state not in PRINT_SLOT_STATES or attempt
                    or a._native_assist_needs_stop(idx, slot)
                    or slot in a._native_buffer.active_slots(idx, transport, identity[1])):
                generation, _ = a._stop_guard.recovery_snapshot()
                proof = stop_and_verify(a, idx, slot, transport=transport, identity=identity,
                                        timeout=min(3., deadline - now()), monitor=monitor,
                                        ready_without_decoder=True)
                state = proof['slot_status']
                a._clear_fa_cache_for(idx, slot)
                if fault:
                    a._stop_guard.clear_verified(generation, idx, slot, identity)
                if a._stop_message(idx, slot, head):
                    raise ReadyWaitError('共用料路停止仍未确认')
            if state not in REARM_SLOT_STATES:
                raise ReadyWaitError('原槽仍报 %s，需要检查耗材或设备' % state)

            monitor()
            if idx != a._active_device_index:
                a._set_active_idx(idx)
            a._arm_fa_for(idx, slot, print_monitor=monitor)
            ack_deadline = min(deadline, now() + ACK_TIMEOUT)
            while not self.accepted(idx, slot) and now() < ack_deadline:
                monitor()
                a.reactor.pause(min(ack_deadline, now() + .04))
            state = self.read_slot(idx, slot, transport, deadline, monitor)
            if self.accepted(idx, slot) and state in PRINT_SLOT_STATES:
                a.log_notice('[multiACE] ACE %d 槽 %d 助送已确认，继续打印' %
                             (idx + 1, slot + 1), done=True)
                return
        raise ReadyWaitError('助送重试已用尽（%s）' % state)

    def read_slot(self, idx, slot, transport, deadline, monitor, initial_assist=False):
        a = self.ace
        now = a.reactor.monotonic
        reason = '目标槽状态未确认'
        for _attempt in range(2):
            monitor()
            replies = []
            request = {'method': 'get_status', 'params': {},
                       '_insert_stop_transport': transport}

            def callback(self, response, replies=replies):
                replies.append(response)

            a.send_request_to(idx, request, callback)
            until = min(now() + .65, deadline)
            while not replies and now() < until:
                monitor()
                a.reactor.pause(min(until, now() + .04))
            monitor()
            states, reason = status_rows(replies[0] if replies else None, request)
            if states is not None:
                if initial_assist and states[slot] == 'assist_error':
                    return states[slot]
                a._native_buffer.observe_status(idx, [{'index': slot, 'slot_status': states[slot]}], transport)
                # Keep the direct proof separate from the heartbeat's metadata.
                self.checked[(idx, slot)] = transport, now(), states[slot]
                return states[slot]
        raise ReadyWaitError(reason)


class StockTipAssist:
    """Coordinate one original ACE lane at the stock G1 segment boundaries."""

    def __init__(self, controller, head, idx, slot, *, allow_stale_session_unload=False):
        self.controller = controller
        self.ace = controller.ace
        self.head, self.idx, self.slot = head, idx, slot
        self.transport = self.ace._serials.get(idx)
        self.identity = self.ace._location_identity(idx)
        source = self.ace._head_source.get(head) or {}
        bound_identity = source.get('connection_identity') or {}
        self.source_identity = {
            'port': bound_identity.get('port'),
            'uid': list(bound_identity.get('uid') or ()),
        }
        self.allow_stale_session_unload = bool(allow_stale_session_unload)
        self.operator_epoch = controller.operator_epoch
        self.controlling = False
        self.mode = None
        self.reverse_speed = None
        self.still = False
        self.stop_failed = False
        self.retry_initial_assist = controller.retry_head == head
        self.stopped_fault = False
        if self.is_armed(2):
            self.mode = 2

    def check_route(self):
        a = self.ace
        source = a._head_source.get(self.head) or {}
        if (self.controller.stock_tip is not self or not self.controller.online(self.idx)
                or a._serials.get(self.idx) is not self.transport
                or a._location_identity(self.idx) != self.identity
                or source_route(source) != (self.idx, self.slot)
                or source.get('connection_identity') != self.source_identity):
            raise ReadyWaitError('拉尖期间原 ACE 连接或料路已改变')

    def check_move(self):
        self.check_route()
        a = self.ace
        a._check_calibration_unload_cancel()
        a._require_no_stop_fault(idx=self.idx, slot=self.slot, head=self.head)
        recovery = getattr(a, '_position_unload_recovery', None)
        original_unload = recovery is not None and recovery.owns_source(
            self.head, self.idx, self.slot)
        source = a._head_source.get(self.head)
        source_session_matches = a._source_insertion_matches(source, self.idx, self.slot)
        stale_session_route_still_owned = (
            self.allow_stale_session_unload
            and source.get('load_failed') is False
            and source.get('connection_identity') == self.source_identity)
        if (self.controller.operator_epoch != self.operator_epoch or not ParkMotion.idle(a)
                or self.controller.active_head() != self.head
                or (not original_unload and not source_session_matches
                    and not stale_session_route_still_owned)):
            raise ReadyWaitError('拉尖已中止，或喷头及原槽来源已改变')

    def is_armed(self, mode):
        a = self.ace
        return (a._native_assist_is_armed(self.idx, self.slot)
                and a._native_buffer.direction(self.idx, self.slot) == mode)

    def check_stop(self):
        self.check_route()
        present = raw_head_state(self.ace, self.head)
        if present is None or (self.retry_initial_assist and not present):
            raise ReadyWaitError('原喷头到料状态已变化')

    def stop(self):
        a = self.ace
        start = a.reactor.monotonic()
        self.stop_failed = True
        proof = stop_and_verify(a, self.idx, self.slot, transport=self.transport,
                                identity=self.identity, monitor=self.check_stop,
                                ready_without_decoder=True, stopped_assist_without_decoder=True,
                                trace_failure=True, stock_unload=True)
        a._clear_fa_cache_for(self.idx, self.slot)
        self.stop_failed = False
        self.mode = None
        self.reverse_speed = None
        self.still = True
        state = proof['slot_status']
        if state == 'assist_error':
            self.stopped_fault = True
        elif state == 'ready':
            self.stopped_fault = False
        else:
            raise ReadyWaitError('拉尖期间原槽报告 %s' % state)
        logging.info('[multiACE] stock tip ACE %d slot %d stop verified in %.3fs',
                     self.idx + 1, self.slot + 1, proof['at'] - start)

    def before_move(self, gcmd, move):
        delta = self.controller.extrusion_delta(gcmd, move)
        if abs(delta) <= 1e-8:
            return
        self.check_move()
        try:
            speed = gcmd.get_command_parameters().get('F')
            speed = move.speed if speed is None else float(speed) * move.speed_factor
        except ValueError:
            return  # Stock G-code reports the malformed move.
        if not math.isfinite(speed) or speed <= 0:
            return

        # Match the upstream reverse-motion deadband. Slow stock cooling
        # pulls still need mode 3 so the native buffer can take up slack.
        desired = 2 if delta > 0 else (3 if speed > TIP_SLOW_REVERSE_MM_S else None)
        if self.mode == desired and (self.still if desired is None else self.is_armed(desired)) and (
                desired != 3 or self.reverse_speed == self.reverse_speed_for(speed)):
            return

        a = self.ace
        a.toolhead.wait_moves()
        self.check_move()
        if not self.still:
            self.stop()
        if desired is None:
            return
        if self.retry_initial_assist and desired != 2:
            raise ReadyWaitError('原厂退料起始动作不是正向送料，未重新启动助送')
        if desired == 3:
            return delta, speed
        try:
            self.arm(desired, delta, speed)
        except AssistArmUnconfirmed as exc:
            logging.info('[multiACE] stock tip retry forward assist after confirmed STOP: %s', exc)
            self.stop()
            self.arm(desired, delta, speed)

    def arm_reverse_after_start(self, delta, speed):
        a = self.ace
        motion = a.printer.lookup_object('motion_report', None)
        if motion is None:
            raise ReadyWaitError('缺少喷头实时速度，未启动反向助送')
        a.toolhead.flush_step_generation()
        deadline = a.reactor.monotonic() + TIP_REVERSE_START_TIMEOUT
        while a.reactor.monotonic() < deadline:
            self.check_move()
            now = a.reactor.monotonic()
            velocity = motion.get_status(now).get('live_extruder_velocity', 0.)
            if velocity < -.3:
                try:
                    self.arm(3, delta, speed)
                except AssistArmUnconfirmed as exc:
                    # The OEM move is already underway; never re-arm reverse
                    # after it. Reconcile at its end before admitting the
                    # original next (often cooling) move.
                    logging.info('[multiACE] stock tip verifying STOP after reverse assist: %s', exc)
                    a.toolhead.wait_moves()
                    self.stop()
                return
            a.reactor.pause(min(deadline, now + .025))
        logging.info('[multiACE] stock tip skipped reverse assist after no live reverse sample')

    def reverse_speed_for(self, speed):
        return self.ace._v2_quantize_velocity(-speed, 'rev')

    def arm(self, desired, delta, speed):
        a = self.ace
        self.check_move()
        params = {'index': self.slot}
        method = 'start_feed_assist'
        if desired == 3:
            method = 'feed_or_rollback_raw'
            params.update(mode=3, length=0, speed=self.reverse_speed_for(speed))
        self.still = False  # STOP is required even if the arm's ACK is lost.
        response = a._tipform_send(self.idx, {'method': method, 'params': params,
            '_insert_stop_transport': self.transport, '_print_assist_monitor': self.check_move},
            timeout=ACK_TIMEOUT)
        self.check_move()
        if a._tipform_rejected(response) or not self.is_armed(desired):
            raise AssistArmUnconfirmed('原槽助送方向未确认')
        deadline = a.reactor.monotonic() + 1.5
        try:
            if self.stopped_fault:
                state = 'assist_error'
                while a.reactor.monotonic() < deadline:
                    state = self.controller.read_slot(
                        self.idx, self.slot, self.transport, deadline, self.check_move, initial_assist=True)
                    if state != 'assist_error':
                        break
                    a.reactor.pause(min(deadline, a.reactor.monotonic() + .05))
            else:
                state = self.controller.read_slot(self.idx, self.slot, self.transport, deadline, self.check_move)
        except ReadyWaitError as exc:
            self.check_move()
            raise AssistArmUnconfirmed(str(exc)) from exc
        running = 'assisting' if desired == 2 else 'rollback_assisting'
        if state not in ('ready', running) or not self.is_armed(desired):
            raise AssistArmUnconfirmed('原槽助送状态未确认（%s）' % state)
        self.mode = desired
        self.reverse_speed = params.get('speed')
        self.retry_initial_assist = self.stopped_fault = False
        logging.info('[multiACE] stock tip ACE %d slot %d armed mode=%d, E=%g F=%g ACE_speed=%s',
                     self.idx + 1, self.slot + 1, desired, delta, speed * 60, self.reverse_speed)

    def finish(self):
        if self.stop_failed:
            return
        if not self.still:
            try:
                self.ace.toolhead.wait_moves()
            finally:
                self.stop()
        # The next finite retract owns the stopped-assist handoff. A verified
        # STOP may still carry the same assist notification on every segment.
