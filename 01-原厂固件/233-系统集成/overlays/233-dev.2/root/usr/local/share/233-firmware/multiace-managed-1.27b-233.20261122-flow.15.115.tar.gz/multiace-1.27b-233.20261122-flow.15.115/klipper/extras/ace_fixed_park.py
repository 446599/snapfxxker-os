"""Return stock V2 filament to its route in reverse only."""
import logging
import copy
import math

from .ace_flow_guard import raw_head_state, source_conflict, source_route
from .ace_v2_standstill import decode_sample, stop_and_verify


class ParkEdgeMissed(RuntimeError):
    """A verified stopped short probe ended before the head switch cleared."""
    def __init__(self, retracted_mm):
        super().__init__('短退限程内喷头开关尚未清空')
        self.retracted_mm = retracted_mm


class SwapShortStillLoaded(RuntimeError):
    """One finite swap pull completed and stopped with the original head still occupied."""
    def __init__(self, motion, commanded_mm):
        super().__init__('短退完成，喷头仍有料')
        self.motion = motion
        self.commanded_mm = commanded_mm


class ParkEncoderUnavailable(RuntimeError):
    pass


class ParkAckUnavailable(RuntimeError):
    """The fixed-park move returned no usable confirmation at all."""
    pass


class ParkMotion:
    TOLERANCE_MM = 3
    DIRECT_EDGE_LIMIT_MM = 120
    FAST_RETURN_SPEED = 100
    FAST_APPROACH_SPEED = 80
    FAST_APPROACH_MIN_SPEED = 40
    FAST_APPROACH_DISTANCE_MM = 45
    FAST_APPROACH_RESERVE_MM = 16
    POLL_S = 0.04
    FALLING_EDGE_SETTLE_S = .25
    # Upstream unwind pacing allows 2s for firmware start/stop overhead.
    HEAD_CLEAR_STARTUP_ALLOWANCE_S = 2.0
    IDLE_STATES = ('standby', 'complete', 'cancelled', 'error')

    def __init__(self, ace, idx, slot, head, *, foreground=False):
        self.ace, self.idx, self.slot, self.head = ace, idx, slot, head
        self.reactor = ace.reactor
        self.transport = ace._serials.get(idx)
        self.identity = ace._location_identity(idx)
        port, uid = self.identity
        if not port or not uid:
            raise RuntimeError('回停前未确认原 ACE 身份')
        self.scope = {'port': port, 'uid': list(uid), 'mode': ace._ace_mode}
        self.epoch = ace._insert_epochs.get((idx, slot))
        self.actions = ace._slot_actions
        self.foreground = foreground
        self.source = copy.deepcopy(ace._head_source.get(head)) if foreground else None
        stats = ace.printer.lookup_object('print_stats', None)
        self.print_state = getattr(stats, 'state', None)
        self.forward_decoder_sign = None
        self.pending = None
        self.receipt = None
        self.operation_deadline = self.reactor.monotonic() + 110

    @classmethod
    def idle(cls, ace):
        stats = ace.printer.lookup_object('print_stats', None)
        return getattr(stats, 'state', None) in cls.IDLE_STATES

    def check(self, *, released=False):
        a = self.ace
        a._require_no_stop_fault(idx=self.idx, slot=self.slot, head=self.head)
        a._check_calibration_unload_cancel()
        present = raw_head_state(a, self.head)
        gates = a._gate_status_per_ace.get(self.idx) or []
        if (a._fixed_park_motion is not (None if released else self) or self.transport is None
                or a._serials.get(self.idx) is not self.transport
                or not a._connected_per_ace.get(self.idx)
                or a._reconnecting_per_ace.get(self.idx)
                or a._location_identity(self.idx) != self.identity
                or a._ace_mode != self.scope['mode']
                or a._insert_epochs.get((self.idx, self.slot)) != self.epoch
                or source_route(a._head_source.get(self.head)) != (self.idx, self.slot)
                or source_conflict(a, self.head, self.idx, self.slot)
                or (self.foreground and (
                    not getattr(a, '_swap_in_progress', False)
                    or getattr(a, '_swap_phase', None) != 'unload'
                    or getattr(a.printer.lookup_object('print_stats', None), 'state', None) != self.print_state
                    or self.print_state not in self.IDLE_STATES + ('printing',)
                    or a._head_source.get(self.head) != self.source
                    or not a._source_insertion_matches(self.source, self.idx, self.slot)))
                or (not self.foreground and not self.idle(a))):
            raise RuntimeError('回停期间原连接、料路或打印状态改变')
        if self.slot >= len(gates) or gates[self.slot] != 1:
            raise RuntimeError('回停期间 ACE 槽口有料状态未确认')
        if present is None:
            raise RuntimeError('回停期间喷头传感器状态未知')
        if not released and self.reactor.monotonic() >= self.operation_deadline:
            raise RuntimeError('回停超过本次动作时限')
        return present

    def allows_wire(self, idx, request, serial):
        if idx != self.idx or serial is not self.transport or request is not self.pending:
            return False
        try:
            present = self.check()
            return (request.get('method') == 'unwind_filament'
                    and (not request.get('_park_require_empty') or present is False))
        except RuntimeError:
            return False

    def _stop(self, allow_zero=False, ready_without_decoder=False, ready_status_only=False):
        # Always verify on the original connection, even if a route/gate guard
        # caused the move to abort. Do not send another move on uncertain STOP.
        self.receipt = stop_and_verify(
            self.ace, self.idx, self.slot, transport=self.transport,
            identity=self.identity, timeout=5.0, ready_zero_mm=0 if allow_zero else None,
            ready_without_decoder=ready_without_decoder,
            stopped_assist_without_decoder=ready_without_decoder, ready_status_only=ready_status_only)

    def _gate(self):
        if not self.actions._gate(self.idx, self.slot, monitor=self.check):
            raise RuntimeError('回停后 ACE 槽口已无料')

    @staticmethod
    def _reply_ok(request, response, command):
        return (isinstance(response, dict) and type(request.get('id')) is int
                and type(response.get('id')) is int and response['id'] == request['id']
                and type(response.get('code')) is int and response['code'] == 0
                and response.get('_v2_command') == command
                and response.get('_v2_frame_valid') is True
                and response.get('_v2_payload_valid') is True
                and str(response.get('msg', '')).upper() != 'FORBIDDEN')

    @staticmethod
    def _reply_rejected(response):
        """Return true for an explicit wire or local admission rejection.

        A missing/invalid acknowledgement can be recovered after STOP has
        proved the lane is idle. An explicit rejection is different: the
        device or one of the local guards deliberately refused this motion,
        so it must keep the normal unload error path.
        """
        if not isinstance(response, dict):
            return False
        if response.get('_insert_invalidated') is True:
            return True
        code = response.get('code')
        return (type(code) is int and code != 0) or (
            str(response.get('msg', '')).strip().upper() == 'FORBIDDEN')

    def _feed_sample(self):
        replies = []

        def reply(self, response):
            if not replies:
                replies.append(response)

        request = {'method': 'get_feed_info', '_insert_stop_transport': self.transport,
                   '_insert_reject': reply}
        self.check()
        self.ace.send_request_to(self.idx, request, reply)
        end = self.reactor.monotonic() + .45
        while not replies and self.reactor.monotonic() < end:
            self.check()
            self.reactor.pause(min(end, self.reactor.monotonic() + self.POLL_S))
        if replies and self._reply_ok(request, replies[0], 76):
            try:
                return decode_sample(replies[0], self.slot, ready_zero_mm=0)
            except ValueError:
                pass
        return None

    def _move(self, length, speed, *, edge=None, stop_at=None,
              allow_edge_miss=False, wait_native=False, material_limit_mm=None, commanded=False,
              head_clear_mm=None, bounded_short=False):
        """One finite pulse, or stop sooner at a witnessed switch transition."""
        start_pin = self.check()
        if edge is not None and start_pin is edge:
            raise RuntimeError('喷头开关已在目标侧，无法建立本次边缘')
        require_empty = edge is None and head_clear_mm in (None, 0)
        if require_empty and start_pin is not False:
            raise RuntimeError('长退开始前喷头尚未清空')
        if not commanded and edge is None and self.forward_decoder_sign is None:
            raise RuntimeError('长退前原槽编码器方向未确认')
        before = self.receipt['sample']
        stopped_motor = self.receipt.get('motor_counters') if before is None else None
        if not commanded and before is None and (edge is not False or stopped_motor is None
                               or self.forward_decoder_sign is None):
            raise ParkEncoderUnavailable('回停前缺少可比较的原槽基线')
        allowance = 14 if wait_native else 4
        motor_limit_mm = length + allowance
        if material_limit_mm is None:
            material_limit_mm = motor_limit_mm
        params = {'index': self.slot, 'length': length, 'speed': speed}
        request = {'method': 'unwind_filament',
                   'params': params, '_fixed_park_motion': self, '_park_require_empty': require_empty,
                   '_insert_stop_transport': self.transport}
        replies = []

        def reply(self, response):
            if not replies:
                replies.append(response)

        request['_insert_reject'] = reply
        self.pending = request
        start = self.reactor.monotonic()
        observed = 0.0
        clear_deadline = (start + head_clear_mm / speed + self.HEAD_CLEAR_STARTUP_ALLOWANCE_S
                          if head_clear_mm is not None else None)
        head_cleared = not start_pin
        saw_rollback = False
        try:
            if self.ace.send_request_to(self.idx, request, reply) is False:
                raise RuntimeError('ACE 未受理本次回停动作')
            while not replies and self.reactor.monotonic() < start + 1.5:
                pin = self.check()
                if clear_deadline is not None and pin and self.reactor.monotonic() >= clear_deadline:
                    raise ParkAckUnavailable('短退范围内未收到退料确认，已停止')
                self.reactor.pause(self.reactor.monotonic() + self.POLL_S)
            if not replies:
                raise ParkAckUnavailable('ACE 未确认本次回停动作')
            if self._reply_rejected(replies[0]):
                raise RuntimeError('ACE 拒绝本次回停动作')
            if not self._reply_ok(request, replies[0], 8):
                raise ParkAckUnavailable('ACE 未确认本次回停动作')
            now = progress_at = poll_at = self.reactor.monotonic()
            end = now + length / speed + .55
            nominal_end = end
            ready_poll_at = now if head_clear_mm is not None else end
            if wait_native:
                end += max(2.0, length / speed * .40)
            poll_gate_at = now + .8
            clear_since = None
            while True:
                pin = self.check()
                now = self.reactor.monotonic()
                if head_clear_mm is not None and not head_cleared:
                    if not pin:
                        if clear_since is None:
                            clear_since = now
                        if now - clear_since >= self.FALLING_EDGE_SETTLE_S:
                            head_cleared = True
                            logging.info('[multiACE] continuous return head=%d cleared; reverse continues', self.head + 1)
                    else:
                        clear_since = None
                    if not bounded_short and not head_cleared and (now >= clear_deadline and
                            (clear_since is None or clear_since > clear_deadline)):
                        raise RuntimeError('短退范围内喷头仍有料，已停止退料')
                elif edge is not None and pin is edge:
                    if clear_since is None:
                        clear_since = now
                    elif now - clear_since >= self.FALLING_EDGE_SETTLE_S:
                        break
                else:
                    clear_since = None
                if edge is None and head_cleared and pin:
                    raise RuntimeError('长退期间喷头开关重新触发')
                if now >= end:
                    if commanded:
                        raise RuntimeError('原槽未在退料时限内就绪')
                    if edge is not None and not allow_edge_miss:
                        raise RuntimeError('在限程内未找到喷头传感器边缘')
                    break
                # At the switch, poll the pin without a serial round trip.
                # The bounded long move also checks the fresh inlet switch.
                if edge is None and (head_clear_mm is None or head_cleared) and now >= poll_gate_at:
                    self._gate()
                    poll_gate_at = now + .8
                if wait_native and now >= ready_poll_at:
                    ready_poll_at = now + .55
                    try:
                        state = self.actions._lane_states(self.idx, monitor=self.check).get(self.slot)
                    except RuntimeError:
                        self.check()
                    else:
                        if state == 'rollback':
                            saw_rollback = True
                        elif state == 'ready':
                            if bounded_short:
                                # A ready sample alone can predate motor startup.
                                if not saw_rollback or (not pin and not head_cleared):
                                    continue
                            elif head_clear_mm is not None and not head_cleared:
                                continue
                            if head_clear_mm is None:
                                break
                            if saw_rollback and now + .75 < nominal_end - .55:
                                raise RuntimeError('原槽提前结束退料，未确认回停')
                            if now >= nominal_end and (saw_rollback or start_pin):
                                break
                        elif not (head_clear_mm is not None and not head_cleared
                                  and not saw_rollback and now - start <= 1.0
                                  and state == 'assist_error'):
                            raise RuntimeError('长退期间原槽状态异常')
                if stop_at is not None and now >= poll_at:
                    sample = self._feed_sample()
                    poll_at = now + .25
                    if sample is not None and sample != before and sample[0] <= motor_limit_mm:
                        value = sample[1] * -self.forward_decoder_sign
                        if value + 1 < observed:
                            raise RuntimeError('低速回停的编码器方向改变或计数重置')
                        if value > observed:
                            observed, progress_at = value, now
                        if observed >= stop_at:
                            break
                    if now - progress_at >= 2.5:
                        raise RuntimeError('低速回停未读到连续推进的编码器')
                self.reactor.pause(min(end, now + self.POLL_S))
        finally:
            self.pending = None
            self._stop(allow_zero=edge is not None and stopped_motor is None, ready_status_only=commanded)
        pin = self.check()
        self._gate()
        if commanded:
            if bounded_short and pin and not head_cleared and self.receipt['slot_status'] == 'ready':
                raise SwapShortStillLoaded(self, length)
            if (pin is not False or (bounded_short and not head_cleared)
                    or self.receipt['slot_status'] != 'ready'):
                raise RuntimeError('回退后原槽或喷头状态未确认')
            return None  # Completion of a finite command supplies no measured distance.
        motor, decoder, steps = sample = self.receipt['sample']
        if self.forward_decoder_sign is None and edge is not None and pin is edge and decoder:
            # Older travel ledgers lack polarity. Only learn it from a
            # stopped short move whose physical switch changed as expected.
            self.forward_decoder_sign = (-1 if decoder > 0 else 1)
        distance = decoder * -(self.forward_decoder_sign or 0)
        if (self.receipt['slot_status'] != 'ready' or sample == before
                or (stopped_motor is not None
                    and ((steps, motor) == stopped_motor or distance <= 0))
                or not 0 <= motor <= motor_limit_mm or not steps
                or not max(observed - 1, 0 if edge is not None else 1) <= distance <= material_limit_mm):
            raise RuntimeError('回停动作缺少本次实际位移或编码器方向证据')
        if pin is not (False if edge is None else edge):
            if allow_edge_miss and edge is False and pin is True:
                raise ParkEdgeMissed(distance)
            raise RuntimeError('回停动作停稳后的喷头信号不符')
        logging.info('[multiACE] fixed park pulse ACE=%d slot=%d direction=reverse '
                     'command=%d speed=%d observed=%.1f terminal=%.1f motor=%.1f',
                     self.idx + 1, self.slot + 1,
                     length, speed, observed, distance, motor)
        return distance

    def run(self, target, short_commanded_mm, speed, *, direct=False, measured=False,
            head_clear_mm=None, handoff=None):
        a = self.ace
        if getattr(a, '_fixed_park_motion', None) is not None:
            raise RuntimeError('另一料路正在回停')
        a._fixed_park_motion = self
        try:
            initial_pin = self.check()
            if head_clear_mm is None and not direct and initial_pin is not False:
                raise RuntimeError('喷头尚未清空，未开始回停')
            a._v2_active_rev_assist = False
            a._clear_fa_cache_for(self.idx, self.slot)
            commanded = not (direct or measured)
            if head_clear_mm is not None:
                if (not commanded or not isinstance(handoff, dict)
                        or handoff.get('transport') is not self.transport
                        or handoff.get('identity') != self.identity
                        or (handoff.get('ace'), handoff.get('slot'), handoff.get('head')) !=
                           (self.idx, self.slot, self.head)
                        or handoff.get('slot_status') not in ('ready', 'assist_error')):
                    raise RuntimeError('连续退料前未确认原槽已交接')
                self.receipt = handoff
            else:
                self._stop(allow_zero=True, ready_without_decoder=True, ready_status_only=commanded)
                if self.receipt['slot_status'] == 'assist_error':
                    raise ParkEncoderUnavailable('原槽已停止助送，转普通有限回退')
                if self.receipt['slot_status'] != 'ready':
                    raise RuntimeError('原槽未就绪，未开始回停')
            self._gate()
            if commanded:
                # The native short pull already cleared the head. Debit every
                # completed short move before issuing one finite reverse.
                remaining = max(0, math.floor(target - short_commanded_mm))
                if self.foreground and head_clear_mm is not None and self.check():
                    # The head still grips the tip. Issue only a finite short command
                    # so a hot-end retry can debit it without guessing where a long
                    # command was interrupted.
                    short = min(head_clear_mm, remaining)
                    if short <= 0:
                        raise RuntimeError('退料长度用尽，喷头仍有料')
                    self._move(short, speed, wait_native=True, commanded=True,
                               head_clear_mm=short, bounded_short=True)
                    remaining -= short
                if self.foreground and head_clear_mm is not None:
                    # The bulk return now starts from an empty switch. Keep watching
                    # the lane for faults throughout the remainder of the same swap.
                    head_clear_mm = 0
                if remaining:
                    self._move(remaining, speed, wait_native=True, commanded=True,
                               head_clear_mm=head_clear_mm)
                a._verify_unload_park(self.idx, self.slot, self.head)
                if self.check() is not False:
                    raise RuntimeError('回停完成后喷头重新检测到料')
                logging.info('[multiACE] one-way park ACE=%d slot=%d target=%d prior=%.1f remaining=%d',
                             self.idx + 1, self.slot + 1, target, short_commanded_mm, remaining)
                return None, None
            if self.receipt['sample'] is None and (not direct or self.forward_decoder_sign is None
                    or self.receipt.get('motor_counters') is None):
                raise ParkEncoderUnavailable('固定回停缺少初始计数记录')
            if measured:
                if self.check() is not False or self.forward_decoder_sign is None:
                    raise RuntimeError('按实测距离回退前喷头或编码器方向未确认')
                reverse_edge = 0.0
            else:
                if self.check() is not True:
                    raise ParkEdgeMissed(0)
                reverse_edge = self._move(min(self.DIRECT_EDGE_LIMIT_MM, int(short_commanded_mm)), 6,
                                          edge=False, allow_edge_miss=True)
            # The legacy motor length can undershoot in filament units.
            # Measure the coarse move before sizing each fast correction.
            coarse = math.floor(target - 100)
            moves = []
            distance = 0.0
            fast_speed = min(speed, self.FAST_APPROACH_SPEED)
            if coarse > 40:
                distance = self._move(coarse, self.FAST_RETURN_SPEED,
                                      wait_native=True, material_limit_mm=target + self.TOLERANCE_MM)
                moves.append((coarse, distance))
            if fast_speed >= self.FAST_APPROACH_MIN_SPEED:
                for _ in range(2):
                    remaining = target - distance
                    if remaining <= self.FAST_APPROACH_DISTANCE_MM:
                        break
                    # The finite command stays short of the target even with
                    # the measured-move allowance. Keep the last approach slow
                    # enough to stop on the encoder with millimetre accuracy.
                    length = math.floor(remaining - self.FAST_APPROACH_RESERVE_MM)
                    actual = self._move(length, fast_speed, wait_native=True,
                                        material_limit_mm=remaining + self.TOLERANCE_MM)
                    moves.append((length, actual))
                    distance += actual
            for _ in range(3):
                remaining = target - distance
                if remaining <= self.TOLERANCE_MM:
                    break
                length = math.ceil(remaining) + 25
                actual = self._move(length, min(speed, 10), stop_at=remaining - 1)
                moves.append((length, actual))
                distance += actual
            if abs(target - distance) > self.TOLERANCE_MM:
                raise RuntimeError('回停未达到编码器目标：%.1f / %.1f mm' % (distance, target))
            a._verify_unload_park(self.idx, self.slot, self.head)
            if self.check() is not False:
                raise RuntimeError('回停完成后喷头重新检测到料')
            logging.info('[multiACE] fixed park ACE=%d slot=%d head=%d target=%.1f '
                         'decoder=%.1f reference=%s edge_retract=%.1f moves=%s',
                         self.idx + 1, self.slot + 1, self.head + 1,
                         target, distance, 'measured' if measured else 'direct',
                         reverse_edge, moves)
            return distance, -reverse_edge - distance
        finally:
            if a._fixed_park_motion is self:
                a._fixed_park_motion = None
